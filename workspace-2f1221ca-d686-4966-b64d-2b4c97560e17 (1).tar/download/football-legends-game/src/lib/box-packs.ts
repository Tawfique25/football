import { Player, PlayerVersion, CardTier } from './types';
import { PLAYERS, getPlayer, getVersion } from './players';

// ============================================================
//  BOX DRAW PACK SYSTEM — 5 packs × 150 players each
//  Each pack: 3 Epic (107/106/106) + 7 Highlight + 140 Standard
// ============================================================

export interface BoxPlayer {
  playerId: string;
  versionId: string;
  tier: CardTier;
}

export interface BoxPack {
  id: string;
  name: string;
  description: string;
  theme: string;
  accent: string;
  gradient: string;
  bannerGradient: string;
  featuredEpic: { playerId: string; versionId: string }[];
  /** Full 150-player roster for this box */
  players: BoxPlayer[];
}

// ============================================================
//  HELPERS
// ============================================================

/** Get all (player, version) pairs that match given theme tags */
function getVersionsByTheme(themes: string[]): { player: Player; version: PlayerVersion }[] {
  const result: { player: Player; version: PlayerVersion }[] = [];
  for (const player of PLAYERS) {
    for (const version of player.versions) {
      if (version.themes.some((t) => themes.includes(t))) {
        result.push({ player, version });
      }
    }
  }
  return result;
}

/** Get all (player, version) pairs by position group */
function getVersionsByPosition(positions: string[]): { player: Player; version: PlayerVersion }[] {
  const result: { player: Player; version: PlayerVersion }[] = [];
  for (const player of PLAYERS) {
    if (positions.includes(player.position) || player.altPositions.some((p) => positions.includes(p))) {
      for (const version of player.versions) {
        result.push({ player, version });
      }
    }
  }
  return result;
}

/** Get all versions with OVR in a range */
function getVersionsByOvr(min: number, max: number): { player: Player; version: PlayerVersion }[] {
  const result: { player: Player; version: PlayerVersion }[] = [];
  for (const player of PLAYERS) {
    for (const version of player.versions) {
      if (version.ovr >= min && version.ovr <= max) {
        result.push({ player, version });
      }
    }
  }
  return result;
}

/** Shuffle array (Fisher-Yates) */
function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Pick N unique items from array (by composite key) */
function pickUnique<T>(
  arr: T[],
  n: number,
  keyFn: (item: T) => string,
  excludeKeys: Set<string> = new Set()
): T[] {
  const shuffled = shuffle(arr);
  const result: T[] = [];
  for (const item of shuffled) {
    if (result.length >= n) break;
    const key = keyFn(item);
    if (excludeKeys.has(key)) continue;
    result.push(item);
    excludeKeys.add(key);
  }
  return result;
}

// ============================================================
//  BUILD PACK ROSTERS
// ============================================================

function buildPack(
  packDef: Omit<BoxPack, 'players'>,
  epicSpecs: { playerId: string; versionId: string; ovr: number }[],
  highlightSpecs: { playerId: string; versionId: string }[],
  standardThemes: string[]
): BoxPack {
  const usedKeys = new Set<string>();
  const players: BoxPlayer[] = [];

  // 1. Add 3 Epic players (107, 106, 106)
  for (const spec of epicSpecs) {
    const key = `${spec.playerId}__${spec.versionId}`;
    if (!usedKeys.has(key)) {
      players.push({ playerId: spec.playerId, versionId: spec.versionId, tier: 'epic' });
      usedKeys.add(key);
    }
  }

  // 2. Add 7 Highlight players
  for (const spec of highlightSpecs) {
    const key = `${spec.playerId}__${spec.versionId}`;
    if (!usedKeys.has(key)) {
      players.push({ playerId: spec.playerId, versionId: spec.versionId, tier: 'highlight' });
      usedKeys.add(key);
    }
  }

  // 3. Fill 140 Standard players from themed pool + general pool
  // First try themed players, then fill from general pool
  let standardPool: { player: Player; version: PlayerVersion }[] = [];

  // Get themed versions
  if (standardThemes.length > 0) {
    standardPool = getVersionsByTheme(standardThemes);
  }

  // If themed pool is too small, add general pool
  if (standardPool.length < 150) {
    const generalPool = getVersionsByOvr(70, 92);
    // Merge, avoiding duplicates by composite key
    const existingKeys = new Set(standardPool.map((v) => `${v.player.id}__${v.version.id}`));
    for (const v of generalPool) {
      const key = `${v.player.id}__${v.version.id}`;
      if (!existingKeys.has(key)) {
        standardPool.push(v);
        existingKeys.add(key);
      }
    }
  }

  // Filter out any versions already used as epic/highlight
  const filteredPool = standardPool.filter(
    (v) => !usedKeys.has(`${v.player.id}__${v.version.id}`)
  );

  // Pick 140 unique standard players
  const standards = pickUnique(filteredPool, 140, (v) => `${v.player.id}__${v.version.id}`, usedKeys);

  for (const s of standards) {
    players.push({
      playerId: s.player.id,
      versionId: s.version.id,
      tier: 'standard',
    });
  }

  return { ...packDef, players };
}

// ============================================================
//  5 BOX PACKS
// ============================================================

// --- Pack 1: Ballon d'Or ---
const pack1 = buildPack(
  {
    id: 'ballon-dor',
    name: 'Ballon d\'Or Pack',
    description: 'The greatest individual prize in football. The Ballon d\'Or winners and nominees.',
    theme: 'Ballon d\'Or',
    accent: '#fcd34d',
    gradient: 'linear-gradient(135deg, #78350f 0%, #fcd34d 30%, #fef3c7 50%, #fcd34d 70%, #78350f 100%)',
    bannerGradient: 'linear-gradient(135deg, #78350f 0%, #fcd34d 40%, #fef3c7 100%)',
    featuredEpic: [
      { playerId: 'kane', versionId: 'kane-epic' },
      { playerId: 'yamal', versionId: 'yamal-epic' },
      { playerId: 'mbappe', versionId: 'mbappe-epic' },
    ],
  },
  [
    { playerId: 'kane', versionId: 'kane-epic', ovr: 108 },
    { playerId: 'yamal', versionId: 'yamal-epic', ovr: 107 },
    { playerId: 'mbappe', versionId: 'mbappe-epic', ovr: 107 },
  ],
  [
    { playerId: 'haaland', versionId: 'haaland-highlight' },
    { playerId: 'debruyne', versionId: 'kdb-highlight' },
    { playerId: 'lewandowski', versionId: 'lewa-highlight' },
    { playerId: 'rodri', versionId: 'rodri-spain-euro' },
    { playerId: 'bellingham', versionId: 'bellingham-england-star' },
    { playerId: 'vinijr', versionId: 'vini-real-star' },
    { playerId: 'salah', versionId: 'salah-liverpool-star' },
  ],
  ['current', 'ballon-dor', 'epic']
);

// --- Pack 2: World Champions ---
const pack2 = buildPack(
  {
    id: 'world-champions',
    name: 'World Champions Pack',
    description: 'Players who lifted the greatest trophy in football — the World Cup.',
    theme: 'World Cup Winners',
    accent: '#fbbf24',
    gradient: 'linear-gradient(135deg, #0a1a3a 0%, #fbbf24 50%, #dc2626 100%)',
    bannerGradient: 'linear-gradient(135deg, #0a1a3a 0%, #fbbf24 50%, #dc2626 100%)',
    featuredEpic: [
      { playerId: 'messi', versionId: 'messi-epic' },
      { playerId: 'maradona', versionId: 'maradona-epic' },
      { playerId: 'zidane', versionId: 'zidane-epic' },
    ],
  },
  [
    { playerId: 'messi', versionId: 'messi-epic', ovr: 107 },
    { playerId: 'maradona', versionId: 'maradona-epic', ovr: 106 },
    { playerId: 'zidane', versionId: 'zidane-epic', ovr: 106 },
  ],
  [
    { playerId: 'mbappe', versionId: 'mbappe-highlight' },
    { playerId: 'kroos', versionId: 'kroos-highlight' },
    { playerId: 'modric', versionId: 'modric-highlight' },
    { playerId: 'beckenbauer', versionId: 'beckenbauer-highlight' },
    { playerId: 'charlton', versionId: 'charlton-highlight' },
    { playerId: 'platini', versionId: 'platini-highlight' },
    { playerId: 'cruyff', versionId: 'cruyff-highlight' },
  ],
  ['world-cup', 'argentina', 'france', 'germany', 'italy', 'spain', 'brazil']
);

// --- Pack 3: Goal Machine ---
const pack3 = buildPack(
  {
    id: 'goal-machine',
    name: 'Goal Machine Pack',
    description: 'The deadliest strikers and finishers in football history.',
    theme: 'Strikers',
    accent: '#dc2626',
    gradient: 'linear-gradient(135deg, #7f1d1d 0%, #dc2626 50%, #000000 100%)',
    bannerGradient: 'linear-gradient(135deg, #7f1d1d 0%, #dc2626 50%, #000000 100%)',
    featuredEpic: [
      { playerId: 'haaland', versionId: 'haaland-epic' },
      { playerId: 'mbappe', versionId: 'mbappe-epic' },
      { playerId: 'ronaldo-cr7', versionId: 'cr7-epic' },
    ],
  },
  [
    { playerId: 'haaland', versionId: 'haaland-epic', ovr: 107 },
    { playerId: 'mbappe', versionId: 'mbappe-epic', ovr: 106 },
    { playerId: 'ronaldo-cr7', versionId: 'cr7-epic', ovr: 106 },
  ],
  [
    { playerId: 'haaland', versionId: 'haaland-highlight' },
    { playerId: 'lewandowski', versionId: 'lewa-highlight' },
    { playerId: 'kane', versionId: 'kane-highlight' },
    { playerId: 'henry', versionId: 'henry-highlight' },
    { playerId: 'r9', versionId: 'r9-highlight' },
    { playerId: 'muller', versionId: 'muller-highlight' },
    { playerId: 'etoo', versionId: 'etoo-highlight' },
  ],
  [] // No theme filter — use general pool (attackers preferred)
);

// --- Pack 4: Defensive Monsters ---
const pack4 = buildPack(
  {
    id: 'defensive-monsters',
    name: 'Defensive Monsters Pack',
    description: 'The immovable walls. Legendary defenders and goalkeepers.',
    theme: 'Defenders',
    accent: '#3b82f6',
    gradient: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 50%, #1e1b4b 100%)',
    bannerGradient: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 50%, #1e1b4b 100%)',
    featuredEpic: [
      { playerId: 'maldini', versionId: 'maldini-epic' },
      { playerId: 'beckenbauer', versionId: 'beckenbauer-epic' },
      { playerId: 'yashin', versionId: 'yashin-epic' },
    ],
  },
  [
    { playerId: 'maldini', versionId: 'maldini-epic', ovr: 107 },
    { playerId: 'beckenbauer', versionId: 'beckenbauer-epic', ovr: 106 },
    { playerId: 'yashin', versionId: 'yashin-epic', ovr: 106 },
  ],
  [
    { playerId: 'maldini', versionId: 'maldini-highlight' },
    { playerId: 'baresi', versionId: 'baresi-highlight' },
    { playerId: 'cannavaro', versionId: 'cannavaro-highlight' },
    { playerId: 'ramos', versionId: 'ramos-highlight' },
    { playerId: 'vandijk', versionId: 'vandijk-highlight' },
    { playerId: 'casillas', versionId: 'casillas-highlight' },
    { playerId: 'alisson', versionId: 'alisson-highlight' },
  ],
  []
);

// --- Pack 5: Ultimate Playmakers ---
const pack5 = buildPack(
  {
    id: 'ultimate-playmakers',
    name: 'Ultimate Playmakers Pack',
    description: 'The magicians who pull the strings — midfield maestros and creators.',
    theme: 'Playmakers',
    accent: '#a855f7',
    gradient: 'linear-gradient(135deg, #4c1d95 0%, #a855f7 50%, #1e1b4b 100%)',
    bannerGradient: 'linear-gradient(135deg, #4c1d95 0%, #a855f7 50%, #1e1b4b 100%)',
    featuredEpic: [
      { playerId: 'iniesta', versionId: 'iniesta-epic' },
      { playerId: 'xavi', versionId: 'xavi-epic' },
      { playerId: 'pirlo', versionId: 'pirlo-epic' },
    ],
  },
  [
    { playerId: 'iniesta', versionId: 'iniesta-epic', ovr: 107 },
    { playerId: 'xavi', versionId: 'xavi-epic', ovr: 106 },
    { playerId: 'pirlo', versionId: 'pirlo-epic', ovr: 106 },
  ],
  [
    { playerId: 'debruyne', versionId: 'kdb-highlight' },
    { playerId: 'pirlo', versionId: 'pirlo-highlight' },
    { playerId: 'totti', versionId: 'totti-highlight' },
    { playerId: 'figo', versionId: 'figo-highlight' },
    { playerId: 'nedved', versionId: 'nedved-highlight' },
    { playerId: 'bergkamp', versionId: 'bergkamp-highlight' },
    { playerId: 'modric', versionId: 'modric-highlight' },
  ],
  []
);

// ============================================================
//  EXPORT
// ============================================================

export const BOX_PACKS: BoxPack[] = [pack1, pack2, pack3, pack4, pack5];

export function getBoxPack(packId: string): BoxPack | undefined {
  return BOX_PACKS.find((p) => p.id === packId);
}

/** Resolve a BoxPlayer to its full player + version objects */
export function resolveBoxPlayer(bp: BoxPlayer): { player: Player; version: PlayerVersion } | undefined {
  const player = getPlayer(bp.playerId);
  const version = getVersion(bp.playerId, bp.versionId);
  if (!player || !version) return undefined;
  return { player, version };
}

/** Count tiers in a pack's roster */
export function getPackTierCounts(pack: BoxPack): { epic: number; highlight: number; standard: number } {
  return {
    epic: pack.players.filter((p) => p.tier === 'epic').length,
    highlight: pack.players.filter((p) => p.tier === 'highlight').length,
    standard: pack.players.filter((p) => p.tier === 'standard').length,
  };
}
