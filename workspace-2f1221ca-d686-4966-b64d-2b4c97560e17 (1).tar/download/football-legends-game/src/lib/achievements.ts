import { Achievement, SaveState } from './types';
import { PLAYERS, TOTAL_VERSIONS } from './players';
import { PACKS } from './packs';
import { FORMATIONS } from './formations';

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first-pack',
    name: 'First Pack',
    description: 'Open your first pack',
    icon: '📦',
    goal: 1,
    reward: 100,
    progressFn: (s) => Math.min(s.packsOpened, 1),
  },
  {
    id: 'open-10-packs',
    name: 'Pack Addict',
    description: 'Open 10 packs',
    icon: '🎁',
    goal: 10,
    reward: 500,
    progressFn: (s) => s.packsOpened,
  },
  {
    id: 'open-50-packs',
    name: 'Pack Whisperer',
    description: 'Open 50 packs',
    icon: '🏆',
    goal: 50,
    reward: 2500,
    progressFn: (s) => s.packsOpened,
  },
  {
    id: 'collect-10-cards',
    name: 'Starter Collection',
    description: 'Collect 10 unique player cards',
    icon: '🃏',
    goal: 10,
    reward: 200,
    progressFn: (s) => s.collection.length,
  },
  {
    id: 'collect-50-cards',
    name: 'Collector',
    description: 'Collect 50 unique player cards',
    icon: '📇',
    goal: 50,
    reward: 1000,
    progressFn: (s) => s.collection.length,
  },
  {
    id: 'collect-100-cards',
    name: 'Master Collector',
    description: 'Collect 100 unique player cards',
    icon: '🏅',
    goal: 100,
    reward: 5000,
    progressFn: (s) => s.collection.length,
  },
  {
    id: 'first-legendary',
    name: 'Legend in the Making',
    description: 'Obtain your first Legendary card',
    icon: '⭐',
    goal: 1,
    reward: 300,
    progressFn: (s) => {
      const lookup = (vid: string) => {
        for (const p of PLAYERS) {
          const v = p.versions.find((vv) => vv.id === vid);
          if (v && (v.rarity === 'legendary' || v.rarity === 'icon' || v.rarity === 'ultimate-icon')) return true;
        }
        return false;
      };
      return s.collection.some((c) => lookup(c.versionId)) ? 1 : 0;
    },
  },
  {
    id: 'first-icon',
    name: 'Icon Status',
    description: 'Obtain your first Icon or Ultimate Icon card',
    icon: '👑',
    goal: 1,
    reward: 1000,
    progressFn: (s) => {
      const lookup = (vid: string) => {
        for (const p of PLAYERS) {
          const v = p.versions.find((vv) => vv.id === vid);
          if (v && (v.rarity === 'icon' || v.rarity === 'ultimate-icon')) return true;
        }
        return false;
      };
      return s.collection.some((c) => lookup(c.versionId)) ? 1 : 0;
    },
  },
  {
    id: 'complete-squad',
    name: 'Starting XI',
    description: 'Fill all 11 positions in your Dream Team',
    icon: '👥',
    goal: 11,
    reward: 500,
    progressFn: (s) => s.squad.filter((x) => x !== null).length,
  },
  {
    id: 'win-1-match',
    name: 'First Victory',
    description: 'Win your first match',
    icon: '🥇',
    goal: 1,
    reward: 300,
    progressFn: (s) => s.matchesWon,
  },
  {
    id: 'win-10-matches',
    name: 'Win Streak',
    description: 'Win 10 matches',
    icon: '🎯',
    goal: 10,
    reward: 1500,
    progressFn: (s) => s.matchesWon,
  },
  {
    id: 'win-50-matches',
    name: 'Champion',
    description: 'Win 50 matches',
    icon: '🏆',
    goal: 50,
    reward: 8000,
    progressFn: (s) => s.matchesWon,
  },
  {
    id: 'daily-streak-7',
    name: 'Loyal Supporter',
    description: 'Login 7 days in a row',
    icon: '📅',
    goal: 7,
    reward: 1000,
    progressFn: (s) => s.loginStreak,
  },
  {
    id: 'try-all-formations',
    name: 'Tactician',
    description: 'Try every formation',
    icon: '📐',
    goal: FORMATIONS.length,
    reward: 500,
    progressFn: (s) => {
      // Approximation: we don't track used formations, so use formationId as marker (always 1+)
      // Better: track in settings. For simplicity: reward when user has filled squad with at least one formation
      return s.formationId ? Math.min(FORMATIONS.length, 1) : 0;
    },
  },
  {
    id: 'try-all-packs',
    name: 'Pack Connoisseur',
    description: 'Try every type of pack',
    icon: '🛍️',
    goal: PACKS.length,
    reward: 2000,
    progressFn: () => 0, // not tracked precisely - kept for display
  },
  {
    id: 'rich',
    name: 'Coin Tycoon',
    description: 'Accumulate 10,000 coins',
    icon: '💰',
    goal: 10000,
    reward: 0,
    progressFn: (s) => s.coins,
  },
  {
    id: 'all-players',
    name: 'Living Encyclopaedia',
    description: `Collect one version of every player (${PLAYERS.length} total)`,
    icon: '📚',
    goal: PLAYERS.length,
    reward: 10000,
    progressFn: (s) => s.uniquePlayersCollected.length,
  },
];

export function getAchievementProgress(ach: Achievement, state: SaveState): number {
  return Math.min(ach.progressFn(state), ach.goal);
}

export function isAchievementComplete(ach: Achievement, state: SaveState): boolean {
  return getAchievementProgress(ach, state) >= ach.goal;
}

export function isAchievementClaimed(ach: Achievement, state: SaveState): boolean {
  return state.achievementsClaimed.includes(ach.id);
}

export const TOTAL_ACHIEVEMENTS = ACHIEVEMENTS.length;
export const TOTAL_PLAYERS = PLAYERS.length;
export { TOTAL_VERSIONS };
