import { Player, Rarity, Position } from './types';

/** Helper to create a player version with sensible defaults */
function v(
  id: string,
  versionName: string,
  rarity: Rarity,
  ovr: number,
  stats: { pac: number; sho: number; pas: number; dri: number; def: number; phy: number },
  themes: string[],
  special = false
) {
  return { id, versionName, rarity, ovr, stats, themes, special };
}

// ============================================================
//  CURRENT SUPERSTARS
// ============================================================

const messi: Player = {
  id: 'messi',
  name: 'L. Messi',
  nationality: 'Argentina',
  countryCode: 'ar',
  position: 'RW',
  altPositions: ['ST', 'CAM', 'CF'],
  club: 'Inter Miami',
  league: 'MLS',
  isLegend: false,
  versions: [
    v('messi-barca-wonderkid', 'Barcelona Wonderkid', 'rare', 81, { pac: 86, sho: 84, pas: 80, dri: 90, def: 28, phy: 62 }, ['barcelona', 'wonderkid', 'current']),
    v('messi-prime-barca', 'Prime Barcelona', 'legendary', 94, { pac: 90, sho: 95, pas: 93, dri: 97, def: 35, phy: 70 }, ['barcelona', 'prime', 'ucl', 'current']),
    v('messi-2011-barca-legend', '2011 Barcelona Legend', 'icon', 98, { pac: 92, sho: 96, pas: 95, dri: 98, def: 36, phy: 72 }, ['barcelona', 'ucl', 'legend']),
    v('messi-psg-superstar', 'PSG Superstar', 'legendary', 92, { pac: 80, sho: 92, pas: 91, dri: 94, def: 32, phy: 66 }, ['psg', 'current', 'france-league']),
    v('messi-argentina-wc', 'Argentina World Cup Champion', 'ultimate-icon', 99, { pac: 81, sho: 95, pas: 93, dri: 96, def: 36, phy: 70 }, ['argentina', 'world-cup', 'legend']),
    v('messi-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 100, { pac: 92, sho: 97, pas: 96, dri: 99, def: 38, phy: 72 }, ['ultimate', 'icon', 'legend']),
    v('messi-epic', 'Epic', 'mythic', 107, { pac: 93, sho: 98, pas: 97, dri: 99, def: 40, phy: 75 }, ['argentina', 'epic', 'legend'], true),
  ],
};

const ronaldo: Player = {
  id: 'ronaldo-cr7',
  name: 'Cristiano Ronaldo',
  nationality: 'Portugal',
  countryCode: 'pt',
  position: 'LW',
  altPositions: ['ST', 'CF'],
  club: 'Al Nassr',
  league: 'Saudi Pro League',
  isLegend: false,
  versions: [
    v('cr7-man-utd-wonderkid', 'Manchester United Wonderkid', 'rare', 80, { pac: 89, sho: 80, pas: 73, dri: 86, def: 30, phy: 70 }, ['man-utd', 'wonderkid', 'current']),
    v('cr7-prime-man-utd', 'Prime Manchester United', 'legendary', 93, { pac: 91, sho: 92, pas: 84, dri: 93, def: 35, phy: 80 }, ['man-utd', 'prime', 'ucl', 'current']),
    v('cr7-real-galactico', 'Real Madrid Galáctico', 'icon', 98, { pac: 90, sho: 96, pas: 86, dri: 92, def: 35, phy: 82 }, ['real-madrid', 'ucl', 'galactico', 'legend']),
    v('cr7-ucl-legend', 'Champions League Legend', 'icon', 96, { pac: 89, sho: 95, pas: 84, dri: 91, def: 36, phy: 82 }, ['ucl', 'real-madrid', 'legend']),
    v('cr7-portugal-euro', 'Portugal Euro Champion', 'ultimate-icon', 99, { pac: 87, sho: 94, pas: 83, dri: 91, def: 36, phy: 82 }, ['portugal', 'euro', 'legend']),
    v('cr7-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 100, { pac: 91, sho: 97, pas: 85, dri: 93, def: 36, phy: 83 }, ['ultimate', 'icon', 'legend']),
    v('cr7-epic', 'Epic', 'mythic', 106, { pac: 93, sho: 99, pas: 87, dri: 94, def: 40, phy: 88 }, ['portugal', 'epic', 'legend'], true),
  ],
};

const mbappe: Player = {
  id: 'mbappe',
  name: 'K. Mbappé',
  nationality: 'France',
  countryCode: 'fr',
  position: 'ST',
  altPositions: ['LW', 'CF'],
  club: 'Real Madrid',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('mbappe-monaco-wonderkid', 'Monaco Wonderkid', 'rare', 79, { pac: 93, sho: 76, pas: 70, dri: 86, def: 28, phy: 64 }, ['monaco', 'wonderkid', 'current']),
    v('mbappe-psg-superstar', 'PSG Superstar', 'legendary', 91, { pac: 97, sho: 90, pas: 82, dri: 92, def: 35, phy: 78 }, ['psg', 'current', 'france-league']),
    v('mbappe-france-wc', 'France World Cup Star', 'icon', 95, { pac: 97, sho: 92, pas: 83, dri: 93, def: 36, phy: 79 }, ['france', 'world-cup', 'legend']),
    v('mbappe-real-madrid-star', 'Real Madrid Star', 'icon', 96, { pac: 97, sho: 91, pas: 84, dri: 93, def: 36, phy: 79 }, ['real-madrid', 'current']),
    v('mbappe-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 99, { pac: 98, sho: 93, pas: 85, dri: 95, def: 38, phy: 80 }, ['ultimate', 'icon', 'legend']),
    v('mbappe-epic', 'Epic', 'mythic', 107, { pac: 99, sho: 96, pas: 87, dri: 96, def: 42, phy: 85 }, ['france', 'epic', 'current', 'ballon-dor'], true),
    v('mbappe-highlight', 'Highlight', 'highlight', 95, { pac: 98, sho: 92, pas: 84, dri: 93, def: 38, phy: 82 }, ['france', 'highlight']),
  ],
};

const haaland: Player = {
  id: 'haaland',
  name: 'E. Haaland',
  nationality: 'Norway',
  countryCode: 'no',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Manchester City',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('haaland-dortmund-star', 'Dortmund Star', 'epic', 86, { pac: 90, sho: 88, pas: 70, dri: 82, def: 35, phy: 84 }, ['dortmund', 'current', 'wonderkid']),
    v('haaland-man-city-star', 'Manchester City Star', 'legendary', 91, { pac: 91, sho: 94, pas: 73, dri: 84, def: 38, phy: 90 }, ['man-city', 'current', 'ucl']),
    v('haaland-norway-phenom', 'Norway Phenom', 'icon', 95, { pac: 92, sho: 95, pas: 74, dri: 85, def: 38, phy: 91 }, ['norway', 'legend']),
    v('haaland-epic', 'Epic', 'mythic', 107, { pac: 94, sho: 98, pas: 75, dri: 86, def: 42, phy: 94 }, ['norway', 'epic', 'current'], true),
    v('haaland-highlight', 'Highlight', 'highlight', 95, { pac: 92, sho: 96, pas: 74, dri: 85, def: 40, phy: 92 }, ['norway', 'highlight']),
  ],
};

const neymar: Player = {
  id: 'neymar',
  name: 'Neymar Jr',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'LW',
  altPositions: ['CAM', 'CF', 'ST'],
  club: 'Al Hilal',
  league: 'Saudi Pro League',
  isLegend: false,
  versions: [
    v('neymar-santos-wonderkid', 'Santos Wonderkid', 'rare', 80, { pac: 90, sho: 76, pas: 75, dri: 90, def: 28, phy: 60 }, ['santos', 'wonderkid', 'current']),
    v('neymar-barca-msn', 'Barcelona MSN Legend', 'icon', 96, { pac: 94, sho: 90, pas: 91, dri: 96, def: 35, phy: 68 }, ['barcelona', 'ucl', 'legend']),
    v('neymar-psg-superstar', 'PSG Superstar', 'legendary', 92, { pac: 92, sho: 86, pas: 89, dri: 94, def: 32, phy: 66 }, ['psg', 'current', 'france-league']),
    v('neymar-brazil-legend', 'Brazil Legend', 'icon', 95, { pac: 93, sho: 88, pas: 90, dri: 95, def: 33, phy: 67 }, ['brazil', 'legend']),
    v('neymar-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 99, { pac: 94, sho: 91, pas: 92, dri: 97, def: 35, phy: 68 }, ['ultimate', 'icon', 'legend']),
    v('neymar-highlight', 'Highlight', 'highlight', 95, { pac: 92, sho: 88, pas: 90, dri: 95, def: 35, phy: 70 }, ['brazil', 'highlight']),
  ],
};

const vini: Player = {
  id: 'vinijr',
  name: 'Vinícius Júnior',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'LW',
  altPositions: ['RW', 'CF'],
  club: 'Real Madrid',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('vini-real-star', 'Real Madrid Star', 'legendary', 90, { pac: 95, sho: 86, pas: 82, dri: 91, def: 32, phy: 70 }, ['real-madrid', 'current', 'ucl']),
    v('vini-brazil-star', 'Brazil Star', 'epic', 88, { pac: 95, sho: 84, pas: 80, dri: 90, def: 31, phy: 69 }, ['brazil', 'current']),
    v('vini-ucl-hero', 'Champions League Hero', 'icon', 95, { pac: 96, sho: 88, pas: 83, dri: 93, def: 33, phy: 71 }, ['real-madrid', 'ucl', 'legend']),
    v('vini-highlight', 'Highlight', 'highlight', 94, { pac: 96, sho: 88, pas: 84, dri: 94, def: 35, phy: 73 }, ['brazil', 'highlight']),
  ],
};

const bellingham: Player = {
  id: 'bellingham',
  name: 'J. Bellingham',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'CAM',
  altPositions: ['CM', 'CF'],
  club: 'Real Madrid',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('bellingham-dortmund-star', 'Dortmund Star', 'epic', 86, { pac: 78, sho: 80, pas: 83, dri: 86, def: 70, phy: 78 }, ['dortmund', 'current', 'wonderkid']),
    v('bellingham-real-star', 'Real Madrid Star', 'legendary', 91, { pac: 80, sho: 86, pas: 87, dri: 89, def: 75, phy: 84 }, ['real-madrid', 'current', 'ucl']),
    v('bellingham-england-star', 'England Star', 'icon', 94, { pac: 81, sho: 87, pas: 88, dri: 90, def: 76, phy: 85 }, ['england', 'current', 'euro']),
  ],
};

const yamal: Player = {
  id: 'yamal',
  name: 'Lamine Yamal',
  nationality: 'Spain',
  countryCode: 'es',
  position: 'RW',
  altPositions: ['CAM'],
  club: 'Barcelona',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('yamal-barca-wonderkid', 'Barcelona Wonderkid', 'epic', 85, { pac: 90, sho: 80, pas: 84, dri: 90, def: 35, phy: 65 }, ['barcelona', 'wonderkid', 'current']),
    v('yamal-spain-euro', 'Spain Euro Star', 'legendary', 90, { pac: 91, sho: 82, pas: 86, dri: 92, def: 36, phy: 66 }, ['spain', 'current', 'euro']),
    v('yamal-epic', 'Epic', 'mythic', 107, { pac: 95, sho: 92, pas: 92, dri: 97, def: 45, phy: 72 }, ['spain', 'epic', 'current', 'ballon-dor'], true),
  ],
};

const debruyne: Player = {
  id: 'debruyne',
  name: 'K. De Bruyne',
  nationality: 'Belgium',
  countryCode: 'be',
  position: 'CAM',
  altPositions: ['CM', 'RM'],
  club: 'Manchester City',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('kdb-man-city-star', 'Manchester City Star', 'legendary', 91, { pac: 75, sho: 90, pas: 95, dri: 88, def: 65, phy: 80 }, ['man-city', 'current', 'ucl']),
    v('kdb-belgium-star', 'Belgium Star', 'epic', 89, { pac: 76, sho: 88, pas: 93, dri: 87, def: 64, phy: 79 }, ['belgium', 'current']),
    v('kdb-highlight', 'Highlight', 'highlight', 95, { pac: 77, sho: 92, pas: 97, dri: 90, def: 67, phy: 82 }, ['belgium', 'highlight']),
  ],
};

const salah: Player = {
  id: 'salah',
  name: 'M. Salah',
  nationality: 'Egypt',
  countryCode: 'eg',
  position: 'RW',
  altPositions: ['ST', 'CF'],
  club: 'Liverpool',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('salah-liverpool-star', 'Liverpool Star', 'legendary', 90, { pac: 92, sho: 90, pas: 84, dri: 90, def: 45, phy: 76 }, ['liverpool', 'current', 'ucl']),
    v('salah-egypt-legend', 'Egypt Legend', 'epic', 89, { pac: 92, sho: 89, pas: 84, dri: 89, def: 45, phy: 76 }, ['egypt', 'legend']),
  ],
};

const kane: Player = {
  id: 'kane',
  name: 'H. Kane',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'ST',
  altPositions: ['CF', 'CAM'],
  club: 'Bayern München',
  league: 'Bundesliga',
  isLegend: false,
  versions: [
    v('kane-tottenham-star', 'Tottenham Star', 'epic', 89, { pac: 70, sho: 93, pas: 84, dri: 83, def: 47, phy: 84 }, ['tottenham', 'current']),
    v('kane-bayern-star', 'Bayern Star', 'legendary', 91, { pac: 71, sho: 94, pas: 85, dri: 84, def: 48, phy: 86 }, ['bayern', 'current']),
    v('kane-highlight', 'Highlight', 'highlight', 93, { pac: 72, sho: 95, pas: 86, dri: 85, def: 49, phy: 87 }, ['england', 'highlight']),
    v('kane-epic', 'Epic', 'mythic', 108, { pac: 75, sho: 99, pas: 90, dri: 88, def: 52, phy: 92 }, ['england', 'epic', 'current', 'ballon-dor'], true),
  ],
};

const rodri: Player = {
  id: 'rodri',
  name: 'Rodri',
  nationality: 'Spain',
  countryCode: 'es',
  position: 'CDM',
  altPositions: ['CM'],
  club: 'Manchester City',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('rodri-man-city-star', 'Manchester City Star', 'legendary', 91, { pac: 65, sho: 78, pas: 89, dri: 84, def: 88, phy: 88 }, ['man-city', 'current', 'ucl']),
    v('rodri-spain-euro', 'Spain Euro Champion', 'icon', 94, { pac: 66, sho: 79, pas: 90, dri: 85, def: 89, phy: 89 }, ['spain', 'current', 'euro']),
  ],
};

const saka: Player = {
  id: 'saka',
  name: 'B. Saka',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'RW',
  altPositions: ['LW', 'RM'],
  club: 'Arsenal',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('saka-arsenal-star', 'Arsenal Star', 'epic', 88, { pac: 88, sho: 84, pas: 85, dri: 87, def: 50, phy: 72 }, ['arsenal', 'current', 'wonderkid']),
  ],
};

const pedri: Player = {
  id: 'pedri',
  name: 'Pedri',
  nationality: 'Spain',
  countryCode: 'es',
  position: 'CM',
  altPositions: ['CAM'],
  club: 'Barcelona',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('pedri-barca-star', 'Barcelona Star', 'epic', 87, { pac: 78, sho: 78, pas: 88, dri: 89, def: 65, phy: 70 }, ['barcelona', 'current', 'wonderkid']),
  ],
};

const araujo: Player = {
  id: 'araujo',
  name: 'R. Araújo',
  nationality: 'Uruguay',
  countryCode: 'uy',
  position: 'CB',
  altPositions: ['RB'],
  club: 'Barcelona',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('araujo-barca-star', 'Barcelona Star', 'epic', 87, { pac: 88, sho: 40, pas: 70, dri: 72, def: 88, phy: 88 }, ['barcelona', 'current']),
  ],
};

const vandijk: Player = {
  id: 'vandijk',
  name: 'V. van Dijk',
  nationality: 'Netherlands',
  countryCode: 'nl',
  position: 'CB',
  altPositions: [],
  club: 'Liverpool',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('vandijk-liverpool-star', 'Liverpool Star', 'legendary', 90, { pac: 80, sho: 60, pas: 74, dri: 75, def: 92, phy: 88 }, ['liverpool', 'current', 'ucl']),
    v('vandijk-netherlands-star', 'Netherlands Star', 'epic', 89, { pac: 79, sho: 60, pas: 73, dri: 74, def: 91, phy: 87 }, ['netherlands', 'current']),
    v('vandijk-highlight', 'Highlight', 'highlight', 93, { pac: 82, sho: 62, pas: 76, dri: 77, def: 94, phy: 90 }, ['netherlands', 'highlight']),
  ],
};

const alisson: Player = {
  id: 'alisson',
  name: 'Alisson Becker',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'GK',
  altPositions: [],
  club: 'Liverpool',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('alisson-liverpool-star', 'Liverpool Star', 'legendary', 90, { pac: 60, sho: 30, pas: 78, dri: 50, def: 90, phy: 78 }, ['liverpool', 'current', 'ucl']),
    v('alisson-highlight', 'Highlight', 'highlight', 92, { pac: 62, sho: 32, pas: 80, dri: 52, def: 92, phy: 80 }, ['brazil', 'highlight']),
  ],
};

const courtois: Player = {
  id: 'courtois',
  name: 'T. Courtois',
  nationality: 'Belgium',
  countryCode: 'be',
  position: 'GK',
  altPositions: [],
  club: 'Real Madrid',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('courtois-real-star', 'Real Madrid Star', 'legendary', 90, { pac: 58, sho: 28, pas: 75, dri: 48, def: 91, phy: 80 }, ['real-madrid', 'current', 'ucl']),
  ],
};

// ============================================================
//  SQUAD ROTATION / COMMON-TIER PLAYERS (60-74 OVR)
//  Real players used to populate weaker AI teams for difficulty progression
// ============================================================

const ramsdale: Player = {
  id: 'ramsdale',
  name: 'A. Ramsdale',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'GK',
  altPositions: [],
  club: 'Southampton',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('ramsdale-squad', 'Squad Player', 'common', 72, { pac: 50, sho: 25, pas: 65, dri: 45, def: 73, phy: 70 }, ['current', 'england']),
  ],
};

const tierney: Player = {
  id: 'tierney',
  name: 'K. Tierney',
  nationality: 'Scotland',
  countryCode: 'gb-sct',
  position: 'LB',
  altPositions: ['LWB'],
  club: 'Arsenal',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('tierney-squad', 'Squad Player', 'common', 74, { pac: 78, sho: 35, pas: 70, dri: 72, def: 75, phy: 72 }, ['current', 'arsenal']),
  ],
};

const maguire: Player = {
  id: 'maguire',
  name: 'H. Maguire',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'CB',
  altPositions: [],
  club: 'Manchester United',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('maguire-squad', 'Squad Player', 'common', 74, { pac: 60, sho: 40, pas: 68, dri: 60, def: 76, phy: 82 }, ['current', 'man-utd']),
  ],
};

const dier: Player = {
  id: 'dier',
  name: 'E. Dier',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'CB',
  altPositions: ['CDM'],
  club: 'Bayern München',
  league: 'Bundesliga',
  isLegend: false,
  versions: [
    v('dier-squad', 'Squad Player', 'common', 72, { pac: 62, sho: 50, pas: 68, dri: 62, def: 73, phy: 78 }, ['current', 'bayern']),
  ],
};

const awb: Player = {
  id: 'awb',
  name: 'A. Wan-Bissaka',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'RB',
  altPositions: ['RWB'],
  club: 'West Ham',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('awb-squad', 'Squad Player', 'common', 73, { pac: 80, sho: 30, pas: 65, dri: 70, def: 76, phy: 72 }, ['current']),
  ],
};

const mctominay: Player = {
  id: 'mctominay',
  name: 'S. McTominay',
  nationality: 'Scotland',
  countryCode: 'gb-sct',
  position: 'CM',
  altPositions: ['CDM'],
  club: 'Napoli',
  league: 'Serie A',
  isLegend: false,
  versions: [
    v('mctominay-squad', 'Squad Player', 'common', 74, { pac: 65, sho: 70, pas: 70, dri: 70, def: 72, phy: 82 }, ['current', 'napoli']),
  ],
};

const henderson: Player = {
  id: 'henderson',
  name: 'J. Henderson',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'CM',
  altPositions: ['CDM'],
  club: 'Ajax',
  league: 'Eredivisie',
  isLegend: false,
  versions: [
    v('henderson-squad', 'Squad Player', 'common', 73, { pac: 60, sho: 60, pas: 75, dri: 70, def: 70, phy: 75 }, ['current']),
  ],
};

const eriksen: Player = {
  id: 'eriksen',
  name: 'C. Eriksen',
  nationality: 'Denmark',
  countryCode: 'dk',
  position: 'CAM',
  altPositions: ['CM'],
  club: 'Manchester United',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('eriksen-squad', 'Squad Player', 'common', 74, { pac: 60, sho: 72, pas: 80, dri: 76, def: 50, phy: 65 }, ['current', 'man-utd']),
  ],
};

const zaha: Player = {
  id: 'zaha',
  name: 'W. Zaha',
  nationality: 'Ivory Coast',
  countryCode: 'ci',
  position: 'LW',
  altPositions: ['ST'],
  club: 'Galatasaray',
  league: 'Süper Lig',
  isLegend: false,
  versions: [
    v('zaha-squad', 'Squad Player', 'common', 74, { pac: 85, sho: 72, pas: 70, dri: 82, def: 35, phy: 70 }, ['current']),
  ],
};

const werner: Player = {
  id: 'werner',
  name: 'T. Werner',
  nationality: 'Germany',
  countryCode: 'de',
  position: 'ST',
  altPositions: ['LW'],
  club: 'Tottenham',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('werner-squad', 'Squad Player', 'common', 73, { pac: 88, sho: 70, pas: 65, dri: 78, def: 35, phy: 70 }, ['current', 'tottenham']),
  ],
};

const martial: Player = {
  id: 'martial',
  name: 'A. Martial',
  nationality: 'France',
  countryCode: 'fr',
  position: 'ST',
  altPositions: ['CF', 'LW'],
  club: 'Manchester United',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('martial-squad', 'Squad Player', 'common', 72, { pac: 80, sho: 72, pas: 68, dri: 78, def: 30, phy: 72 }, ['current', 'man-utd']),
  ],
};

const adama: Player = {
  id: 'adama',
  name: 'Adama Traoré',
  nationality: 'Spain',
  countryCode: 'es',
  position: 'RW',
  altPositions: ['RM'],
  club: 'Fulham',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('adama-squad', 'Squad Player', 'common', 73, { pac: 92, sho: 65, pas: 68, dri: 80, def: 35, phy: 80 }, ['current']),
  ],
};

const jesus: Player = {
  id: 'jesus',
  name: 'Gabriel Jesus',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'ST',
  altPositions: ['CF', 'LW'],
  club: 'Arsenal',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('jesus-squad', 'Squad Player', 'common', 74, { pac: 82, sho: 75, pas: 72, dri: 80, def: 40, phy: 72 }, ['current', 'arsenal']),
  ],
};

const richarlison: Player = {
  id: 'richarlison',
  name: 'Richarlison',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'ST',
  altPositions: ['LW', 'CF'],
  club: 'Tottenham',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('richarlison-squad', 'Squad Player', 'common', 73, { pac: 80, sho: 73, pas: 65, dri: 76, def: 40, phy: 78 }, ['current', 'tottenham']),
  ],
};

const rakitic: Player = {
  id: 'rakitic',
  name: 'I. Rakitić',
  nationality: 'Croatia',
  countryCode: 'hr',
  position: 'CM',
  altPositions: ['CDM'],
  club: 'Sevilla',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('rakitic-veteran', 'Veteran', 'common', 74, { pac: 60, sho: 70, pas: 78, dri: 75, def: 65, phy: 72 }, ['current', 'sevilla']),
  ],
};

const pulisic: Player = {
  id: 'pulisic',
  name: 'C. Pulisic',
  nationality: 'USA',
  countryCode: 'us',
  position: 'RW',
  altPositions: ['LW', 'CAM'],
  club: 'AC Milan',
  league: 'Serie A',
  isLegend: false,
  versions: [
    v('pulisic-squad', 'Squad Player', 'common', 74, { pac: 85, sho: 73, pas: 73, dri: 82, def: 40, phy: 65 }, ['current', 'ac-milan']),
  ],
};

const sterling: Player = {
  id: 'sterling',
  name: 'R. Sterling',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'LW',
  altPositions: ['RW', 'CF'],
  club: 'Arsenal',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('sterling-squad', 'Squad Player', 'common', 74, { pac: 85, sho: 72, pas: 73, dri: 82, def: 40, phy: 68 }, ['current', 'arsenal']),
  ],
};

// ============================================================
//  STARTER SQUAD — YOUNG TALENTS (epic-tier rotation)
// ============================================================

const mamardashvili: Player = {
  id: 'mamardashvili',
  name: 'G. Mamardashvili',
  nationality: 'Georgia',
  countryCode: 'ge',
  position: 'GK',
  altPositions: [],
  club: 'Valencia',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('mamardashvili-star', 'Valencia Star', 'epic', 80, { pac: 55, sho: 25, pas: 70, dri: 48, def: 81, phy: 78 }, ['current', 'laliga', 'valencia']),
  ],
};

const gusto: Player = {
  id: 'gusto',
  name: 'M. Gusto',
  nationality: 'France',
  countryCode: 'fr',
  position: 'RB',
  altPositions: ['RWB', 'RM'],
  club: 'Chelsea',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('gusto-star', 'Chelsea Star', 'epic', 78, { pac: 88, sho: 55, pas: 75, dri: 80, def: 76, phy: 75 }, ['current', 'premier-league', 'chelsea']),
  ],
};

const branthwaite: Player = {
  id: 'branthwaite',
  name: 'J. Branthwaite',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'CB',
  altPositions: [],
  club: 'Everton',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('branthwaite-star', 'Everton Star', 'epic', 79, { pac: 75, sho: 35, pas: 68, dri: 65, def: 80, phy: 85 }, ['current', 'premier-league', 'everton']),
  ],
};

const antoniosilva: Player = {
  id: 'antoniosilva',
  name: 'A. Silva',
  nationality: 'Portugal',
  countryCode: 'pt',
  position: 'CB',
  altPositions: [],
  club: 'Benfica',
  league: 'Primeira Liga',
  isLegend: false,
  versions: [
    v('antoniosilva-star', 'Benfica Star', 'epic', 80, { pac: 72, sho: 35, pas: 70, dri: 68, def: 82, phy: 84 }, ['current', 'primeira-liga', 'benfica']),
  ],
};

const balde: Player = {
  id: 'balde',
  name: 'A. Baldé',
  nationality: 'Spain',
  countryCode: 'es',
  position: 'LB',
  altPositions: ['LWB', 'LM'],
  club: 'Barcelona',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('balde-star', 'Barcelona Star', 'epic', 80, { pac: 90, sho: 50, pas: 72, dri: 78, def: 76, phy: 72 }, ['current', 'laliga', 'barcelona']),
  ],
};

const mainoo: Player = {
  id: 'mainoo',
  name: 'K. Mainoo',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'CM',
  altPositions: ['CAM', 'CDM'],
  club: 'Manchester United',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('mainoo-star', 'Manchester United Star', 'epic', 79, { pac: 72, sho: 70, pas: 78, dri: 82, def: 68, phy: 72 }, ['current', 'premier-league', 'man-utd']),
  ],
};

const joaoneves: Player = {
  id: 'joaoneves',
  name: 'J. Neves',
  nationality: 'Portugal',
  countryCode: 'pt',
  position: 'CM',
  altPositions: ['CDM'],
  club: 'PSG',
  league: 'Ligue 1',
  isLegend: false,
  versions: [
    v('joaoneves-star', 'PSG Star', 'epic', 80, { pac: 70, sho: 72, pas: 82, dri: 80, def: 72, phy: 75 }, ['current', 'ligue-1', 'psg']),
  ],
};

const bakayoko: Player = {
  id: 'bakayoko',
  name: 'J. Bakayoko',
  nationality: 'France',
  countryCode: 'fr',
  position: 'LW',
  altPositions: ['LM'],
  club: 'PSV',
  league: 'Eredivisie',
  isLegend: false,
  versions: [
    v('bakayoko-star', 'PSV Star', 'epic', 78, { pac: 90, sho: 72, pas: 70, dri: 82, def: 35, phy: 68 }, ['current', 'eredivisie', 'psv']),
  ],
};

const ansufati: Player = {
  id: 'ansufati',
  name: 'A. Fati',
  nationality: 'Spain',
  countryCode: 'es',
  position: 'LW',
  altPositions: ['CF', 'ST'],
  club: 'Barcelona',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('ansufati-star', 'Barcelona Star', 'epic', 77, { pac: 85, sho: 75, pas: 70, dri: 80, def: 30, phy: 65 }, ['current', 'laliga', 'barcelona']),
  ],
};

const sesko: Player = {
  id: 'sesko',
  name: 'B. Šeško',
  nationality: 'Slovenia',
  countryCode: 'si',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Arsenal',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('sesko-star', 'Arsenal Star', 'epic', 80, { pac: 87, sho: 80, pas: 65, dri: 75, def: 35, phy: 82 }, ['current', 'premier-league', 'arsenal']),
  ],
};

const chevalier: Player = {
  id: 'chevalier',
  name: 'L. Chevalier',
  nationality: 'France',
  countryCode: 'fr',
  position: 'GK',
  altPositions: [],
  club: 'Lille',
  league: 'Ligue 1',
  isLegend: false,
  versions: [
    v('chevalier-star', 'Lille Star', 'epic', 78, { pac: 55, sho: 25, pas: 68, dri: 45, def: 79, phy: 75 }, ['current', 'ligue-1', 'lille']),
  ],
};

const lukeba: Player = {
  id: 'lukeba',
  name: 'M. Lukeba',
  nationality: 'France',
  countryCode: 'fr',
  position: 'CB',
  altPositions: [],
  club: 'RB Leipzig',
  league: 'Bundesliga',
  isLegend: false,
  versions: [
    v('lukeba-star', 'RB Leipzig Star', 'epic', 79, { pac: 78, sho: 35, pas: 72, dri: 70, def: 80, phy: 78 }, ['current', 'bundesliga', 'rb-leipzig']),
  ],
};

const archiegray: Player = {
  id: 'archiegray',
  name: 'A. Gray',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'CM',
  altPositions: ['CDM', 'CB'],
  club: 'Tottenham',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('archiegray-star', 'Tottenham Star', 'epic', 77, { pac: 70, sho: 65, pas: 75, dri: 76, def: 70, phy: 72 }, ['current', 'premier-league', 'tottenham']),
  ],
};

const nicowilliams: Player = {
  id: 'nicowilliams',
  name: 'N. Williams',
  nationality: 'Spain',
  countryCode: 'es',
  position: 'RW',
  altPositions: ['LW'],
  club: 'Athletic Bilbao',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('nicowilliams-star', 'Athletic Bilbao Star', 'epic', 80, { pac: 92, sho: 76, pas: 75, dri: 85, def: 40, phy: 70 }, ['current', 'laliga', 'athletic-bilbao']),
  ],
};

const hojlund: Player = {
  id: 'hojlund',
  name: 'R. Højlund',
  nationality: 'Denmark',
  countryCode: 'dk',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Manchester United',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('hojlund-star', 'Manchester United Star', 'epic', 79, { pac: 85, sho: 78, pas: 65, dri: 75, def: 40, phy: 80 }, ['current', 'premier-league', 'man-utd']),
  ],
};

const verratti: Player = {
  id: 'verratti',
  name: 'M. Verratti',
  nationality: 'Italy',
  countryCode: 'it',
  position: 'CM',
  altPositions: ['CDM', 'CAM'],
  club: 'Qatar SC',
  league: 'Qatar Stars League',
  isLegend: false,
  versions: [
    v('verratti-star', 'Qatar SC Star', 'epic', 84, { pac: 65, sho: 65, pas: 85, dri: 88, def: 70, phy: 65 }, ['current', 'qatar-stars-league', 'qatar-sc']),
  ],
};

const trent: Player = {
  id: 'trent',
  name: 'T. Alexander-Arnold',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'RB',
  altPositions: ['RM', 'CDM'],
  club: 'Real Madrid',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('trent-liverpool-star', 'Liverpool Star', 'epic', 87, { pac: 80, sho: 75, pas: 90, dri: 80, def: 80, phy: 75 }, ['liverpool', 'current', 'ucl']),
    v('trent-real-star', 'Real Madrid Star', 'epic', 87, { pac: 80, sho: 75, pas: 90, dri: 80, def: 80, phy: 75 }, ['real-madrid', 'current']),
  ],
};

const hakimi: Player = {
  id: 'hakimi',
  name: 'A. Hakimi',
  nationality: 'Morocco',
  countryCode: 'ma',
  position: 'RB',
  altPositions: ['RWB', 'RM'],
  club: 'PSG',
  league: 'Ligue 1',
  isLegend: false,
  versions: [
    v('hakimi-psg-star', 'PSG Star', 'epic', 86, { pac: 93, sho: 70, pas: 80, dri: 84, def: 80, phy: 78 }, ['psg', 'current', 'france-league']),
  ],
};

const dias: Player = {
  id: 'dias',
  name: 'Rúben Dias',
  nationality: 'Portugal',
  countryCode: 'pt',
  position: 'CB',
  altPositions: [],
  club: 'Manchester City',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('dias-man-city-star', 'Manchester City Star', 'epic', 88, { pac: 70, sho: 40, pas: 75, dri: 70, def: 91, phy: 88 }, ['man-city', 'current', 'ucl']),
  ],
};

// ============================================================
//  ADDITIONAL CURRENT STARS (expanded roster)
// ============================================================

const rudiger: Player = {
  id: 'rudiger',
  name: 'A. Rüdiger',
  nationality: 'Germany',
  countryCode: 'de',
  position: 'CB',
  altPositions: ['LB'],
  club: 'Real Madrid',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('rudiger-real-star', 'Real Madrid Star', 'epic', 87, { pac: 82, sho: 50, pas: 72, dri: 70, def: 88, phy: 86 }, ['real-madrid', 'current', 'ucl']),
  ],
};

const kimmich: Player = {
  id: 'kimmich',
  name: 'J. Kimmich',
  nationality: 'Germany',
  countryCode: 'de',
  position: 'CDM',
  altPositions: ['CM', 'RB'],
  club: 'Bayern München',
  league: 'Bundesliga',
  isLegend: false,
  versions: [
    v('kimmich-bayern-star', 'Bayern Star', 'epic', 88, { pac: 70, sho: 75, pas: 88, dri: 84, def: 80, phy: 78 }, ['bayern', 'current', 'ucl']),
  ],
};

const saliba: Player = {
  id: 'saliba',
  name: 'W. Saliba',
  nationality: 'France',
  countryCode: 'fr',
  position: 'CB',
  altPositions: [],
  club: 'Arsenal',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('saliba-arsenal-star', 'Arsenal Star', 'epic', 87, { pac: 85, sho: 35, pas: 70, dri: 72, def: 88, phy: 85 }, ['arsenal', 'current', 'wonderkid']),
  ],
};

const odegaard: Player = {
  id: 'odegaard',
  name: 'M. Ødegaard',
  nationality: 'Norway',
  countryCode: 'no',
  position: 'CAM',
  altPositions: ['CM', 'RW'],
  club: 'Arsenal',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('odegaard-arsenal-star', 'Arsenal Star', 'epic', 87, { pac: 76, sho: 82, pas: 88, dri: 87, def: 55, phy: 70 }, ['arsenal', 'current', 'wonderkid']),
  ],
};

const gravenberch: Player = {
  id: 'gravenberch',
  name: 'R. Gravenberch',
  nationality: 'Netherlands',
  countryCode: 'nl',
  position: 'CM',
  altPositions: ['CDM'],
  club: 'Liverpool',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('gravenberch-liverpool-star', 'Liverpool Star', 'epic', 85, { pac: 75, sho: 70, pas: 82, dri: 85, def: 72, phy: 78 }, ['liverpool', 'current', 'wonderkid']),
  ],
};

const camavinga: Player = {
  id: 'camavinga',
  name: 'E. Camavinga',
  nationality: 'France',
  countryCode: 'fr',
  position: 'CM',
  altPositions: ['CDM', 'LB'],
  club: 'Real Madrid',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('camavinga-real-star', 'Real Madrid Star', 'epic', 85, { pac: 80, sho: 68, pas: 80, dri: 84, def: 75, phy: 80 }, ['real-madrid', 'current', 'wonderkid']),
  ],
};

const valverde: Player = {
  id: 'valverde',
  name: 'F. Valverde',
  nationality: 'Uruguay',
  countryCode: 'uy',
  position: 'CM',
  altPositions: ['RM', 'CDM'],
  club: 'Real Madrid',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('valverde-real-star', 'Real Madrid Star', 'legendary', 90, { pac: 85, sho: 84, pas: 85, dri: 84, def: 78, phy: 85 }, ['real-madrid', 'current', 'ucl']),
  ],
};

const musiala: Player = {
  id: 'musiala',
  name: 'J. Musiala',
  nationality: 'Germany',
  countryCode: 'de',
  position: 'CAM',
  altPositions: ['LW', 'CF'],
  club: 'Bayern München',
  league: 'Bundesliga',
  isLegend: false,
  versions: [
    v('musiala-bayern-star', 'Bayern Star', 'legendary', 90, { pac: 85, sho: 82, pas: 84, dri: 92, def: 50, phy: 70 }, ['bayern', 'current', 'wonderkid']),
  ],
};

const wirtz: Player = {
  id: 'wirtz',
  name: 'F. Wirtz',
  nationality: 'Germany',
  countryCode: 'de',
  position: 'CAM',
  altPositions: ['CM', 'LW'],
  club: 'Bayer Leverkusen',
  league: 'Bundesliga',
  isLegend: false,
  versions: [
    v('wirtz-leverkusen-star', 'Leverkusen Star', 'epic', 88, { pac: 80, sho: 80, pas: 85, dri: 89, def: 50, phy: 70 }, ['leverkusen', 'current', 'wonderkid']),
  ],
};

const palmer: Player = {
  id: 'palmer',
  name: 'C. Palmer',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'CAM',
  altPositions: ['RW', 'CM'],
  club: 'Chelsea',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('palmer-chelsea-star', 'Chelsea Star', 'epic', 88, { pac: 78, sho: 85, pas: 85, dri: 86, def: 50, phy: 72 }, ['chelsea', 'current', 'wonderkid']),
  ],
};

const gustavo: Player = {
  id: 'gustavo',
  name: 'G. Jesus',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'ST',
  altPositions: ['LW', 'CF'],
  club: 'Arsenal',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('gustavo-arsenal-star', 'Arsenal Star', 'epic', 84, { pac: 85, sho: 80, pas: 75, dri: 85, def: 35, phy: 75 }, ['arsenal', 'current']),
  ],
};

const doku: Player = {
  id: 'doku',
  name: 'J. Doku',
  nationality: 'Belgium',
  countryCode: 'be',
  position: 'LW',
  altPositions: ['RW'],
  club: 'Manchester City',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('doku-man-city-star', 'Manchester City Star', 'epic', 84, { pac: 94, sho: 75, pas: 76, dri: 88, def: 35, phy: 70 }, ['man-city', 'current']),
  ],
};

const gvardiol: Player = {
  id: 'gvardiol',
  name: 'J. Gvardiol',
  nationality: 'Croatia',
  countryCode: 'hr',
  position: 'CB',
  altPositions: ['LB'],
  club: 'Manchester City',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('gvardiol-man-city-star', 'Manchester City Star', 'epic', 86, { pac: 80, sho: 45, pas: 72, dri: 75, def: 86, phy: 84 }, ['man-city', 'current', 'wonderkid']),
  ],
};

const onana: Player = {
  id: 'onana',
  name: 'A. Onana',
  nationality: 'Cameroon',
  countryCode: 'cm',
  position: 'GK',
  altPositions: [],
  club: 'Manchester United',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('onana-man-utd-star', 'Manchester United Star', 'epic', 85, { pac: 60, sho: 30, pas: 75, dri: 55, def: 86, phy: 78 }, ['man-utd', 'current']),
  ],
};

const maignan: Player = {
  id: 'maignan',
  name: 'M. Maignan',
  nationality: 'France',
  countryCode: 'fr',
  position: 'GK',
  altPositions: [],
  club: 'AC Milan',
  league: 'Serie A',
  isLegend: false,
  versions: [
    v('maignan-milan-star', 'AC Milan Star', 'legendary', 89, { pac: 65, sho: 30, pas: 80, dri: 55, def: 89, phy: 80 }, ['ac-milan', 'current']),
  ],
};

const lautmora: Player = {
  id: 'lautaro',
  name: 'L. Martínez',
  nationality: 'Argentina',
  countryCode: 'ar',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Inter Milan',
  league: 'Serie A',
  isLegend: false,
  versions: [
    v('lautaro-inter-star', 'Inter Star', 'legendary', 89, { pac: 82, sho: 89, pas: 78, dri: 85, def: 45, phy: 82 }, ['inter', 'current', 'ucl']),
  ],
};

const barella: Player = {
  id: 'barella',
  name: 'N. Barella',
  nationality: 'Italy',
  countryCode: 'it',
  position: 'CM',
  altPositions: ['CAM', 'CDM'],
  club: 'Inter Milan',
  league: 'Serie A',
  isLegend: false,
  versions: [
    v('barella-inter-star', 'Inter Star', 'epic', 87, { pac: 78, sho: 80, pas: 85, dri: 85, def: 75, phy: 80 }, ['inter', 'current']),
  ],
};

const dimarco: Player = {
  id: 'dimarco',
  name: 'F. Dimarco',
  nationality: 'Italy',
  countryCode: 'it',
  position: 'LB',
  altPositions: ['LWB', 'LM'],
  club: 'Inter Milan',
  league: 'Serie A',
  isLegend: false,
  versions: [
    v('dimarco-inter-star', 'Inter Star', 'epic', 86, { pac: 78, sho: 75, pas: 85, dri: 82, def: 80, phy: 78 }, ['inter', 'current']),
  ],
};

const llorente: Player = {
  id: 'llorente',
  name: 'M. Llorente',
  nationality: 'Spain',
  countryCode: 'es',
  position: 'CM',
  altPositions: ['CDM', 'RB'],
  club: 'Atlético Madrid',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('llorente-atleti-star', 'Atlético Star', 'epic', 86, { pac: 85, sho: 78, pas: 82, dri: 82, def: 78, phy: 84 }, ['atletico', 'current']),
  ],
};

const deligt: Player = {
  id: 'deligt',
  name: 'M. de Ligt',
  nationality: 'Netherlands',
  countryCode: 'nl',
  position: 'CB',
  altPositions: [],
  club: 'Manchester United',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('deligt-man-utd-star', 'Manchester United Star', 'epic', 85, { pac: 70, sho: 40, pas: 72, dri: 72, def: 87, phy: 85 }, ['man-utd', 'current']),
  ],
};

const raphinha: Player = {
  id: 'raphinha',
  name: 'Raphinha',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'RW',
  altPositions: ['LW', 'CAM'],
  club: 'Barcelona',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('raphinha-barca-star', 'Barcelona Star', 'legendary', 89, { pac: 88, sho: 85, pas: 83, dri: 87, def: 45, phy: 72 }, ['barcelona', 'current', 'ucl']),
  ],
};

const olise: Player = {
  id: 'olise',
  name: 'M. Olise',
  nationality: 'France',
  countryCode: 'fr',
  position: 'RW',
  altPositions: ['CAM', 'LW'],
  club: 'Bayern München',
  league: 'Bundesliga',
  isLegend: false,
  versions: [
    v('olise-bayern-star', 'Bayern Star', 'epic', 86, { pac: 85, sho: 80, pas: 84, dri: 87, def: 45, phy: 70 }, ['bayern', 'current', 'wonderkid']),
  ],
};

const mbopo: Player = {
  id: 'mbopo',
  name: 'B. Saka',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'RW',
  altPositions: ['LW', 'RM'],
  club: 'Arsenal',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('mbopo-arsenal-star', 'Arsenal Star', 'epic', 87, { pac: 85, sho: 82, pas: 84, dri: 86, def: 50, phy: 72 }, ['arsenal', 'current', 'wonderkid']),
  ],
};

// Additional legends
const figo: Player = {
  id: 'figo',
  name: 'L. Figo',
  nationality: 'Portugal',
  countryCode: 'pt',
  position: 'RW',
  altPositions: ['RM', 'LW'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('figo-real-legend', 'Real Madrid Legend', 'icon', 93, { pac: 88, sho: 86, pas: 90, dri: 92, def: 50, phy: 78 }, ['real-madrid', 'ucl', 'legend']),
    v('figo-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 97, { pac: 89, sho: 87, pas: 91, dri: 93, def: 52, phy: 79 }, ['ultimate', 'icon', 'legend']),
    v('figo-highlight', 'Highlight', 'highlight', 94, { pac: 90, sho: 88, pas: 92, dri: 94, def: 52, phy: 80 }, ['portugal', 'highlight']),
  ],
};

const rivaldo: Player = {
  id: 'rivaldo',
  name: 'Rivaldo',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'CAM',
  altPositions: ['LW', 'CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('rivaldo-brazil-legend', 'Brazil Legend', 'icon', 93, { pac: 85, sho: 90, pas: 88, dri: 93, def: 40, phy: 78 }, ['brazil', 'world-cup', 'legend']),
    v('rivaldo-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 96, { pac: 86, sho: 91, pas: 89, dri: 94, def: 42, phy: 79 }, ['ultimate', 'icon', 'legend']),
    v('rivaldo-highlight', 'Highlight', 'highlight', 94, { pac: 87, sho: 92, pas: 90, dri: 94, def: 42, phy: 80 }, ['brazil', 'highlight']),
  ],
};

const romario: Player = {
  id: 'romario',
  name: 'Romário',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('romario-brazil-legend', 'Brazil Legend', 'icon', 94, { pac: 88, sho: 93, pas: 80, dri: 93, def: 40, phy: 75 }, ['brazil', 'world-cup', 'legend']),
    v('romario-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 97, { pac: 89, sho: 94, pas: 81, dri: 94, def: 42, phy: 76 }, ['ultimate', 'icon', 'legend']),
    v('romario-highlight', 'Highlight', 'highlight', 95, { pac: 89, sho: 95, pas: 82, dri: 94, def: 42, phy: 78 }, ['brazil', 'highlight']),
  ],
};

const baggio: Player = {
  id: 'baggio',
  name: 'R. Baggio',
  nationality: 'Italy',
  countryCode: 'it',
  position: 'CF',
  altPositions: ['ST', 'CAM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('baggio-italy-legend', 'Italy Legend', 'icon', 93, { pac: 80, sho: 90, pas: 88, dri: 93, def: 50, phy: 72 }, ['italy', 'world-cup', 'legend']),
    v('baggio-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 96, { pac: 81, sho: 91, pas: 89, dri: 94, def: 52, phy: 73 }, ['ultimate', 'icon', 'legend']),
  ],
};

const matthaus: Player = {
  id: 'matthaus',
  name: 'L. Matthäus',
  nationality: 'Germany',
  countryCode: 'de',
  position: 'CM',
  altPositions: ['CDM', 'CAM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('matthaus-germany-legend', 'Germany Legend', 'icon', 94, { pac: 80, sho: 85, pas: 88, dri: 87, def: 80, phy: 82 }, ['germany', 'world-cup', 'legend']),
    v('matthaus-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 97, { pac: 81, sho: 86, pas: 89, dri: 88, def: 81, phy: 83 }, ['ultimate', 'icon', 'legend']),
  ],
};

const netzer: Player = {
  id: 'netzer',
  name: 'G. Netzer',
  nationality: 'Germany',
  countryCode: 'de',
  position: 'CAM',
  altPositions: ['CM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('netzer-legend', 'Germany Legend', 'icon', 91, { pac: 75, sho: 82, pas: 90, dri: 88, def: 55, phy: 75 }, ['germany', 'legend']),
  ],
};

const breitner: Player = {
  id: 'breitner',
  name: 'P. Breitner',
  nationality: 'Germany',
  countryCode: 'de',
  position: 'CM',
  altPositions: ['LB', 'CDM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('breitner-legend', 'Germany Legend', 'icon', 91, { pac: 80, sho: 82, pas: 85, dri: 82, def: 78, phy: 82 }, ['germany', 'legend', 'real-madrid']),
  ],
};

const vanderVaart: Player = {
  id: 'vandervaart',
  name: 'R. van der Vaart',
  nationality: 'Netherlands',
  countryCode: 'nl',
  position: 'CAM',
  altPositions: ['CM', 'CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('vandervaart-legend', 'Netherlands Legend', 'icon', 89, { pac: 72, sho: 82, pas: 85, dri: 85, def: 55, phy: 72 }, ['netherlands', 'legend']),
  ],
};

const bergkamp: Player = {
  id: 'bergkamp',
  name: 'D. Bergkamp',
  nationality: 'Netherlands',
  countryCode: 'nl',
  position: 'CF',
  altPositions: ['ST', 'CAM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('bergkamp-arsenal-legend', 'Arsenal Legend', 'icon', 92, { pac: 82, sho: 88, pas: 88, dri: 92, def: 45, phy: 75 }, ['arsenal', 'ucl', 'legend']),
    v('bergkamp-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 95, { pac: 83, sho: 89, pas: 89, dri: 93, def: 46, phy: 76 }, ['ultimate', 'icon', 'legend']),
    v('bergkamp-highlight', 'Highlight', 'highlight', 94, { pac: 84, sho: 90, pas: 90, dri: 94, def: 47, phy: 77 }, ['netherlands', 'highlight']),
  ],
};

const nedved: Player = {
  id: 'nedved',
  name: 'P. Nedvěd',
  nationality: 'Czech Republic',
  countryCode: 'cz',
  position: 'CAM',
  altPositions: ['CM', 'LW'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('nedved-juve-legend', 'Juventus Legend', 'icon', 91, { pac: 80, sho: 85, pas: 86, dri: 87, def: 60, phy: 75 }, ['juventus', 'ucl', 'legend']),
    v('nedved-highlight', 'Highlight', 'highlight', 92, { pac: 82, sho: 87, pas: 88, dri: 89, def: 62, phy: 77 }, ['czech-republic', 'highlight']),
  ],
};

const shevchenko: Player = {
  id: 'shevchenko',
  name: 'A. Shevchenko',
  nationality: 'Ukraine',
  countryCode: 'ua',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('shevchenko-milan-legend', 'AC Milan Legend', 'icon', 93, { pac: 87, sho: 92, pas: 80, dri: 88, def: 40, phy: 80 }, ['ac-milan', 'ucl', 'legend']),
    v('shevchenko-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 95, { pac: 88, sho: 93, pas: 81, dri: 89, def: 42, phy: 81 }, ['ultimate', 'icon', 'legend']),
  ],
};

const kaka: Player = {
  id: 'kaka',
  name: 'Kaká',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'CAM',
  altPositions: ['CF', 'ST'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('kaka-milan-legend', 'AC Milan Legend', 'icon', 95, { pac: 90, sho: 88, pas: 88, dri: 93, def: 50, phy: 78 }, ['ac-milan', 'ucl', 'legend']),
    v('kaka-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 98, { pac: 91, sho: 89, pas: 89, dri: 94, def: 52, phy: 79 }, ['ultimate', 'icon', 'legend']),
  ],
};

const ruiCosta: Player = {
  id: 'ruicosta',
  name: 'R. Costa',
  nationality: 'Portugal',
  countryCode: 'pt',
  position: 'CAM',
  altPositions: ['CM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('ruicosta-milan-legend', 'AC Milan Legend', 'icon', 90, { pac: 72, sho: 80, pas: 90, dri: 88, def: 55, phy: 72 }, ['ac-milan', 'ucl', 'legend']),
  ],
};

const seedorf: Player = {
  id: 'seedorf',
  name: 'C. Seedorf',
  nationality: 'Netherlands',
  countryCode: 'nl',
  position: 'CM',
  altPositions: ['CAM', 'CDM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('seedorf-milan-legend', 'AC Milan Legend', 'icon', 91, { pac: 78, sho: 84, pas: 86, dri: 87, def: 70, phy: 82 }, ['ac-milan', 'ucl', 'legend']),
  ],
};

// More current stars
const lewandowski: Player = {
  id: 'lewandowski',
  name: 'R. Lewandowski',
  nationality: 'Poland',
  countryCode: 'pl',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Barcelona',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('lewa-bayern-star', 'Bayern Star', 'legendary', 92, { pac: 76, sho: 94, pas: 80, dri: 86, def: 45, phy: 86 }, ['bayern', 'ucl', 'legend']),
    v('lewa-barca-star', 'Barcelona Star', 'epic', 89, { pac: 75, sho: 92, pas: 79, dri: 85, def: 44, phy: 85 }, ['barcelona', 'current']),
    v('lewa-highlight', 'Highlight', 'highlight', 94, { pac: 77, sho: 95, pas: 81, dri: 87, def: 46, phy: 87 }, ['poland', 'highlight']),
  ],
};

const modric: Player = {
  id: 'modric',
  name: 'L. Modrić',
  nationality: 'Croatia',
  countryCode: 'hr',
  position: 'CM',
  altPositions: ['CAM'],
  club: 'Real Madrid',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('modric-real-legend', 'Real Madrid Legend', 'icon', 95, { pac: 75, sho: 80, pas: 91, dri: 90, def: 72, phy: 72 }, ['real-madrid', 'ucl', 'legend']),
    v('modric-croatia-star', 'Croatia Star', 'legendary', 91, { pac: 74, sho: 78, pas: 90, dri: 89, def: 71, phy: 71 }, ['croatia', 'current', 'world-cup']),
    v('modric-highlight', 'Highlight', 'highlight', 94, { pac: 77, sho: 82, pas: 93, dri: 92, def: 74, phy: 74 }, ['croatia', 'highlight']),
  ],
};

const kroos: Player = {
  id: 'kroos',
  name: 'T. Kroos',
  nationality: 'Germany',
  countryCode: 'de',
  position: 'CM',
  altPositions: ['CDM'],
  club: 'Real Madrid',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('kroos-real-legend', 'Real Madrid Legend', 'icon', 94, { pac: 60, sho: 82, pas: 93, dri: 84, def: 75, phy: 75 }, ['real-madrid', 'ucl', 'legend']),
    v('kroos-germany-star', 'Germany Star', 'legendary', 90, { pac: 60, sho: 81, pas: 92, dri: 83, def: 74, phy: 74 }, ['germany', 'legend']),
    v('kroos-highlight', 'Highlight', 'highlight', 94, { pac: 62, sho: 84, pas: 95, dri: 86, def: 78, phy: 76 }, ['germany', 'highlight']),
  ],
};

const ramos: Player = {
  id: 'ramos',
  name: 'S. Ramos',
  nationality: 'Spain',
  countryCode: 'es',
  position: 'CB',
  altPositions: ['CDM'],
  club: 'Sevilla',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('ramos-real-legend', 'Real Madrid Legend', 'icon', 95, { pac: 75, sho: 65, pas: 76, dri: 76, def: 92, phy: 88 }, ['real-madrid', 'ucl', 'legend']),
    v('ramos-spain-star', 'Spain Star', 'legendary', 90, { pac: 74, sho: 64, pas: 75, dri: 75, def: 91, phy: 87 }, ['spain', 'legend']),
    v('ramos-highlight', 'Highlight', 'highlight', 94, { pac: 77, sho: 68, pas: 78, dri: 78, def: 93, phy: 88 }, ['spain', 'highlight']),
  ],
};

const benzema: Player = {
  id: 'benzema',
  name: 'K. Benzema',
  nationality: 'France',
  countryCode: 'fr',
  position: 'ST',
  altPositions: ['CF', 'CAM'],
  club: 'Al Ittihad',
  league: 'Saudi Pro League',
  isLegend: false,
  versions: [
    v('benzema-real-galactico', 'Real Madrid Galáctico', 'icon', 95, { pac: 80, sho: 92, pas: 88, dri: 89, def: 45, phy: 82 }, ['real-madrid', 'ucl', 'galactico', 'legend']),
    v('benzema-france-star', 'France Star', 'legendary', 90, { pac: 80, sho: 90, pas: 86, dri: 87, def: 44, phy: 81 }, ['france', 'current']),
  ],
};

const son: Player = {
  id: 'son',
  name: 'Son Heung-min',
  nationality: 'South Korea',
  countryCode: 'kr',
  position: 'LW',
  altPositions: ['ST', 'CF'],
  club: 'Tottenham',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('son-tottenham-star', 'Tottenham Star', 'epic', 88, { pac: 90, sho: 89, pas: 84, dri: 87, def: 45, phy: 73 }, ['tottenham', 'current']),
    v('son-korea-legend', 'Korea Legend', 'legendary', 90, { pac: 91, sho: 90, pas: 85, dri: 88, def: 46, phy: 74 }, ['south-korea', 'legend']),
  ],
};

const mane: Player = {
  id: 'mane',
  name: 'S. Mané',
  nationality: 'Senegal',
  countryCode: 'sn',
  position: 'LW',
  altPositions: ['ST', 'CF'],
  club: 'Al Nassr',
  league: 'Saudi Pro League',
  isLegend: false,
  versions: [
    v('mane-senegal-legend', 'Senegal Legend', 'epic', 88, { pac: 92, sho: 86, pas: 80, dri: 87, def: 40, phy: 76 }, ['senegal', 'legend']),
  ],
};

const leao: Player = {
  id: 'leao',
  name: 'R. Leão',
  nationality: 'Portugal',
  countryCode: 'pt',
  position: 'LW',
  altPositions: ['ST'],
  club: 'AC Milan',
  league: 'Serie A',
  isLegend: false,
  versions: [
    v('leao-milan-star', 'AC Milan Star', 'epic', 86, { pac: 94, sho: 82, pas: 78, dri: 88, def: 35, phy: 78 }, ['ac-milan', 'current']),
  ],
};

const hernandez: Player = {
  id: 'hernandez',
  name: 'T. Hernández',
  nationality: 'France',
  countryCode: 'fr',
  position: 'LB',
  altPositions: ['LWB'],
  club: 'AC Milan',
  league: 'Serie A',
  isLegend: false,
  versions: [
    v('hernandez-milan-star', 'AC Milan Star', 'epic', 86, { pac: 92, sho: 70, pas: 80, dri: 84, def: 78, phy: 80 }, ['ac-milan', 'current']),
  ],
};

const kvaratskhelia: Player = {
  id: 'kvara',
  name: 'K. Kvaratskhelia',
  nationality: 'Georgia',
  countryCode: 'ge',
  position: 'LW',
  altPositions: ['RW', 'CAM'],
  club: 'Napoli',
  league: 'Serie A',
  isLegend: false,
  versions: [
    v('kvara-napoli-star', 'Napoli Star', 'epic', 87, { pac: 90, sho: 82, pas: 82, dri: 90, def: 38, phy: 72 }, ['napoli', 'current', 'wonderkid']),
  ],
};

const osimhen: Player = {
  id: 'osimhen',
  name: 'V. Osimhen',
  nationality: 'Nigeria',
  countryCode: 'ng',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Napoli',
  league: 'Serie A',
  isLegend: false,
  versions: [
    v('osimhen-napoli-star', 'Napoli Star', 'epic', 89, { pac: 92, sho: 88, pas: 70, dri: 82, def: 40, phy: 84 }, ['napoli', 'current']),
  ],
};

const foden: Player = {
  id: 'foden',
  name: 'P. Foden',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'CAM',
  altPositions: ['LW', 'RW'],
  club: 'Manchester City',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('foden-man-city-star', 'Manchester City Star', 'epic', 88, { pac: 84, sho: 85, pas: 85, dri: 89, def: 55, phy: 70 }, ['man-city', 'current', 'wonderkid']),
  ],
};

const bruno: Player = {
  id: 'bruno',
  name: 'B. Fernandes',
  nationality: 'Portugal',
  countryCode: 'pt',
  position: 'CAM',
  altPositions: ['CM'],
  club: 'Manchester United',
  league: 'Premier League',
  isLegend: false,
  versions: [
    v('bruno-man-utd-star', 'Manchester United Star', 'epic', 88, { pac: 76, sho: 87, pas: 91, dri: 86, def: 60, phy: 76 }, ['man-utd', 'current']),
  ],
};

// ============================================================
//  ICONIC & LEGENDARY PLAYERS
// ============================================================

const pele: Player = {
  id: 'pele',
  name: 'Pelé',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'ST',
  altPositions: ['CF', 'CAM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('pele-santos-legend', 'Santos Legend', 'icon', 96, { pac: 92, sho: 95, pas: 88, dri: 95, def: 45, phy: 80 }, ['santos', 'legend']),
    v('pele-brazil-wc', 'Brazil World Cup Legend', 'ultimate-icon', 99, { pac: 93, sho: 96, pas: 89, dri: 96, def: 46, phy: 81 }, ['brazil', 'world-cup', 'legend']),
    v('pele-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 100, { pac: 94, sho: 97, pas: 90, dri: 97, def: 48, phy: 82 }, ['ultimate', 'icon', 'legend']),
    v('pele-epic', 'Epic', 'mythic', 107, { pac: 95, sho: 98, pas: 92, dri: 98, def: 50, phy: 85 }, ['brazil', 'epic', 'legend'], true),
  ],
};

const maradona: Player = {
  id: 'maradona',
  name: 'D. Maradona',
  nationality: 'Argentina',
  countryCode: 'ar',
  position: 'CAM',
  altPositions: ['CF', 'ST'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('maradona-argentina-1986', 'Argentina 1986 Legend', 'ultimate-icon', 99, { pac: 90, sho: 90, pas: 92, dri: 98, def: 35, phy: 70 }, ['argentina', 'world-cup', 'legend']),
    v('maradona-napoli-legend', 'Napoli Legend', 'icon', 97, { pac: 90, sho: 89, pas: 92, dri: 97, def: 34, phy: 69 }, ['napoli', 'legend']),
    v('maradona-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 100, { pac: 91, sho: 91, pas: 93, dri: 99, def: 36, phy: 71 }, ['ultimate', 'icon', 'legend']),
    v('maradona-epic', 'Epic', 'mythic', 106, { pac: 92, sho: 93, pas: 95, dri: 99, def: 40, phy: 75 }, ['argentina', 'epic', 'legend'], true),
  ],
};

const r9: Player = {
  id: 'r9',
  name: 'Ronaldo Nazário',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('r9-brazil-phenom', 'Brazil Phenom', 'icon', 97, { pac: 95, sho: 95, pas: 80, dri: 96, def: 40, phy: 84 }, ['brazil', 'world-cup', 'legend']),
    v('r9-real-galactico', 'Real Madrid Galáctico', 'icon', 96, { pac: 94, sho: 94, pas: 80, dri: 95, def: 40, phy: 84 }, ['real-madrid', 'galactico', 'legend']),
    v('r9-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 100, { pac: 96, sho: 96, pas: 81, dri: 97, def: 41, phy: 85 }, ['ultimate', 'icon', 'legend']),
    v('r9-epic', 'Epic', 'mythic', 106, { pac: 97, sho: 97, pas: 82, dri: 98, def: 45, phy: 88 }, ['brazil', 'epic', 'legend'], true),
    v('r9-highlight', 'Highlight', 'highlight', 96, { pac: 96, sho: 96, pas: 82, dri: 97, def: 42, phy: 86 }, ['brazil', 'highlight']),
  ],
};

const ronaldinho: Player = {
  id: 'ronaldinho',
  name: 'Ronaldinho',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'CAM',
  altPositions: ['LW', 'CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('ronaldinho-barca-magician', 'Barcelona Magician', 'icon', 97, { pac: 90, sho: 90, pas: 92, dri: 97, def: 40, phy: 75 }, ['barcelona', 'ucl', 'legend']),
    v('ronaldinho-brazil-legend', 'Brazil Legend', 'icon', 96, { pac: 90, sho: 89, pas: 91, dri: 96, def: 40, phy: 74 }, ['brazil', 'world-cup', 'legend']),
    v('ronaldinho-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 100, { pac: 91, sho: 91, pas: 93, dri: 98, def: 42, phy: 76 }, ['ultimate', 'icon', 'legend']),
    v('ronaldinho-epic', 'Epic', 'mythic', 106, { pac: 92, sho: 93, pas: 95, dri: 99, def: 45, phy: 80 }, ['brazil', 'epic', 'legend'], true),
  ],
};

const zidane: Player = {
  id: 'zidane',
  name: 'Z. Zidane',
  nationality: 'France',
  countryCode: 'fr',
  position: 'CAM',
  altPositions: ['CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('zidane-juve-star', 'Juventus Star', 'icon', 95, { pac: 78, sho: 88, pas: 92, dri: 95, def: 60, phy: 82 }, ['juventus', 'legend']),
    v('zidane-real-galactico', 'Real Madrid Galáctico', 'icon', 97, { pac: 78, sho: 89, pas: 93, dri: 96, def: 60, phy: 83 }, ['real-madrid', 'galactico', 'ucl', 'legend']),
    v('zidane-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 100, { pac: 79, sho: 90, pas: 94, dri: 97, def: 62, phy: 84 }, ['ultimate', 'icon', 'legend']),
    v('zidane-epic', 'Epic', 'mythic', 106, { pac: 80, sho: 92, pas: 96, dri: 98, def: 65, phy: 88 }, ['france', 'epic', 'legend'], true),
  ],
};

const cruyff: Player = {
  id: 'cruyff',
  name: 'J. Cruyff',
  nationality: 'Netherlands',
  countryCode: 'nl',
  position: 'CF',
  altPositions: ['ST', 'CAM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('cruyff-ajax-legend', 'Ajax Legend', 'icon', 96, { pac: 90, sho: 90, pas: 92, dri: 95, def: 50, phy: 72 }, ['ajax', 'ucl', 'legend']),
    v('cruyff-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 100, { pac: 91, sho: 91, pas: 93, dri: 96, def: 52, phy: 73 }, ['ultimate', 'icon', 'legend']),
    v('cruyff-highlight', 'Highlight', 'highlight', 96, { pac: 92, sho: 92, pas: 94, dri: 96, def: 54, phy: 75 }, ['netherlands', 'highlight']),
  ],
};

const beckenbauer: Player = {
  id: 'beckenbauer',
  name: 'F. Beckenbauer',
  nationality: 'Germany',
  countryCode: 'de',
  position: 'CB',
  altPositions: ['CDM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('beckenbauer-bayern-legend', 'Bayern Legend', 'icon', 96, { pac: 75, sho: 70, pas: 84, dri: 80, def: 94, phy: 84 }, ['bayern', 'ucl', 'legend']),
    v('beckenbauer-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 99, { pac: 76, sho: 71, pas: 85, dri: 81, def: 95, phy: 85 }, ['ultimate', 'icon', 'legend']),
    v('beckenbauer-epic', 'Epic', 'mythic', 106, { pac: 78, sho: 75, pas: 88, dri: 84, def: 99, phy: 88 }, ['germany', 'epic', 'legend'], true),
    v('beckenbauer-highlight', 'Highlight', 'highlight', 95, { pac: 78, sho: 72, pas: 86, dri: 82, def: 97, phy: 86 }, ['germany', 'highlight']),
  ],
};

const maldini: Player = {
  id: 'maldini',
  name: 'P. Maldini',
  nationality: 'Italy',
  countryCode: 'it',
  position: 'CB',
  altPositions: ['LB'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('maldini-milan-legend', 'AC Milan Legend', 'icon', 96, { pac: 80, sho: 50, pas: 78, dri: 78, def: 95, phy: 86 }, ['ac-milan', 'ucl', 'legend']),
    v('maldini-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 99, { pac: 81, sho: 51, pas: 79, dri: 79, def: 96, phy: 87 }, ['ultimate', 'icon', 'legend']),
    v('maldini-epic', 'Epic', 'mythic', 107, { pac: 82, sho: 55, pas: 82, dri: 82, def: 99, phy: 90 }, ['italy', 'epic', 'legend'], true),
    v('maldini-highlight', 'Highlight', 'highlight', 96, { pac: 82, sho: 52, pas: 80, dri: 80, def: 97, phy: 88 }, ['italy', 'highlight']),
  ],
};

const robertoCarlos: Player = {
  id: 'robertocarlos',
  name: 'Roberto Carlos',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'LB',
  altPositions: ['LWB', 'LM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('rc-real-galactico', 'Real Madrid Galáctico', 'icon', 95, { pac: 93, sho: 80, pas: 86, dri: 88, def: 86, phy: 84 }, ['real-madrid', 'galactico', 'ucl', 'legend']),
    v('rc-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 99, { pac: 94, sho: 81, pas: 87, dri: 89, def: 87, phy: 85 }, ['ultimate', 'icon', 'legend']),
    v('rc-highlight', 'Highlight', 'highlight', 95, { pac: 94, sho: 82, pas: 88, dri: 90, def: 88, phy: 86 }, ['brazil', 'highlight']),
  ],
};

const cafu: Player = {
  id: 'cafu',
  name: 'Cafu',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'RB',
  altPositions: ['RWB', 'RM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('cafu-brazil-legend', 'Brazil Legend', 'icon', 95, { pac: 92, sho: 65, pas: 84, dri: 86, def: 86, phy: 82 }, ['brazil', 'world-cup', 'legend']),
    v('cafu-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 98, { pac: 93, sho: 66, pas: 85, dri: 87, def: 87, phy: 83 }, ['ultimate', 'icon', 'legend']),
    v('cafu-highlight', 'Highlight', 'highlight', 95, { pac: 93, sho: 68, pas: 86, dri: 88, def: 88, phy: 84 }, ['brazil', 'highlight']),
  ],
};

const henry: Player = {
  id: 'henry',
  name: 'T. Henry',
  nationality: 'France',
  countryCode: 'fr',
  position: 'ST',
  altPositions: ['LW', 'CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('henry-arsenal-legend', 'Arsenal Legend', 'icon', 96, { pac: 95, sho: 92, pas: 86, dri: 93, def: 45, phy: 82 }, ['arsenal', 'ucl', 'legend']),
    v('henry-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 99, { pac: 96, sho: 93, pas: 87, dri: 94, def: 46, phy: 83 }, ['ultimate', 'icon', 'legend']),
    v('henry-highlight', 'Highlight', 'highlight', 96, { pac: 97, sho: 94, pas: 88, dri: 94, def: 47, phy: 84 }, ['france', 'highlight']),
  ],
};

const beckham: Player = {
  id: 'beckham',
  name: 'D. Beckham',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'RM',
  altPositions: ['CM', 'CAM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('beckham-man-utd-star', 'Manchester United Star', 'icon', 94, { pac: 75, sho: 85, pas: 95, dri: 84, def: 60, phy: 76 }, ['man-utd', 'ucl', 'legend']),
    v('beckham-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 98, { pac: 76, sho: 86, pas: 96, dri: 85, def: 62, phy: 77 }, ['ultimate', 'icon', 'legend']),
  ],
};

const iniesta: Player = {
  id: 'iniesta',
  name: 'A. Iniesta',
  nationality: 'Spain',
  countryCode: 'es',
  position: 'CM',
  altPositions: ['CAM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('iniesta-barca-legend', 'Barcelona Legend', 'icon', 96, { pac: 78, sho: 80, pas: 94, dri: 95, def: 65, phy: 72 }, ['barcelona', 'ucl', 'legend']),
    v('iniesta-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 99, { pac: 79, sho: 81, pas: 95, dri: 96, def: 66, phy: 73 }, ['ultimate', 'icon', 'legend']),
    v('iniesta-epic', 'Epic', 'mythic', 107, { pac: 80, sho: 83, pas: 97, dri: 99, def: 70, phy: 76 }, ['spain', 'epic', 'legend'], true),
  ],
};

const xavi: Player = {
  id: 'xavi',
  name: 'Xavi',
  nationality: 'Spain',
  countryCode: 'es',
  position: 'CM',
  altPositions: ['CDM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('xavi-barca-legend', 'Barcelona Legend', 'icon', 95, { pac: 70, sho: 78, pas: 95, dri: 90, def: 68, phy: 72 }, ['barcelona', 'ucl', 'legend']),
    v('xavi-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 98, { pac: 71, sho: 79, pas: 96, dri: 91, def: 69, phy: 73 }, ['ultimate', 'icon', 'legend']),
    v('xavi-epic', 'Epic', 'mythic', 106, { pac: 73, sho: 81, pas: 99, dri: 93, def: 72, phy: 76 }, ['spain', 'epic', 'legend'], true),
  ],
};

const casillas: Player = {
  id: 'casillas',
  name: 'I. Casillas',
  nationality: 'Spain',
  countryCode: 'es',
  position: 'GK',
  altPositions: [],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('casillas-real-legend', 'Real Madrid Legend', 'icon', 95, { pac: 55, sho: 25, pas: 75, dri: 50, def: 94, phy: 75 }, ['real-madrid', 'ucl', 'legend']),
    v('casillas-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 98, { pac: 56, sho: 26, pas: 76, dri: 51, def: 95, phy: 76 }, ['ultimate', 'icon', 'legend']),
    v('casillas-highlight', 'Highlight', 'highlight', 94, { pac: 58, sho: 28, pas: 78, dri: 52, def: 95, phy: 78 }, ['spain', 'highlight']),
  ],
};

const yashin: Player = {
  id: 'yashin',
  name: 'L. Yashin',
  nationality: 'Soviet Union',
  countryCode: 'ru',
  position: 'GK',
  altPositions: [],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('yashin-soviet-legend', 'Soviet Legend', 'icon', 95, { pac: 55, sho: 25, pas: 70, dri: 45, def: 95, phy: 78 }, ['soviet', 'legend']),
    v('yashin-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 98, { pac: 56, sho: 26, pas: 71, dri: 46, def: 96, phy: 79 }, ['ultimate', 'icon', 'legend']),
    v('yashin-epic', 'Epic', 'mythic', 106, { pac: 58, sho: 30, pas: 75, dri: 50, def: 99, phy: 82 }, ['soviet', 'epic', 'legend'], true),
  ],
};

const garrincha: Player = {
  id: 'garrincha',
  name: 'Garrincha',
  nationality: 'Brazil',
  countryCode: 'br',
  position: 'RW',
  altPositions: ['RM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('garrincha-brazil-legend', 'Brazil Legend', 'icon', 94, { pac: 92, sho: 82, pas: 78, dri: 95, def: 35, phy: 70 }, ['brazil', 'world-cup', 'legend']),
    v('garrincha-highlight', 'Highlight', 'highlight', 94, { pac: 93, sho: 84, pas: 80, dri: 96, def: 38, phy: 72 }, ['brazil', 'highlight']),
  ],
};

const eusebio: Player = {
  id: 'eusebio',
  name: 'Eusébio',
  nationality: 'Portugal',
  countryCode: 'pt',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('eusebio-benfica-legend', 'Benfica Legend', 'icon', 95, { pac: 92, sho: 93, pas: 84, dri: 92, def: 45, phy: 80 }, ['benfica', 'ucl', 'legend']),
    v('eusebio-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 98, { pac: 93, sho: 94, pas: 85, dri: 93, def: 46, phy: 81 }, ['ultimate', 'icon', 'legend']),
  ],
};

const puskas: Player = {
  id: 'puskas',
  name: 'F. Puskás',
  nationality: 'Hungary',
  countryCode: 'hu',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('puskas-real-legend', 'Real Madrid Legend', 'icon', 96, { pac: 82, sho: 95, pas: 86, dri: 88, def: 45, phy: 80 }, ['real-madrid', 'ucl', 'legend']),
    v('puskas-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 99, { pac: 83, sho: 96, pas: 87, dri: 89, def: 46, phy: 81 }, ['ultimate', 'icon', 'legend']),
  ],
};

const distefano: Player = {
  id: 'distefano',
  name: 'A. Di Stéfano',
  nationality: 'Argentina',
  countryCode: 'ar',
  position: 'ST',
  altPositions: ['CF', 'CAM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('distefano-real-legend', 'Real Madrid Legend', 'icon', 96, { pac: 85, sho: 92, pas: 90, dri: 92, def: 60, phy: 80 }, ['real-madrid', 'ucl', 'legend']),
    v('distefano-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 99, { pac: 86, sho: 93, pas: 91, dri: 93, def: 61, phy: 81 }, ['ultimate', 'icon', 'legend']),
  ],
};

const muller: Player = {
  id: 'muller',
  name: 'G. Müller',
  nationality: 'Germany',
  countryCode: 'de',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('muller-bayern-legend', 'Bayern Legend', 'icon', 95, { pac: 80, sho: 95, pas: 75, dri: 84, def: 40, phy: 82 }, ['bayern', 'ucl', 'legend']),
    v('muller-highlight', 'Highlight', 'highlight', 93, { pac: 82, sho: 96, pas: 78, dri: 86, def: 42, phy: 84 }, ['germany', 'highlight']),
  ],
};

const platini: Player = {
  id: 'platini',
  name: 'M. Platini',
  nationality: 'France',
  countryCode: 'fr',
  position: 'CAM',
  altPositions: ['CM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('platini-france-legend', 'France Legend', 'icon', 95, { pac: 75, sho: 90, pas: 92, dri: 90, def: 55, phy: 75 }, ['france', 'legend', 'juventus']),
    v('platini-highlight', 'Highlight', 'highlight', 94, { pac: 77, sho: 92, pas: 94, dri: 92, def: 57, phy: 77 }, ['france', 'highlight']),
  ],
};

const charlton: Player = {
  id: 'charlton',
  name: 'B. Charlton',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'CAM',
  altPositions: ['CM', 'CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('charlton-man-utd-legend', 'Manchester United Legend', 'icon', 94, { pac: 78, sho: 90, pas: 88, dri: 87, def: 60, phy: 78 }, ['man-utd', 'ucl', 'legend']),
    v('charlton-highlight', 'Highlight', 'highlight', 93, { pac: 80, sho: 92, pas: 90, dri: 89, def: 62, phy: 80 }, ['england', 'highlight']),
  ],
};

const best: Player = {
  id: 'best',
  name: 'G. Best',
  nationality: 'Northern Ireland',
  countryCode: 'gb-nir',
  position: 'RW',
  altPositions: ['LW', 'CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('best-man-utd-legend', 'Manchester United Legend', 'icon', 94, { pac: 90, sho: 88, pas: 82, dri: 93, def: 40, phy: 72 }, ['man-utd', 'ucl', 'legend']),
  ],
};

const dalglish: Player = {
  id: 'dalglish',
  name: 'K. Dalglish',
  nationality: 'Scotland',
  countryCode: 'gb-sct',
  position: 'CF',
  altPositions: ['ST', 'CAM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('dalglish-liverpool-legend', 'Liverpool Legend', 'icon', 93, { pac: 82, sho: 88, pas: 86, dri: 90, def: 50, phy: 75 }, ['liverpool', 'ucl', 'legend']),
  ],
};

const baresi: Player = {
  id: 'baresi',
  name: 'F. Baresi',
  nationality: 'Italy',
  countryCode: 'it',
  position: 'CB',
  altPositions: ['CDM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('baresi-milan-legend', 'AC Milan Legend', 'icon', 95, { pac: 70, sho: 45, pas: 76, dri: 76, def: 95, phy: 82 }, ['ac-milan', 'ucl', 'legend']),
    v('baresi-highlight', 'Highlight', 'highlight', 94, { pac: 72, sho: 47, pas: 78, dri: 78, def: 96, phy: 84 }, ['italy', 'highlight']),
  ],
};

const vanBasten: Player = {
  id: 'vanbasten',
  name: 'M. van Basten',
  nationality: 'Netherlands',
  countryCode: 'nl',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('vanbasten-milan-legend', 'AC Milan Legend', 'icon', 95, { pac: 84, sho: 94, pas: 82, dri: 90, def: 40, phy: 82 }, ['ac-milan', 'ucl', 'legend']),
    v('vanbasten-ultimate-icon', 'Ultimate Icon', 'ultimate-icon', 98, { pac: 85, sho: 95, pas: 83, dri: 91, def: 41, phy: 83 }, ['ultimate', 'icon', 'legend']),
  ],
};

const gullit: Player = {
  id: 'gullit',
  name: 'R. Gullit',
  nationality: 'Netherlands',
  countryCode: 'nl',
  position: 'CAM',
  altPositions: ['CF', 'ST'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('gullit-milan-legend', 'AC Milan Legend', 'icon', 94, { pac: 85, sho: 86, pas: 86, dri: 90, def: 70, phy: 85 }, ['ac-milan', 'ucl', 'legend']),
  ],
};

const pirlo: Player = {
  id: 'pirlo',
  name: 'A. Pirlo',
  nationality: 'Italy',
  countryCode: 'it',
  position: 'CM',
  altPositions: ['CDM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('pirlo-italy-legend', 'Italy Legend', 'icon', 93, { pac: 60, sho: 80, pas: 93, dri: 88, def: 65, phy: 70 }, ['italy', 'legend', 'juventus']),
    v('pirlo-epic', 'Epic', 'mythic', 106, { pac: 62, sho: 85, pas: 97, dri: 90, def: 68, phy: 73 }, ['italy', 'epic', 'legend'], true),
    v('pirlo-highlight', 'Highlight', 'highlight', 93, { pac: 62, sho: 82, pas: 95, dri: 90, def: 68, phy: 73 }, ['italy', 'highlight']),
  ],
};

const totti: Player = {
  id: 'totti',
  name: 'F. Totti',
  nationality: 'Italy',
  countryCode: 'it',
  position: 'CAM',
  altPositions: ['CF', 'ST'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('totti-roma-legend', 'Roma Legend', 'icon', 93, { pac: 75, sho: 88, pas: 90, dri: 89, def: 50, phy: 78 }, ['roma', 'legend']),
    v('totti-highlight', 'Highlight', 'highlight', 93, { pac: 77, sho: 90, pas: 92, dri: 91, def: 52, phy: 80 }, ['italy', 'highlight']),
  ],
};

const cannavaro: Player = {
  id: 'cannavaro',
  name: 'F. Cannavaro',
  nationality: 'Italy',
  countryCode: 'it',
  position: 'CB',
  altPositions: [],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('cannavaro-italy-legend', 'Italy Legend', 'icon', 93, { pac: 78, sho: 40, pas: 70, dri: 72, def: 93, phy: 82 }, ['italy', 'world-cup', 'legend']),
    v('cannavaro-highlight', 'Highlight', 'highlight', 93, { pac: 80, sho: 42, pas: 72, dri: 74, def: 94, phy: 84 }, ['italy', 'highlight']),
  ],
};

const lampard: Player = {
  id: 'lampard',
  name: 'F. Lampard',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'CM',
  altPositions: ['CAM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('lampard-chelsea-legend', 'Chelsea Legend', 'icon', 92, { pac: 70, sho: 88, pas: 88, dri: 84, def: 65, phy: 80 }, ['chelsea', 'ucl', 'legend']),
  ],
};

const gerrard: Player = {
  id: 'gerrard',
  name: 'S. Gerrard',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'CM',
  altPositions: ['CAM', 'CDM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('gerrard-liverpool-legend', 'Liverpool Legend', 'icon', 92, { pac: 75, sho: 86, pas: 88, dri: 84, def: 75, phy: 85 }, ['liverpool', 'ucl', 'legend']),
  ],
};

const rooney: Player = {
  id: 'rooney',
  name: 'W. Rooney',
  nationality: 'England',
  countryCode: 'gb-eng',
  position: 'ST',
  altPositions: ['CF', 'CAM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('rooney-man-utd-star', 'Manchester United Star', 'icon', 92, { pac: 80, sho: 88, pas: 84, dri: 86, def: 50, phy: 84 }, ['man-utd', 'ucl', 'legend']),
  ],
};

const drogba: Player = {
  id: 'drogba',
  name: 'D. Drogba',
  nationality: 'Ivory Coast',
  countryCode: 'ci',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('drogba-chelsea-legend', 'Chelsea Legend', 'icon', 92, { pac: 85, sho: 90, pas: 75, dri: 84, def: 45, phy: 88 }, ['chelsea', 'ucl', 'legend']),
  ],
};

const etoo: Player = {
  id: 'etoo',
  name: 'S. Eto\'o',
  nationality: 'Cameroon',
  countryCode: 'cm',
  position: 'ST',
  altPositions: ['CF', 'LW'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('etoo-cameroon-legend', 'Cameroon Legend', 'icon', 92, { pac: 90, sho: 89, pas: 78, dri: 88, def: 40, phy: 80 }, ['cameroon', 'ucl', 'legend', 'barcelona']),
    v('etoo-highlight', 'Highlight', 'highlight', 93, { pac: 92, sho: 91, pas: 80, dri: 89, def: 42, phy: 82 }, ['cameroon', 'highlight']),
  ],
};

const weah: Player = {
  id: 'weah',
  name: 'G. Weah',
  nationality: 'Liberia',
  countryCode: 'lr',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('weah-ac-milan-legend', 'AC Milan Legend', 'icon', 93, { pac: 90, sho: 90, pas: 80, dri: 90, def: 40, phy: 82 }, ['ac-milan', 'ucl', 'legend']),
  ],
};

const neuer: Player = {
  id: 'neuer',
  name: 'M. Neuer',
  nationality: 'Germany',
  countryCode: 'de',
  position: 'GK',
  altPositions: [],
  club: 'Bayern München',
  league: 'Bundesliga',
  isLegend: false,
  versions: [
    v('neuer-bayern-legend', 'Bayern Legend', 'icon', 93, { pac: 65, sho: 30, pas: 80, dri: 60, def: 92, phy: 80 }, ['bayern', 'ucl', 'legend']),
  ],
};

const lahm: Player = {
  id: 'lahm',
  name: 'P. Lahm',
  nationality: 'Germany',
  countryCode: 'de',
  position: 'RB',
  altPositions: ['LB', 'CDM'],
  club: 'Legend',
  league: 'Legend',
  isLegend: true,
  versions: [
    v('lahm-bayern-legend', 'Bayern Legend', 'icon', 92, { pac: 80, sho: 50, pas: 85, dri: 84, def: 88, phy: 75 }, ['bayern', 'ucl', 'legend']),
  ],
};

const suarez: Player = {
  id: 'suarez',
  name: 'L. Suárez',
  nationality: 'Uruguay',
  countryCode: 'uy',
  position: 'ST',
  altPositions: ['CF'],
  club: 'Inter Miami',
  league: 'MLS',
  isLegend: false,
  versions: [
    v('suarez-liverpool-star', 'Liverpool Star', 'legendary', 90, { pac: 80, sho: 91, pas: 85, dri: 88, def: 50, phy: 84 }, ['liverpool', 'legend']),
    v('suarez-barca-legend', 'Barcelona Legend', 'icon', 93, { pac: 80, sho: 92, pas: 86, dri: 89, def: 50, phy: 85 }, ['barcelona', 'ucl', 'legend']),
  ],
};

const griezmann: Player = {
  id: 'griezmann',
  name: 'A. Griezmann',
  nationality: 'France',
  countryCode: 'fr',
  position: 'CF',
  altPositions: ['ST', 'CAM'],
  club: 'Atlético Madrid',
  league: 'LaLiga',
  isLegend: false,
  versions: [
    v('griezmann-atleti-star', 'Atlético Madrid Star', 'epic', 88, { pac: 82, sho: 87, pas: 85, dri: 88, def: 50, phy: 75 }, ['atletico', 'current']),
  ],
};

// ============================================================
//  PLAYER DATABASE EXPORT
// ============================================================

export const PLAYERS: Player[] = [
  // Current superstars
  messi, ronaldo, mbappe, haaland, neymar, vini, bellingham, yamal, debruyne,
  salah, kane, rodri, saka, pedri, araujo, vandijk, alisson, courtois,
  // More current
  lewandowski, modric, kroos, ramos, benzema, son, mane, leao, hernandez,
  kvaratskhelia, osimhen, foden, bruno, suarez, griezmann, neuer,
  // Squad rotation / common-tier
  ramsdale, tierney, maguire, dier, awb, mctominay, henderson, eriksen,
  zaha, werner, martial, adama, jesus, richarlison, rakitic, pulisic, sterling,
  // Starter squad — young talents (epic-tier rotation)
  mamardashvili, gusto, branthwaite, antoniosilva, balde, mainoo, joaoneves,
  bakayoko, ansufati, sesko, chevalier, lukeba, archiegray, nicowilliams,
  hojlund, verratti,
  // More current stars (elite-tier fillers)
  trent, hakimi, dias,
  // Expanded current roster
  rudiger, kimmich, saliba, odegaard, gravenberch, camavinga, valverde,
  musiala, wirtz, palmer, gustavo, doku, gvardiol, onana, maignan,
  lautmora, barella, dimarco, llorente, deligt, raphinha, olise, mbopo,
  // Additional legends
  figo, rivaldo, romario, baggio, matthaus, netzer, breitner, vanderVaart,
  bergkamp, nedved, shevchenko, kaka, ruiCosta, seedorf,
  // Legends
  pele, maradona, r9, ronaldinho, zidane, cruyff, beckenbauer, maldini,
  robertoCarlos, cafu, henry, beckham, iniesta, xavi, casillas, yashin,
  garrincha, eusebio, puskas, distefano, muller, platini, charlton, best,
  dalglish, baresi, vanBasten, gullit, pirlo, totti, cannavaro, lampard,
  gerrard, rooney, drogba, etoo, weah, lahm,
];

// Total versions count
export const TOTAL_VERSIONS = PLAYERS.reduce((sum, p) => sum + p.versions.length, 0);

// ============================================================
//  CARD VALUE / MARKET PRICE SYSTEM
// ============================================================

/** Base market value by rarity (in coins) */
export const RARITY_BASE_VALUE: Record<Rarity, number> = {
  common: 100,
  rare: 500,
  epic: 2000,
  legendary: 6000,
  icon: 15000,
  'ultimate-icon': 40000,
  highlight: 25000,
  mythic: 75000,
};

/**
 * Calculate the market value of a card version.
 * Based on rarity base value + OVR multiplier.
 * Higher OVR within same rarity = higher value.
 */
export function cardValue(version: PlayerVersion): number {
  const base = RARITY_BASE_VALUE[version.rarity];
  // OVR multiplier: 60 OVR = 1.0x, 99 OVR = ~2.95x
  const ovrMultiplier = 1 + Math.max(0, version.ovr - 60) * 0.05;
  const value = base * ovrMultiplier;
  // Round to nearest 50 coins
  return Math.round(value / 50) * 50;
}

/** Get sell price (25% of market value — very low to encourage trading over selling) */
export function cardSellPrice(version: PlayerVersion): number {
  return Math.max(10, Math.round(cardValue(version) * 0.25 / 10) * 10);
}

/** Get market buy price (110-130% of value, with some randomness for market dynamics) */
export function cardBuyPrice(version: PlayerVersion, variance = 0.2): number {
  const markup = 1.1 + Math.random() * variance; // 110% - 130%
  return Math.round((cardValue(version) * markup) / 50) * 50;
}

/** Helper: get player by id */
export function getPlayer(playerId: string): Player | undefined {
  return PLAYERS.find((p) => p.id === playerId);
}

/** Helper: get all versions flattened */
export function getAllVersions(): { player: Player; version: Player['versions'][0] }[] {
  const result: { player: Player; version: Player['versions'][0] }[] = [];
  for (const player of PLAYERS) {
    for (const version of player.versions) {
      result.push({ player, version });
    }
  }
  return result;
}

/** Helper: get a specific version of a player */
export function getVersion(playerId: string, versionId: string) {
  const player = getPlayer(playerId);
  if (!player) return undefined;
  return player.versions.find((v) => v.id === versionId);
}

/** Generate emoji flag from ISO country code */
export function flagEmoji(countryCode: string): string {
  // Special cases for England, Scotland, Northern Ireland (not ISO)
  if (countryCode === 'gb-eng') return '🏴';
  if (countryCode === 'gb-sct') return '🏴';
  if (countryCode === 'gb-nir') return '🏴';
  if (countryCode === 'soviet') return '☭';
  const codePoints = countryCode
    .toUpperCase()
    .split('')
    .map((c) => 0x1f1e6 + c.charCodeAt(0) - 65);
  return String.fromCodePoint(...codePoints);
}

/** Rarity color/gradient metadata for UI */
export const RARITY_META: Record<
  Rarity,
  {
    label: string;
    shortLabel: string;
    gradient: string;
    border: string;
    glow: string;
    text: string;
    ovrRange: [number, number];
  }
> = {
  common: {
    label: 'Common',
    shortLabel: 'COM',
    gradient: 'linear-gradient(135deg, #4a4a4a 0%, #6e6e6e 50%, #2a2a2a 100%)',
    border: '#888',
    glow: 'rgba(150,150,150,0.5)',
    text: '#e0e0e0',
    ovrRange: [60, 74],
  },
  rare: {
    label: 'Rare',
    shortLabel: 'RAR',
    gradient: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 50%, #1e40af 100%)',
    border: '#60a5fa',
    glow: 'rgba(96,165,250,0.6)',
    text: '#dbeafe',
    ovrRange: [75, 84],
  },
  epic: {
    label: 'Epic',
    shortLabel: 'EPI',
    gradient: 'linear-gradient(135deg, #4c1d95 0%, #8b5cf6 50%, #6d28d9 100%)',
    border: '#a78bfa',
    glow: 'rgba(167,139,250,0.7)',
    text: '#ede9fe',
    ovrRange: [85, 89],
  },
  legendary: {
    label: 'Legendary',
    shortLabel: 'LEG',
    gradient: 'linear-gradient(135deg, #78350f 0%, #fbbf24 50%, #92400e 100%)',
    border: '#fcd34d',
    glow: 'rgba(251,191,36,0.8)',
    text: '#fef3c7',
    ovrRange: [90, 94],
  },
  icon: {
    label: 'Icon',
    shortLabel: 'ICO',
    gradient: 'linear-gradient(135deg, #fef3c7 0%, #fde68a 50%, #f59e0b 100%)',
    border: '#fde68a',
    glow: 'rgba(253,230,138,0.9)',
    text: '#78350f',
    ovrRange: [95, 98],
  },
  'ultimate-icon': {
    label: 'Ultimate Icon',
    shortLabel: 'ULT',
    gradient:
      'linear-gradient(135deg, #000000 0%, #1a1a1a 30%, #fbbf24 70%, #000000 100%)',
    border: '#fbbf24',
    glow: 'rgba(251,191,36,1)',
    text: '#fde68a',
    ovrRange: [99, 100],
  },
  highlight: {
    label: 'Highlight',
    shortLabel: 'HLG',
    gradient: 'linear-gradient(135deg, #b45309 0%, #fcd34d 30%, #ffffff 50%, #fcd34d 70%, #b45309 100%)',
    border: '#fcd34d',
    glow: 'rgba(252,211,77,0.9)',
    text: '#451a03',
    ovrRange: [90, 105],
  },
  mythic: {
    label: 'Epic',
    shortLabel: 'EPIC',
    gradient:
      'linear-gradient(135deg, #1a0033 0%, #4c1d95 20%, #fbbf24 40%, #dc2626 60%, #4c1d95 80%, #1a0033 100%)',
    border: '#fbbf24',
    glow: 'rgba(251,191,36,1)',
    text: '#fde68a',
    ovrRange: [106, 108],
  },
};

export const RARITY_ORDER: Rarity[] = [
  'common',
  'rare',
  'epic',
  'legendary',
  'icon',
  'ultimate-icon',
  'highlight',
  'mythic',
];

export const POSITION_GROUPS: Record<string, Position[]> = {
  GK: ['GK'],
  DEF: ['CB', 'LB', 'RB'],
  MID: ['CDM', 'CM', 'CAM', 'LM', 'RM'],
  ATT: ['LW', 'RW', 'ST', 'CF'],
};

export function positionGroup(pos: Position): 'GK' | 'DEF' | 'MID' | 'ATT' {
  for (const [group, positions] of Object.entries(POSITION_GROUPS)) {
    if (positions.includes(pos)) return group as 'GK' | 'DEF' | 'MID' | 'ATT';
  }
  return 'MID';
}
