'use client';

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { SaveState, Player, PlayerVersion, Rarity, MarketListing, TradeOffer, CardTier, CustomFormation } from './types';
import { PLAYERS, getVersion, cardValue, cardBuyPrice, cardSellPrice, getAllVersions } from './players';
import { openPack, DUPLICATE_REWARDS, PackDef } from './packs';
import { getFormation } from './formations';
import { ACHIEVEMENTS, getAchievementProgress } from './achievements';
import { BOX_PACKS, BoxPlayer, getBoxPack } from './box-packs';

// ============================================================
//  STARTER SQUAD — given to every new user (11 starters + 5 subs)
// ============================================================

export const STARTER_SQUAD: { playerId: string; versionId: string; isSubstitute: boolean }[] = [
  // Starting XI (4-3-3)
  { playerId: 'mamardashvili', versionId: 'mamardashvili-star', isSubstitute: false }, // GK
  { playerId: 'gusto', versionId: 'gusto-star', isSubstitute: false },           // RB
  { playerId: 'branthwaite', versionId: 'branthwaite-star', isSubstitute: false }, // CB
  { playerId: 'antoniosilva', versionId: 'antoniosilva-star', isSubstitute: false }, // CB
  { playerId: 'balde', versionId: 'balde-star', isSubstitute: false },           // LB
  { playerId: 'mainoo', versionId: 'mainoo-star', isSubstitute: false },         // CM
  { playerId: 'joaoneves', versionId: 'joaoneves-star', isSubstitute: false },   // CM
  { playerId: 'neymar', versionId: 'neymar-santos-wonderkid', isSubstitute: false }, // CM (rated 80)
  { playerId: 'bakayoko', versionId: 'bakayoko-star', isSubstitute: false },     // LW
  { playerId: 'ansufati', versionId: 'ansufati-star', isSubstitute: false },     // RW
  { playerId: 'sesko', versionId: 'sesko-star', isSubstitute: false },           // ST
  // Substitutes (5)
  { playerId: 'chevalier', versionId: 'chevalier-star', isSubstitute: true },    // GK
  { playerId: 'lukeba', versionId: 'lukeba-star', isSubstitute: true },          // CB
  { playerId: 'archiegray', versionId: 'archiegray-star', isSubstitute: true },  // CM
  { playerId: 'nicowilliams', versionId: 'nicowilliams-star', isSubstitute: true }, // RW
  { playerId: 'hojlund', versionId: 'hojlund-star', isSubstitute: true },        // ST
];

// ============================================================
//  DAILY REWARD CALENDAR
// ============================================================

export const DAILY_REWARDS = [
  { day: 1, coins: 200, label: 'Day 1' },
  { day: 2, coins: 300, label: 'Day 2' },
  { day: 3, coins: 400, label: 'Day 3' },
  { day: 4, coins: 500, label: 'Day 4' },
  { day: 5, coins: 700, label: 'Day 5' },
  { day: 6, coins: 1000, label: 'Day 6' },
  { day: 7, coins: 2000, label: 'Day 7 (Mega!)' },
];

// ============================================================
//  STORE
// ============================================================

interface GameStore extends SaveState {
  // --- hydration flag ---
  _hasHydrated: boolean;
  setHasHydrated: (v: boolean) => void;

  // --- collection ---
  addCards: (cards: { player: Player; version: PlayerVersion }[]) => void;
  exchangeDuplicate: (cardId: string) => void;
  exchangeAllDuplicates: () => number;
  getCardCount: (playerId: string, versionId: string) => number;
  clearNewFlags: () => void;

  // --- packs ---
  buyAndOpenPack: (pack: PackDef) => { cards: { player: Player; version: PlayerVersion }[]; success: boolean; error?: string };
  canClaimDailySpin: () => boolean;
  claimDailySpin: () => { player: Player; version: PlayerVersion } | null;

  // --- squad ---
  setFormation: (formationId: string) => void;
  setCustomFormation: (formation: { slots: { position: string; x: number; y: number }[] }) => void;
  placePlayerInSlot: (slotIndex: number, cardId: string) => void;
  removePlayerFromSlot: (slotIndex: number) => void;
  autoFillSquad: () => void;
  clearSquad: () => void;

  // --- rewards / coins ---
  addCoins: (n: number) => void;
  spendCoins: (n: number) => boolean;
  addXp: (n: number) => void;
  claimAchievement: (achievementId: string) => void;
  claimDailyLogin: () => { claimed: boolean; coins: number; day: number };

  // --- matches ---
  recordMatch: (won: boolean, draw: boolean, coins: number, xp: number) => void;

  // --- market ---
  marketListings: MarketListing[];
  marketRefreshKey: string;
  generateMarketListings: () => void;
  buyMarketCard: (listingId: string) => { success: boolean; error?: string };
  sellCard: (cardId: string) => { success: boolean; coins: number; error?: string };

  // --- trades ---
  tradeOffers: TradeOffer[];
  tradeRefreshKey: string;
  generateTradeOffers: () => void;
  acceptTrade: (offerId: string) => { success: boolean; error?: string };
  rejectTrade: (offerId: string) => void;

  // --- box draw packs ---
  boxStates: Record<string, { remaining: string[]; obtained: string[] }>;
  spinBox: (packId: string, spins: 1 | 10) => { cards: { player: Player; version: PlayerVersion; tier: CardTier }[]; success: boolean; error?: string };
  resetBox: (packId: string) => void;
  getBoxState: (packId: string) => { remaining: string[]; obtained: string[] };

  // --- starter squad ---
  starterSquadClaimed: boolean;
  claimStarterSquad: () => void;

  // --- settings ---
  updateSettings: (s: Partial<SaveState['settings']>) => void;

  // --- helpers ---
  lookupCard: (cardId: string) => { player: Player; version: PlayerVersion } | undefined;
  resolveSquad: () => ({ player: Player; version: PlayerVersion } | null)[];
  resetGame: () => void;
}

const DEFAULT_STATE: SaveState = {
  coins: 10000,
  xp: 0,
  level: 1,
  collection: [],
  formationId: '4-3-3',
  squad: new Array(11).fill(null),
  customFormation: null,
  achievementsClaimed: [],
  lastDailySpin: null,
  lastLoginReward: null,
  loginStreak: 0,
  matchesPlayed: 0,
  matchesWon: 0,
  matchesDrawn: 0,
  matchesLost: 0,
  packsOpened: 0,
  uniquePlayersCollected: [],
  boxStates: {},
  starterSquadClaimed: false,
  settings: {
    sound: true,
    animations: true,
    reduceMotion: false,
  },
};

function todayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

function daysBetween(a: string, b: string): number {
  const da = new Date(a + 'T00:00:00Z').getTime();
  const db = new Date(b + 'T00:00:00Z').getTime();
  return Math.round((db - da) / 86400000);
}

export const useGame = create<GameStore>()(
  persist(
    (set, get) => ({
      ...DEFAULT_STATE,
      _hasHydrated: false,
      setHasHydrated: (v) => set({ _hasHydrated: v }),

      addCards: (cards) =>
        set((state) => {
          const collection = [...state.collection];
          const uniquePlayers = new Set(state.uniquePlayersCollected);
          const now = new Date().toISOString();

          for (const { player, version } of cards) {
            const cardId = `${player.id}__${version.id}`;
            const existing = collection.find((c) => c.id === cardId);
            if (existing) {
              existing.count += 1;
              existing.lastAcquiredAt = now;
              existing.isNew = true;
            } else {
              collection.push({
                id: cardId,
                playerId: player.id,
                versionId: version.id,
                count: 1,
                acquiredAt: now,
                lastAcquiredAt: now,
                isNew: true,
              });
            }
            uniquePlayers.add(player.id);
          }

          return {
            collection,
            uniquePlayersCollected: Array.from(uniquePlayers),
          };
        }),

      exchangeDuplicate: (cardId) =>
        set((state) => {
          const card = state.collection.find((c) => c.id === cardId);
          if (!card || card.count <= 1) return state;
          const version = getVersion(card.playerId, card.versionId);
          if (!version) return state;
          const reward = DUPLICATE_REWARDS[version.rarity as Rarity];
          const newCollection = state.collection.map((c) =>
            c.id === cardId ? { ...c, count: c.count - 1 } : c
          );
          return {
            collection: newCollection,
            coins: state.coins + reward,
          };
        }),

      exchangeAllDuplicates: () => {
        const state = get();
        let total = 0;
        const newCollection = state.collection.map((c) => {
          if (c.count > 1) {
            const version = getVersion(c.playerId, c.versionId);
            if (version) {
              const reward = DUPLICATE_REWARDS[version.rarity as Rarity];
              total += reward * (c.count - 1);
              return { ...c, count: 1 };
            }
          }
          return c;
        });
        if (total > 0) {
          set({ collection: newCollection, coins: state.coins + total });
        }
        return total;
      },

      getCardCount: (playerId, versionId) => {
        const cardId = `${playerId}__${versionId}`;
        return get().collection.find((c) => c.id === cardId)?.count ?? 0;
      },

      clearNewFlags: () =>
        set((state) => ({
          collection: state.collection.map((c) => ({ ...c, isNew: false })),
        })),

      buyAndOpenPack: (pack) => {
        const state = get();
        if (pack.cost > 0 && state.coins < pack.cost) {
          return { cards: [], success: false, error: 'Not enough coins' };
        }
        if (pack.cost > 0) {
          set({ coins: state.coins - pack.cost });
        }
        const cards = openPack(pack);
        get().addCards(cards);
        set((s) => ({ packsOpened: s.packsOpened + 1 }));
        return { cards, success: true };
      },

      canClaimDailySpin: () => {
        const last = get().lastDailySpin;
        if (!last) return true;
        return todayKey() !== last;
      },

      claimDailySpin: () => {
        if (!get().canClaimDailySpin()) return null;
        // Use the daily spin pack logic
        const cards = openPack({
          id: 'daily-spin',
          name: 'Daily Free Spin',
          description: '',
          cost: 0,
          cardCount: 1,
          guaranteeRarity: 'rare',
          accent: '#22c55e',
          gradient: '',
          badge: 'FREE',
          category: 'daily',
        });
        if (cards.length === 0) return null;
        get().addCards(cards);
        set((s) => ({
          lastDailySpin: todayKey(),
          packsOpened: s.packsOpened + 1,
          coins: s.coins + 100, // daily spin bonus
        }));
        return cards[0];
      },

      setFormation: (formationId) =>
        set((state) => {
          // When changing formation, attempt to preserve player placements by re-mapping
          // For simplicity, clear squad on formation change (user can re-place)
          const formation = getFormation(formationId, state.customFormation);
          const oldSquad = state.squad;
          const newSquad: (string | null)[] = new Array(formation.slots.length).fill(null);
          // Try to keep players in slots with matching positions
          for (let i = 0; i < Math.min(oldSquad.length, newSquad.length); i++) {
            if (oldSquad[i]) newSquad[i] = oldSquad[i];
          }
          return { formationId, squad: newSquad };
        }),

      setCustomFormation: (formation) =>
        set((state) => {
          const customFormation: CustomFormation = {
            id: 'custom',
            name: 'Custom',
            slots: formation.slots.map((s) => ({
              position: s.position,
              x: Math.round(s.x * 100) / 100,
              y: Math.round(s.y * 100) / 100,
            })),
          };
          // Switch to the custom formation immediately and rebuild squad array to match
          const resolved = getFormation('custom', customFormation);
          const oldSquad = state.squad;
          const newSquad: (string | null)[] = new Array(resolved.slots.length).fill(null);
          for (let i = 0; i < Math.min(oldSquad.length, newSquad.length); i++) {
            if (oldSquad[i]) newSquad[i] = oldSquad[i];
          }
          return { customFormation, formationId: 'custom', squad: newSquad };
        }),

      placePlayerInSlot: (slotIndex, cardId) =>
        set((state) => {
          const squad = [...state.squad];
          // Remove this card from any other slot first
          for (let i = 0; i < squad.length; i++) {
            if (squad[i] === cardId) squad[i] = null;
          }
          squad[slotIndex] = cardId;
          return { squad };
        }),

      removePlayerFromSlot: (slotIndex) =>
        set((state) => {
          const squad = [...state.squad];
          squad[slotIndex] = null;
          return { squad };
        }),

      autoFillSquad: () =>
        set((state) => {
          const formation = getFormation(state.formationId, state.customFormation);
          const squad: (string | null)[] = new Array(formation.slots.length).fill(null);
          const usedCardIds = new Set<string>();
          const usedSlotIdx = new Set<number>();

          // Compute compatibility score for every (card, slot) pair
          const allPairs: { cardId: string; slotIdx: number; score: number; compat: number; ovr: number }[] = [];
          for (const card of state.collection) {
            const player = PLAYERS.find((p) => p.id === card.playerId);
            const version = player?.versions.find((v) => v.id === card.versionId);
            if (!player || !version) continue;
            for (let i = 0; i < formation.slots.length; i++) {
              const slotPos = formation.slots[i].position as any;
              let compat = 1.0;
              if (slotPos === player.position) compat = 1.0;
              else if (player.altPositions.includes(slotPos)) compat = 0.85;
              else if (
                (slotPos === 'GK' && player.position !== 'GK') ||
                (player.position === 'GK' && slotPos !== 'GK')
              )
                compat = 0.0;
              else compat = 0.55;
              if (compat === 0) continue;
              const score = version.ovr * compat;
              allPairs.push({ cardId: card.id, slotIdx: i, score, compat, ovr: version.ovr });
            }
          }

          // Sort pairs by score descending — place the best fits first
          allPairs.sort((a, b) => b.score - a.score);

          // Greedy assignment: take the best pair, place it, skip conflicting cards/slots
          for (const pair of allPairs) {
            if (usedCardIds.has(pair.cardId)) continue;
            if (usedSlotIdx.has(pair.slotIdx)) continue;
            // Only place if compat is reasonable (avoid putting players in terrible positions
            // unless we have to fill the squad)
            if (pair.compat < 0.55) continue;
            squad[pair.slotIdx] = pair.cardId;
            usedCardIds.add(pair.cardId);
            usedSlotIdx.add(pair.slotIdx);
          }

          return { squad };
        }),

      clearSquad: () =>
        set((state) => ({
          squad: new Array(getFormation(state.formationId, state.customFormation).slots.length).fill(null),
        })),

      addCoins: (n) => set((s) => ({ coins: s.coins + n })),
      spendCoins: (n) => {
        if (get().coins < n) return false;
        set((s) => ({ coins: s.coins - n }));
        return true;
      },
      addXp: (n) =>
        set((s) => {
          const newXp = s.xp + n;
          // Level up every 200 xp
          const newLevel = Math.floor(newXp / 200) + 1;
          return { xp: newXp, level: newLevel };
        }),

      claimAchievement: (achievementId) =>
        set((state) => {
          if (state.achievementsClaimed.includes(achievementId)) return state;
          const ach = ACHIEVEMENTS.find((a) => a.id === achievementId);
          if (!ach) return state;
          const progress = getAchievementProgress(ach, state);
          if (progress < ach.goal) return state;
          return {
            achievementsClaimed: [...state.achievementsClaimed, achievementId],
            coins: state.coins + ach.reward,
          };
        }),

      claimDailyLogin: () => {
        const state = get();
        const today = todayKey();
        if (state.lastLoginReward === today) {
          return { claimed: false, coins: 0, day: state.loginStreak };
        }
        let newStreak = 1;
        if (state.lastLoginReward) {
          const gap = daysBetween(state.lastLoginReward, today);
          if (gap === 1) newStreak = state.loginStreak + 1;
          else if (gap > 1) newStreak = 1;
          else newStreak = state.loginStreak;
        }
        if (newStreak > 7) newStreak = 1; // reset cycle
        const reward = DAILY_REWARDS[newStreak - 1];
        set({
          lastLoginReward: today,
          loginStreak: newStreak,
          coins: state.coins + reward.coins,
        });
        return { claimed: true, coins: reward.coins, day: newStreak };
      },

      recordMatch: (won, draw, coins, xp) =>
        set((s) => ({
          matchesPlayed: s.matchesPlayed + 1,
          matchesWon: s.matchesWon + (won ? 1 : 0),
          matchesDrawn: s.matchesDrawn + (draw ? 1 : 0),
          matchesLost: s.matchesLost + (!won && !draw ? 1 : 0),
          coins: s.coins + coins,
          xp: s.xp + xp,
          level: Math.floor((s.xp + xp) / 200) + 1,
        })),

      // ============================================================
      //  MARKET SYSTEM
      // ============================================================
      marketListings: [],
      marketRefreshKey: '',

      generateMarketListings: () => {
        const allVersions = getAllVersions();
        const listings: MarketListing[] = [];
        const now = new Date();
        const expires = new Date(now.getTime() + 24 * 60 * 60 * 1000); // 24 hours

        // Generate 30 random listings with better rarity distribution (more high-tier cards)
        const rarityWeights: { rarity: Rarity; weight: number }[] = [
          { rarity: 'common', weight: 10 },
          { rarity: 'rare', weight: 20 },
          { rarity: 'epic', weight: 30 },
          { rarity: 'legendary', weight: 25 },
          { rarity: 'icon', weight: 12 },
          { rarity: 'ultimate-icon', weight: 3 },
          { rarity: 'highlight', weight: 15 },
          { rarity: 'mythic', weight: 2 },
        ];
        const totalWeight = rarityWeights.reduce((s, r) => s + r.weight, 0);

        const usedIds = new Set<string>();
        for (let i = 0; i < 30; i++) {
          // Pick rarity
          let r = Math.random() * totalWeight;
          let chosenRarity: Rarity = 'common';
          for (const rw of rarityWeights) {
            r -= rw.weight;
            if (r <= 0) { chosenRarity = rw.rarity; break; }
          }
          // Pick a version of that rarity, preferring higher OVR within rarity
          const candidates = allVersions.filter(
            (v) => v.version.rarity === chosenRarity && !usedIds.has(`${v.player.id}__${v.version.id}`)
          );
          if (candidates.length === 0) continue;
          // Sort by OVR descending and prefer top half
          const sorted = candidates.sort((a, b) => b.version.ovr - a.version.ovr);
          const topHalf = sorted.slice(0, Math.max(1, Math.ceil(sorted.length / 2)));
          const pick = topHalf[Math.floor(Math.random() * topHalf.length)];
          usedIds.add(`${pick.player.id}__${pick.version.id}`);
          const price = cardBuyPrice(pick.version, 0.15);
          listings.push({
            id: `mkt-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 8)}`,
            playerId: pick.player.id,
            versionId: pick.version.id,
            price,
            createdAt: now.toISOString(),
            expiresAt: expires.toISOString(),
          });
        }
        set({ marketListings: listings, marketRefreshKey: todayKey() });
      },

      buyMarketCard: (listingId) => {
        const state = get();
        const listing = state.marketListings.find((l) => l.id === listingId);
        if (!listing) return { success: false, error: 'Listing not found' };
        if (state.coins < listing.price) return { success: false, error: 'Not enough coins' };

        const player = PLAYERS.find((p) => p.id === listing.playerId);
        const version = player?.versions.find((v) => v.id === listing.versionId);
        if (!player || !version) return { success: false, error: 'Card not found' };

        // Deduct coins, remove listing, add card
        set({
          coins: state.coins - listing.price,
          marketListings: state.marketListings.filter((l) => l.id !== listingId),
        });
        get().addCards([{ player, version }]);
        return { success: true };
      },

      sellCard: (cardId) => {
        const state = get();
        const card = state.collection.find((c) => c.id === cardId);
        if (!card || card.count <= 0) return { success: false, coins: 0, error: 'Card not found' };
        const version = getVersion(card.playerId, card.versionId);
        if (!version) return { success: false, coins: 0, error: 'Version not found' };

        const sellPrice = cardSellPrice(version);
        const newCollection = state.collection
          .map((c) => (c.id === cardId ? { ...c, count: c.count - 1 } : c))
          .filter((c) => c.count > 0);

        set({
          collection: newCollection,
          coins: state.coins + sellPrice,
        });
        return { success: true, coins: sellPrice };
      },

      // ============================================================
      //  TRADE SYSTEM
      // ============================================================
      tradeOffers: [],
      tradeRefreshKey: '',

      generateTradeOffers: () => {
        const state = get();
        const allVersions = getAllVersions();
        const offers: TradeOffer[] = [];
        const merchants = [
          { name: 'Scout Paulo', avatar: '🧑‍💼' },
          { name: 'Agent Sarah', avatar: '👩‍💼' },
          { name: 'Director Max', avatar: '👨‍💼' },
          { name: 'Broker Lena', avatar: '👩‍🦰' },
          { name: 'Trader Vic', avatar: '🧔' },
        ];

        for (let i = 0; i < 4; i++) {
          const merchant = merchants[Math.floor(Math.random() * merchants.length)];
          // Merchant gives 1 card (random rarity, weighted toward mid-tier)
          const giveRarityWeights: { rarity: Rarity; weight: number }[] = [
            { rarity: 'rare', weight: 30 },
            { rarity: 'epic', weight: 35 },
            { rarity: 'legendary', weight: 25 },
            { rarity: 'icon', weight: 8 },
            { rarity: 'ultimate-icon', weight: 2 },
          ];
          const totalW = giveRarityWeights.reduce((s, r) => s + r.weight, 0);
          let r = Math.random() * totalW;
          let giveRarity: Rarity = 'epic';
          for (const rw of giveRarityWeights) {
            r -= rw.weight;
            if (r <= 0) { giveRarity = rw.rarity; break; }
          }
          const giveCandidates = allVersions.filter((v) => v.version.rarity === giveRarity);
          if (giveCandidates.length === 0) continue;
          const givePick = giveCandidates[Math.floor(Math.random() * giveCandidates.length)];
          const giveValue = cardValue(givePick.version);

          // Merchant wants: either coins-equivalent in cards (slightly above giveValue) or a specific card
          // Strategy: merchant wants 1-2 cards from user's collection whose total value >= giveValue * 1.1
          // If user doesn't have enough, merchant wants a random card of slightly lower value
          const want: { playerId: string; versionId: string }[] = [];

          // Try to find cards from user's collection that match the value
          const userCards = state.collection
            .map((c) => {
              const entry = get().lookupCard(c.id);
              return entry ? { card: c, ...entry } : null;
            })
            .filter((x): x is NonNullable<typeof x> => x !== null);

          if (userCards.length > 0 && Math.random() > 0.3) {
            // Try to want 1-2 cards from user
            const sortedByValue = userCards.sort((a, b) => cardValue(b.version) - cardValue(a.version));
            // Pick a card with value close to giveValue * 1.1
            const targetValue = giveValue * 1.15;
            let bestCard = sortedByValue[0];
            let bestDiff = Infinity;
            for (const uc of sortedByValue) {
              const diff = Math.abs(cardValue(uc.version) - targetValue);
              if (diff < bestDiff) {
                bestDiff = diff;
                bestCard = uc;
              }
            }
            if (bestCard && cardValue(bestCard.version) >= giveValue * 0.7) {
              want.push({ playerId: bestCard.player.id, versionId: bestCard.version.id });
            }
          }

          // If no user card matched, merchant wants a random card of slightly lower rarity
          if (want.length === 0) {
            const wantRarityOrder: Record<Rarity, Rarity[]> = {
              'common': ['common'],
              'rare': ['common', 'rare'],
              'epic': ['rare', 'epic'],
              'legendary': ['epic', 'legendary'],
              'icon': ['legendary', 'icon'],
              'ultimate-icon': ['icon', 'ultimate-icon'],
            };
            const wantRarities = wantRarityOrder[giveRarity] || ['epic'];
            const wantRarity = wantRarities[Math.floor(Math.random() * wantRarities.length)];
            const wantCandidates = allVersions.filter((v) => v.version.rarity === wantRarity);
            if (wantCandidates.length > 0) {
              const wantPick = wantCandidates[Math.floor(Math.random() * wantCandidates.length)];
              want.push({ playerId: wantPick.player.id, versionId: wantPick.version.id });
            }
          }

          if (givePick && want.length > 0) {
            offers.push({
              id: `trade-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 8)}`,
              merchantName: merchant.name,
              merchantAvatar: merchant.avatar,
              give: [{ playerId: givePick.player.id, versionId: givePick.version.id }],
              want,
              createdAt: new Date().toISOString(),
              active: true,
            });
          }
        }

        set({ tradeOffers: offers, tradeRefreshKey: todayKey() });
      },

      acceptTrade: (offerId) => {
        const state = get();
        const offer = state.tradeOffers.find((o) => o.id === offerId && o.active);
        if (!offer) return { success: false, error: 'Offer not found' };

        // Check user has all wanted cards
        for (const w of offer.want) {
          const cardId = `${w.playerId}__${w.versionId}`;
          const card = state.collection.find((c) => c.id === cardId);
          if (!card || card.count < 1) {
            return { success: false, error: 'You no longer have the required card(s)' };
          }
        }

        // Remove wanted cards from user's collection
        const newCollection = [...state.collection];
        for (const w of offer.want) {
          const cardId = `${w.playerId}__${w.versionId}`;
          const idx = newCollection.findIndex((c) => c.id === cardId);
          if (idx >= 0) {
            newCollection[idx] = { ...newCollection[idx], count: newCollection[idx].count - 1 };
          }
        }
        const filteredCollection = newCollection.filter((c) => c.count > 0);

        // Add given cards
        const givenCards: { player: Player; version: PlayerVersion }[] = [];
        for (const g of offer.give) {
          const player = PLAYERS.find((p) => p.id === g.playerId);
          const version = player?.versions.find((v) => v.id === g.versionId);
          if (player && version) givenCards.push({ player, version });
        }

        // Mark offer as inactive
        const newOffers = state.tradeOffers.map((o) =>
          o.id === offerId ? { ...o, active: false } : o
        );

        set({
          collection: filteredCollection,
          tradeOffers: newOffers,
        });

        // Add given cards via addCards
        if (givenCards.length > 0) {
          get().addCards(givenCards);
        }

        return { success: true };
      },

      rejectTrade: (offerId) =>
        set((state) => ({
          tradeOffers: state.tradeOffers.map((o) =>
            o.id === offerId ? { ...o, active: false } : o
          ),
        })),

      // ============================================================
      //  BOX DRAW PACK SYSTEM
      // ============================================================
      boxStates: {},

      getBoxState: (packId) => {
        const state = get();
        const boxState = state.boxStates[packId];
        if (boxState) return boxState;
        // Initialize box state if it doesn't exist
        const pack = getBoxPack(packId);
        if (!pack) return { remaining: [], obtained: [] };
        const allVersionIds = pack.players.map((p) => `${p.playerId}__${p.versionId}`);
        return { remaining: allVersionIds, obtained: [] };
      },

      spinBox: (packId, spins) => {
        const state = get();
        const pack = getBoxPack(packId);
        if (!pack) return { cards: [], success: false, error: 'Pack not found' };

        // Initialize box state if needed
        let boxState = state.boxStates[packId];
        if (!boxState) {
          const allVersionIds = pack.players.map((p) => `${p.playerId}__${p.versionId}`);
          boxState = { remaining: allVersionIds, obtained: [] };
        }

        // Calculate cost: 100 for 1 spin, 1000 for 10 spins
        const cost = spins === 1 ? 100 : 1000;
        if (state.coins < cost) {
          return { cards: [], success: false, error: `Need ${cost - state.coins} more coins` };
        }

        // Check if enough remaining
        if (boxState.remaining.length < spins) {
          return { cards: [], success: false, error: `Only ${boxState.remaining.length} players remaining in box` };
        }

        // Randomly select from remaining pool (no duplicates)
        const remainingPool = [...boxState.remaining];
        const drawnKeys: string[] = [];
        for (let i = 0; i < spins; i++) {
          const idx = Math.floor(Math.random() * remainingPool.length);
          drawnKeys.push(remainingPool[idx]);
          remainingPool.splice(idx, 1);
        }

        // Resolve to player + version + tier
        const cards: { player: Player; version: PlayerVersion; tier: CardTier }[] = [];
        for (const key of drawnKeys) {
          const boxPlayer = pack.players.find(
            (p) => `${p.playerId}__${p.versionId}` === key
          );
          if (!boxPlayer) continue;
          const player = PLAYERS.find((p) => p.id === boxPlayer.playerId);
          const version = player?.versions.find((v) => v.id === boxPlayer.versionId);
          if (!player || !version) continue;
          cards.push({ player, version, tier: boxPlayer.tier });
        }

        // Update state: deduct coins, update box state, add cards to collection
        const newBoxState = {
          remaining: remainingPool,
          obtained: [...boxState.obtained, ...drawnKeys],
        };

        set({
          coins: state.coins - cost,
          boxStates: { ...state.boxStates, [packId]: newBoxState },
          packsOpened: state.packsOpened + spins,
        });

        // Add cards to collection
        get().addCards(cards.map((c) => ({ player: c.player, version: c.version })));

        return { cards, success: true };
      },

      resetBox: (packId) => {
        const pack = getBoxPack(packId);
        if (!pack) return;
        const allVersionIds = pack.players.map((p) => `${p.playerId}__${p.versionId}`);
        set((state) => ({
          boxStates: {
            ...state.boxStates,
            [packId]: { remaining: allVersionIds, obtained: [] },
          },
        }));
      },

      // ============================================================
      //  STARTER SQUAD
      // ============================================================
      starterSquadClaimed: false,

      claimStarterSquad: () => {
        const state = get();
        if (state.starterSquadClaimed) return;

        // Add all 16 starter players to collection
        const cards: { player: Player; version: PlayerVersion }[] = [];
        for (const s of STARTER_SQUAD) {
          const player = PLAYERS.find((p) => p.id === s.playerId);
          const version = player?.versions.find((v) => v.id === s.versionId);
          if (player && version) {
            cards.push({ player, version });
          }
        }
        get().addCards(cards);

        // Auto-fill the squad with starting XI (not substitutes)
        const formation = getFormation(state.formationId, state.customFormation);
        const squad: (string | null)[] = new Array(formation.slots.length).fill(null);
        const starters = STARTER_SQUAD.filter((s) => !s.isSubstitute);
        const usedCardIds = new Set<string>();

        // Match starters to positions
        for (let i = 0; i < formation.slots.length && i < starters.length; i++) {
          const starter = starters[i];
          const cardId = `${starter.playerId}__${starter.versionId}`;
          if (!usedCardIds.has(cardId)) {
            squad[i] = cardId;
            usedCardIds.add(cardId);
          }
        }

        set({
          starterSquadClaimed: true,
          squad,
        });
      },

      updateSettings: (s) =>
        set((state) => ({ settings: { ...state.settings, ...s } })),

      lookupCard: (cardId) => {
        const card = get().collection.find((c) => c.id === cardId);
        if (!card) return undefined;
        const player = PLAYERS.find((p) => p.id === card.playerId);
        const version = player?.versions.find((v) => v.id === card.versionId);
        if (!player || !version) return undefined;
        return { player, version };
      },

      resolveSquad: () => {
        const state = get();
        return state.squad.map((cardId) =>
          cardId ? get().lookupCard(cardId) ?? null : null
        );
      },

      resetGame: () =>
        set({
          ...DEFAULT_STATE,
          _hasHydrated: get()._hasHydrated,
          squad: new Array(11).fill(null),
        }),
    }),
    {
      name: 'fl-dream-xi-save',
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => {
        const { _hasHydrated, ...rest } = s as any;
        return rest;
      },
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      },
    }
  )
);
