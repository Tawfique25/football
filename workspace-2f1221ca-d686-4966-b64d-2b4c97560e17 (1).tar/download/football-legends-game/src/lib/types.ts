// Core type definitions for FOOTBALL LEGENDS: DREAM XI

export type Rarity =
  | 'common'
  | 'rare'
  | 'epic'
  | 'legendary'
  | 'icon'
  | 'ultimate-icon'
  | 'highlight'
  | 'mythic';

/** Box-draw card tier (independent of rarity, used for pack mechanics) */
export type CardTier = 'standard' | 'highlight' | 'epic';

export type Position =
  | 'GK'
  | 'CB'
  | 'LB'
  | 'RB'
  | 'CDM'
  | 'CM'
  | 'CAM'
  | 'LM'
  | 'RM'
  | 'LW'
  | 'RW'
  | 'ST'
  | 'CF';

export interface PlayerStats {
  pac: number; // Pace
  sho: number; // Shooting
  pas: number; // Passing
  dri: number; // Dribbling
  def: number; // Defending
  phy: number; // Physicality
}

export interface PlayerVersion {
  /** Unique id like "messi-barca-2011" */
  id: string;
  /** Display title like "2011 Barcelona Legend" */
  versionName: string;
  rarity: Rarity;
  ovr: number;
  stats: PlayerStats;
  /** Theme tags used by themed packs, e.g. ["barcelona", "argentina", "ucl"] */
  themes: string[];
  /** Whether this is a "special" version (career milestone etc.) */
  special?: boolean;
}

export interface Player {
  /** Stable id like "messi" */
  id: string;
  name: string;
  nationality: string;
  /** ISO 3166-1 alpha-2 lowercased for flag emoji generation */
  countryCode: string;
  /** Primary position (used for squad placement & chem) */
  position: Position;
  /** Alternate positions the player can play */
  altPositions: Position[];
  /** Current club or "Legend" / "Retired" */
  club: string;
  league: string;
  isLegend: boolean;
  /** Multiple collectible versions (career stages / milestones) */
  versions: PlayerVersion[];
}

export interface CollectedCard {
  /** Composite id: `${playerId}__${versionId}` */
  id: string;
  playerId: string;
  versionId: string;
  count: number;
  /** ISO timestamp of first acquisition */
  acquiredAt: string;
  /** ISO timestamp of most recent acquisition */
  lastAcquiredAt: string;
  isNew?: boolean;
}

export interface PackDef {
  id: string;
  name: string;
  description: string;
  cost: number;
  cardCount: number;
  /** Theme tags - if set, only players whose version matches these themes are eligible */
  themes?: string[];
  /** Per-rarity probability weights (must sum to ~1.0). If undefined, uses standard distribution */
  rarityWeights?: Partial<Record<Rarity, number>>;
  /** If true, guarantees at least one card of the minimum rarity listed */
  guaranteeRarity?: Rarity;
  /** Visual accent color for the pack art */
  accent: string;
  /** Background gradient for the pack art */
  gradient: string;
  /** Optional badge text */
  badge?: string;
  /** Category: standard | premium | icon | themed | daily */
  category: 'daily' | 'standard' | 'premium' | 'icon' | 'themed';
}

export interface FormationSlot {
  position: Position;
  /** x,y as percentages of pitch (0-100) */
  x: number;
  y: number;
}

export interface FormationDef {
  id: string;
  name: string;
  slots: FormationSlot[];
}

export interface SquadSlot {
  /** Composite card id, or null if empty */
  cardId: string | null;
}

export interface MatchEvent {
  minute: number;
  type: 'goal' | 'yellow' | 'red' | 'sub' | 'chance' | 'save' | 'info';
  team: 'home' | 'away';
  text: string;
  scorer?: string;
  assist?: string;
}

export interface MatchResult {
  homeScore: number;
  awayScore: number;
  events: MatchEvent[];
  homeStats: { possession: number; shots: number; onTarget: number };
  awayStats: { possession: number; shots: number; onTarget: number };
  homeRating: number;
  awayRating: number;
  chemistryHome: number;
  rewards: { coins: number; xp: number };
  won: boolean;
  draw: boolean;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  goal: number;
  reward: number;
  /** progress is computed dynamically from save state */
  progressFn: (state: SaveState) => number;
  /** is achieved when progress >= goal */
}

/** User-designed custom formation (persisted across sessions) */
export interface CustomFormation {
  id: string;
  name: string;
  slots: { position: string; x: number; y: number }[];
}

export interface SaveState {
  coins: number;
  xp: number;
  level: number;
  collection: CollectedCard[];
  /** selected formation id */
  formationId: string;
  /** squad slots, length matches formation */
  squad: (string | null)[];
  /** user-designed custom formation (null until first saved) */
  customFormation: CustomFormation | null;
  achievementsClaimed: string[];
  /** ISO date string of last daily spin */
  lastDailySpin: string | null;
  /** ISO date string of last daily login reward */
  lastLoginReward: string | null;
  /** streak count of consecutive daily logins */
  loginStreak: number;
  /** matches played */
  matchesPlayed: number;
  matchesWon: number;
  matchesDrawn: number;
  matchesLost: number;
  packsOpened: number;
  /** player ids that have been collected at any point (for achievement tracking) */
  uniquePlayersCollected: string[];
  /** Box draw pack states: packId -> { remaining versionIds, obtained versionIds } */
  boxStates: Record<string, { remaining: string[]; obtained: string[] }>;
  /** Whether the starter squad has been claimed */
  starterSquadClaimed: boolean;
  settings: {
    sound: boolean;
    animations: boolean;
    reduceMotion: boolean;
  };
}

// ============================================================
//  MARKET & TRADE TYPES
// ============================================================

/** A card listed for sale on the transfer market */
export interface MarketListing {
  id: string;
  playerId: string;
  versionId: string;
  price: number;
  /** ISO date when listing was created */
  createdAt: string;
  /** ISO date when listing expires */
  expiresAt: string;
}

/** A trade offer from an NPC merchant */
export interface TradeOffer {
  id: string;
  merchantName: string;
  merchantAvatar: string;
  /** What the merchant gives you */
  give: { playerId: string; versionId: string }[];
  /** What the merchant wants from you */
  want: { playerId: string; versionId: string }[];
  /** ISO date when offer was created */
  createdAt: string;
  /** Whether the offer is still active */
  active: boolean;
}

/** User profile for authentication */
export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  createdAt: string;
  lastLoginAt: string;
}
