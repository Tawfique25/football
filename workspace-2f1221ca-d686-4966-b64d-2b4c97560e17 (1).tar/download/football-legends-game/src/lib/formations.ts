import { FormationDef, Position, Player, PlayerVersion, CustomFormation } from './types';

// ============================================================
//  FORMATIONS
// ============================================================

export const FORMATIONS: FormationDef[] = [
  {
    id: '4-3-3',
    name: '4-3-3',
    slots: [
      { position: 'GK', x: 50, y: 92 },
      { position: 'LB', x: 15, y: 73 },
      { position: 'CB', x: 38, y: 76 },
      { position: 'CB', x: 62, y: 76 },
      { position: 'RB', x: 85, y: 73 },
      { position: 'CM', x: 28, y: 50 },
      { position: 'CM', x: 50, y: 53 },
      { position: 'CM', x: 72, y: 50 },
      { position: 'LW', x: 18, y: 22 },
      { position: 'ST', x: 50, y: 17 },
      { position: 'RW', x: 82, y: 22 },
    ],
  },
  {
    id: '4-2-3-1',
    name: '4-2-3-1',
    slots: [
      { position: 'GK', x: 50, y: 92 },
      { position: 'LB', x: 15, y: 73 },
      { position: 'CB', x: 38, y: 76 },
      { position: 'CB', x: 62, y: 76 },
      { position: 'RB', x: 85, y: 73 },
      { position: 'CDM', x: 35, y: 58 },
      { position: 'CDM', x: 65, y: 58 },
      { position: 'LM', x: 18, y: 35 },
      { position: 'CAM', x: 50, y: 33 },
      { position: 'RM', x: 82, y: 35 },
      { position: 'ST', x: 50, y: 14 },
    ],
  },
  {
    id: '4-4-2',
    name: '4-4-2',
    slots: [
      { position: 'GK', x: 50, y: 92 },
      { position: 'LB', x: 15, y: 73 },
      { position: 'CB', x: 38, y: 76 },
      { position: 'CB', x: 62, y: 76 },
      { position: 'RB', x: 85, y: 73 },
      { position: 'LM', x: 15, y: 45 },
      { position: 'CM', x: 38, y: 48 },
      { position: 'CM', x: 62, y: 48 },
      { position: 'RM', x: 85, y: 45 },
      { position: 'ST', x: 38, y: 18 },
      { position: 'ST', x: 62, y: 18 },
    ],
  },
  {
    id: '3-5-2',
    name: '3-5-2',
    slots: [
      { position: 'GK', x: 50, y: 92 },
      { position: 'CB', x: 28, y: 76 },
      { position: 'CB', x: 50, y: 78 },
      { position: 'CB', x: 72, y: 76 },
      { position: 'LM', x: 12, y: 50 },
      { position: 'CDM', x: 35, y: 55 },
      { position: 'CM', x: 50, y: 45 },
      { position: 'CM', x: 65, y: 55 },
      { position: 'RM', x: 88, y: 50 },
      { position: 'ST', x: 38, y: 18 },
      { position: 'ST', x: 62, y: 18 },
    ],
  },
  {
    id: '4-1-2-1-2',
    name: '4-1-2-1-2',
    slots: [
      { position: 'GK', x: 50, y: 92 },
      { position: 'LB', x: 15, y: 73 },
      { position: 'CB', x: 38, y: 76 },
      { position: 'CB', x: 62, y: 76 },
      { position: 'RB', x: 85, y: 73 },
      { position: 'CDM', x: 50, y: 60 },
      { position: 'LM', x: 22, y: 45 },
      { position: 'RM', x: 78, y: 45 },
      { position: 'CAM', x: 50, y: 35 },
      { position: 'ST', x: 38, y: 16 },
      { position: 'ST', x: 62, y: 16 },
    ],
  },
  {
    id: '5-3-2',
    name: '5-3-2',
    slots: [
      { position: 'GK', x: 50, y: 92 },
      { position: 'LWB', x: 12, y: 65 },
      { position: 'CB', x: 30, y: 76 },
      { position: 'CB', x: 50, y: 78 },
      { position: 'CB', x: 70, y: 76 },
      { position: 'RWB', x: 88, y: 65 },
      { position: 'CM', x: 28, y: 45 },
      { position: 'CM', x: 50, y: 48 },
      { position: 'CM', x: 72, y: 45 },
      { position: 'ST', x: 38, y: 18 },
      { position: 'ST', x: 62, y: 18 },
    ],
  },
];

export function getFormation(id: string, customFormation?: CustomFormation | null): FormationDef {
  if (id === 'custom' && customFormation && customFormation.slots.length > 0) {
    return {
      id: 'custom',
      name: customFormation.name || 'Custom',
      slots: customFormation.slots.map((s) => ({
        position: s.position as Position,
        x: s.x,
        y: s.y,
      })),
    };
  }
  if (id === 'custom') {
    // No custom formation saved yet — fall back to default so the UI doesn't crash
    return FORMATIONS[0];
  }
  return FORMATIONS.find((f) => f.id === id) ?? FORMATIONS[0];
}

// ============================================================
//  POSITION COMPATIBILITY
// ============================================================

const POSITION_FAMILIES: Record<string, string[]> = {
  // Goalkeepers
  GK: ['GK'],
  // Defenders
  CB: ['CB'],
  LB: ['LB', 'LWB', 'LM'],
  RB: ['RB', 'RWB', 'RM'],
  LWB: ['LWB', 'LB', 'LM'],
  RWB: ['RWB', 'RB', 'RM'],
  // Defensive mid
  CDM: ['CDM', 'CM'],
  // Central mid
  CM: ['CM', 'CDM', 'CAM'],
  // Attacking mid
  CAM: ['CAM', 'CM', 'CF'],
  // Wide mid
  LM: ['LM', 'LW', 'LB'],
  RM: ['RM', 'RW', 'RB'],
  // Wings
  LW: ['LW', 'LM', 'CF', 'ST'],
  RW: ['RW', 'RM', 'CF', 'ST'],
  // Strikers
  ST: ['ST', 'CF'],
  CF: ['CF', 'ST', 'CAM'],
};

/**
 * Returns position compatibility score 0..1.
 * 1.0 = perfect natural fit, 0.85 = alt position, 0.7 = close family, 0.6 = same group, 0.3 = poor
 */
export function positionCompatibility(
  slotPos: Position,
  playerPos: Position,
  altPositions: Position[]
): number {
  if (slotPos === playerPos) return 1.0;
  if (altPositions.includes(slotPos)) return 0.85;
  const family = POSITION_FAMILIES[playerPos] ?? [playerPos];
  if (family.includes(slotPos)) return 0.72;
  // Same group (DEF/MID/ATT) check
  const groupOf = (p: Position): 'GK' | 'DEF' | 'MID' | 'ATT' => {
    if (p === 'GK') return 'GK';
    if (['CB', 'LB', 'RB', 'LWB', 'RWB'].includes(p)) return 'DEF';
    if (['CDM', 'CM', 'CAM', 'LM', 'RM'].includes(p)) return 'MID';
    return 'ATT';
  };
  if (groupOf(slotPos) === groupOf(playerPos)) return 0.6;
  // Outfield player in GK slot or vice versa = very poor
  if (groupOf(slotPos) === 'GK' || groupOf(playerPos) === 'GK') return 0.1;
  return 0.35;
}

/** Effective rating of a player in a slot — penalised for out-of-position.
 *  Formula: ovr * (0.7 + 0.3 * compat) so even out-of-position keeps 70-79% of rating. */
export function effectiveRating(
  version: PlayerVersion,
  slotPos: Position,
  player: Player
): number {
  const compat = positionCompatibility(slotPos, player.position, player.altPositions);
  return Math.round(version.ovr * (0.7 + 0.3 * compat));
}

// ============================================================
//  CHEMISTRY SYSTEM
// ============================================================

export interface ChemistryResult {
  /** 0-100 overall chemistry */
  overall: number;
  /** Per-player chemistry contribution */
  perSlot: number[];
  /** Pairs of slot indices that have a strong link, for visualization */
  links: { from: number; to: number; strength: number }[];
}

/**
 * Calculate team chemistry based on shared nationality, club, league, and position compatibility.
 */
export function calculateChemistry(
  formationId: string,
  squad: ({ player: Player; version: PlayerVersion } | null)[],
  customFormation?: CustomFormation | null
): ChemistryResult {
  const formation = getFormation(formationId, customFormation);

  // Position compat for each filled slot
  const slotScores: number[] = squad.map((entry, i) => {
    if (!entry) return 0;
    const slotPos = formation.slots[i].position;
    const compat = positionCompatibility(slotPos, entry.player.position, entry.player.altPositions);
    return compat;
  });

  // Chemistry links: connect each player to nearby players (within a distance threshold on the pitch)
  // Then count shared attributes (nationality, club, league)
  const links: { from: number; to: number; strength: number }[] = [];
  const linkDist = 35; // % of pitch
  const perSlotChem: number[] = squad.map((s) => (s ? 0.5 : 0));

  for (let i = 0; i < squad.length; i++) {
    const a = squad[i];
    if (!a) continue;
    const slotA = formation.slots[i];
    for (let j = i + 1; j < squad.length; j++) {
      const b = squad[j];
      if (!b) continue;
      const slotB = formation.slots[j];
      const dx = slotA.x - slotB.x;
      const dy = slotA.y - slotB.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist > linkDist) continue;

      let strength = 0;
      if (a.player.nationality === b.player.nationality) strength += 1;
      if (a.player.club === b.player.club && a.player.club !== 'Legend' && a.player.club !== 'Retired') strength += 1.2;
      if (a.player.league === b.player.league && a.player.league !== 'Legend') strength += 0.5;

      if (strength > 0) {
        links.push({ from: i, to: j, strength: Math.min(strength, 2.7) });
        perSlotChem[i] += strength * 0.4;
        perSlotChem[j] += strength * 0.4;
      }
    }
  }

  // Cap per-slot chem at 1.0, combine with position compat
  const combined: number[] = squad.map((s, i) => {
    if (!s) return 0;
    const posScore = slotScores[i];
    const chemScore = Math.min(perSlotChem[i], 1.0);
    // Weighted: position compat matters most, then chem
    return 0.55 * posScore + 0.45 * chemScore;
  });

  const filled = combined.filter((c) => c > 0);
  const overall =
    filled.length === 0 ? 0 : Math.round((filled.reduce((s, c) => s + c, 0) / 11) * 100);

  return {
    overall: Math.min(100, overall),
    perSlot: combined.map((c) => Math.round(c * 100)),
    links,
  };
}

// ============================================================
//  TEAM RATINGS
// ============================================================

export interface TeamRating {
  overall: number;
  attack: number;
  midfield: number;
  defense: number;
  chemistry: number;
  filled: number;
}

export function calculateTeamRating(
  formationId: string,
  squad: ({ player: Player; version: PlayerVersion } | null)[],
  customFormation?: CustomFormation | null
): TeamRating {
  const formation = getFormation(formationId, customFormation);
  const chem = calculateChemistry(formationId, squad, customFormation);

  let attackSum = 0;
  let attackN = 0;
  let midSum = 0;
  let midN = 0;
  let defSum = 0;
  let defN = 0;
  let overallSum = 0;
  let overallN = 0;
  let filled = 0;

  squad.forEach((entry, i) => {
    if (!entry) return;
    filled++;
    const slotPos = formation.slots[i].position;
    const eff = effectiveRating(entry.version, slotPos, entry.player);
    overallSum += eff;
    overallN++;

    const group = (() => {
      if (slotPos === 'GK') return 'GK';
      if (['CB', 'LB', 'RB', 'LWB', 'RWB'].includes(slotPos)) return 'DEF';
      if (['CDM', 'CM', 'CAM', 'LM', 'RM'].includes(slotPos)) return 'MID';
      return 'ATT';
    })();

    if (group === 'ATT') {
      attackSum += eff;
      attackN++;
    } else if (group === 'MID') {
      midSum += eff;
      midN++;
    } else {
      defSum += eff;
      defN++;
    }
  });

  // Apply chemistry boost to overall (capped to keep ratings realistic)
  const chemBoost = 1 + (chem.overall / 100) * 0.05; // up to +5%
  const rawOverall = overallN > 0 ? overallSum / overallN : 0;
  const overall = Math.min(99, Math.round(rawOverall * chemBoost));
  const attack = Math.min(99, attackN > 0 ? Math.round((attackSum / attackN) * chemBoost) : 0);
  const midfield = Math.min(99, midN > 0 ? Math.round((midSum / midN) * chemBoost) : 0);
  const defense = Math.min(99, defN > 0 ? Math.round((defSum / defN) * chemBoost) : 0);

  return {
    overall,
    attack,
    midfield,
    defense,
    chemistry: chem.overall,
    filled,
  };
}
