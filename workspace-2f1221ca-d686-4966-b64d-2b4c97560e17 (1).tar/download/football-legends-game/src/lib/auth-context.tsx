'use client';

import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import {
  User,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  updateProfile,
} from 'firebase/auth';
import {
  doc,
  setDoc,
  getDoc,
  serverTimestamp,
} from 'firebase/firestore';
import { auth, db, isFirebaseConfigured } from './firebase';
import { UserProfile } from './types';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  isFirebaseReady: boolean;
  signUp: (email: string, password: string, displayName: string) => Promise<{ success: boolean; error?: string }>;
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  loading: false,
  isFirebaseReady: false,
  signUp: async () => ({ success: false, error: 'Not configured' }),
  signIn: async () => ({ success: false, error: 'Not configured' }),
  signOut: async () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(isFirebaseConfigured);

  useEffect(() => {
    if (!isFirebaseConfigured || !auth) {
      // Firebase not configured — skip loading state
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        // Fetch or create user profile in Firestore
        if (db) {
          try {
            const userDocRef = doc(db, 'users', firebaseUser.uid);
            const userDoc = await getDoc(userDocRef);
            if (userDoc.exists()) {
              const data = userDoc.data();
              setProfile({
                uid: firebaseUser.uid,
                email: data.email || firebaseUser.email || '',
                displayName: data.displayName || firebaseUser.displayName || 'Manager',
                photoURL: data.photoURL || firebaseUser.photoURL || undefined,
                createdAt: data.createdAt?.toDate()?.toISOString() || new Date().toISOString(),
                lastLoginAt: new Date().toISOString(),
              });
              // Update last login
              await setDoc(userDocRef, { lastLoginAt: serverTimestamp() }, { merge: true });
            } else {
              // Create profile if it doesn't exist
              const newProfile: UserProfile = {
                uid: firebaseUser.uid,
                email: firebaseUser.email || '',
                displayName: firebaseUser.displayName || 'Manager',
                createdAt: new Date().toISOString(),
                lastLoginAt: new Date().toISOString(),
              };
              await setDoc(userDocRef, {
                ...newProfile,
                createdAt: serverTimestamp(),
                lastLoginAt: serverTimestamp(),
              });
              setProfile(newProfile);
            }
          } catch (e) {
            console.warn('Error fetching user profile:', e);
            setProfile({
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              displayName: firebaseUser.displayName || 'Manager',
              createdAt: new Date().toISOString(),
              lastLoginAt: new Date().toISOString(),
            });
          }
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signUp = async (email: string, password: string, displayName: string) => {
    if (!isFirebaseConfigured || !auth) {
      return { success: false, error: 'Firebase is not configured. See FIREBASE_DEPLOYMENT_GUIDE.md for setup instructions.' };
    }
    try {
      const credential = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(credential.user, { displayName });
      // Create Firestore profile
      if (db) {
        const userDocRef = doc(db, 'users', credential.user.uid);
        const newProfile = {
          uid: credential.user.uid,
          email,
          displayName,
          createdAt: serverTimestamp(),
          lastLoginAt: serverTimestamp(),
        };
        await setDoc(userDocRef, newProfile);
      }
      return { success: true };
    } catch (e: any) {
      let msg = e?.message || 'Sign up failed';
      // Make common Firebase errors user-friendly
      if (msg.includes('email-already-in-use')) msg = 'This email is already registered. Try signing in instead.';
      else if (msg.includes('weak-password')) msg = 'Password should be at least 6 characters.';
      else if (msg.includes('invalid-email')) msg = 'Please enter a valid email address.';
      return { success: false, error: msg };
    }
  };

  const signIn = async (email: string, password: string) => {
    if (!isFirebaseConfigured || !auth) {
      return { success: false, error: 'Firebase is not configured. See FIREBASE_DEPLOYMENT_GUIDE.md for setup instructions.' };
    }
    try {
      await signInWithEmailAndPassword(auth, email, password);
      return { success: true };
    } catch (e: any) {
      let msg = e?.message || 'Sign in failed';
      if (msg.includes('wrong-password') || msg.includes('user-not-found')) {
        msg = 'Invalid email or password.';
      } else if (msg.includes('invalid-email')) {
        msg = 'Please enter a valid email address.';
      } else if (msg.includes('too-many-requests')) {
        msg = 'Too many failed attempts. Please try again later.';
      }
      return { success: false, error: msg };
    }
  };

  const signOut = async () => {
    if (auth) {
      await firebaseSignOut(auth);
    }
  };

  return (
    <AuthContext.Provider
      value={{ user, profile, loading, isFirebaseReady: isFirebaseConfigured, signUp, signIn, signOut }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
