'use client';

import { useEffect, useRef } from 'react';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { db, isFirebaseConfigured } from './firebase';
import { useAuth } from './auth-context';
import { useGame } from './store';
import { SaveState } from './types';

/**
 * Hook that syncs game state to Firestore when a user is logged in.
 * - On login: loads the user's saved game state from Firestore
 * - On state change: saves to Firestore (debounced)
 * - Falls back to localStorage when not logged in (handled by zustand persist)
 */
export function useFirestoreSync() {
  const { user } = useAuth();
  const game = useGame();
  const lastLoadedUid = useRef<string | null>(null);
  const saveTimeout = useRef<NodeJS.Timeout | null>(null);

  // Load game state when user logs in
  useEffect(() => {
    if (!user || !db || !isFirebaseConfigured) return;
    if (lastLoadedUid.current === user.uid) return; // already loaded for this user

    let cancelled = false;
    (async () => {
      try {
        const stateRef = doc(db, 'gameStates', user.uid);
        const stateDoc = await getDoc(stateRef);
        if (cancelled) return;
        if (stateDoc.exists()) {
          const data = stateDoc.data() as SaveState;
          // Merge loaded state into the store, keeping current state as fallback
          useGame.setState({
            ...data,
            _hasHydrated: true,
          });
        }
        // If no saved state, keep current localStorage state and mark as loaded
        lastLoadedUid.current = user.uid;
      } catch (e) {
        console.warn('Error loading game state from Firestore:', e);
        lastLoadedUid.current = user.uid;
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [user]);

  // Debounced save to Firestore on state change
  useEffect(() => {
    if (!user || !db || !isFirebaseConfigured) return;
    if (lastLoadedUid.current !== user.uid) return; // don't save until loaded

    if (saveTimeout.current) clearTimeout(saveTimeout.current);

    saveTimeout.current = setTimeout(async () => {
      try {
        const stateRef = doc(db, 'gameStates', user.uid);
        // Extract serializable state (exclude _hasHydrated and functions)
        const state = useGame.getState();
        const { _hasHydrated, ...saveable } = state as any;
        // Remove functions
        const cleanState: any = {};
        for (const [key, value] of Object.entries(saveable)) {
          if (typeof value !== 'function') {
            cleanState[key] = value;
          }
        }
        await setDoc(stateRef, cleanState, { merge: true });
      } catch (e) {
        console.warn('Error saving game state to Firestore:', e);
      }
    }, 1500); // 1.5s debounce

    return () => {
      if (saveTimeout.current) clearTimeout(saveTimeout.current);
    };
  }, [user, game.coins, game.collection, game.squad, game.formationId, game.customFormation, game.achievementsClaimed, game.level, game.xp, game.matchesPlayed, game.marketListings, game.tradeOffers]);
}
