/**
 * Firebase configuration for FOOTBALL LEGENDS: DREAM XI
 *
 * SETUP INSTRUCTIONS:
 * 1. Go to https://console.firebase.google.com/
 * 2. Create a new project (or use an existing one)
 * 3. Add a Web App (</> icon) to get your config values
 * 4. Enable Authentication > Email/Password sign-in method
 * 5. Create a Firestore Database (start in production or test mode)
 * 6. Replace the placeholder values below with your real config
 * 7. For deployment: run `firebase init` then `firebase deploy`
 *
 * See FIREBASE_DEPLOYMENT_GUIDE.md for the full step-by-step guide.
 */

import { initializeApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore } from 'firebase/firestore';

// ============================================================
//  FIREBASE CONFIG — REPLACE THESE WITH YOUR OWN VALUES
// ============================================================
const firebaseConfig = {
  apiKey: "AIzaSyDIU2G096jgvFugABTeS8l3uSO8R7uDWV4",
  authDomain: "football-legends-2551d.firebaseapp.com",
  projectId: "football-legends-2551d",
  storageBucket: "football-legends-2551d.firebasestorage.app",
  messagingSenderId: "44469943167",
  appId: "1:44469943167:web:715f571a54d32b3bf3384a",
  measurementId: "G-NKBVY9VGRQ",
};

// Check if Firebase is configured (not using placeholder values)
export const isFirebaseConfigured =
  firebaseConfig.apiKey !== "YOUR_API_KEY" &&
  firebaseConfig.projectId !== "YOUR_PROJECT_ID";

// Lazy-initialize Firebase only if configured
let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;

if (isFirebaseConfigured) {
  try {
    app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);
  } catch (e) {
    console.warn('Firebase initialization failed:', e);
  }
}

export { app, auth, db };
