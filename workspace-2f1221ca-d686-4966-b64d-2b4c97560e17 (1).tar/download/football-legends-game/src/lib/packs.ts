import { PackDef, Rarity, Player, PlayerVersion } from './types';
import { PLAYERS } from './players';

// ============================================================
//  PACK DEFINITIONS
// ============================================================

export const PACKS: PackDef[] = [
  // ---- Daily ----
  {
    id: 'daily-spin',
    name: 'Daily Free Spin',
    description: 'One free spin every day. Contains at least a Rare player.',
    cost: 0,
    cardCount: 1,
    guaranteeRarity: 'rare',
    accent: '#22c55e',
    gradient: 'linear-gradient(135deg, #14532d 0%, #22c55e 50%, #052e16 100%)',
    badge: 'FREE',
    category: 'daily',
  },

  // ---- Standard ----
  {
    id: 'standard',
    name: 'Standard Pack',
    description: '3 player cards. Mostly Common with a chance of Rare or Epic.',
    cost: 500,
    cardCount: 3,
    rarityWeights: {
      common: 0.65,
      rare: 0.27,
      epic: 0.07,
      legendary: 0.01,
    },
    accent: '#94a3b8',
    gradient: 'linear-gradient(135deg, #1e293b 0%, #475569 50%, #0f172a 100%)',
    category: 'standard',
  },

  // ---- Premium ----
  {
    id: 'premium',
    name: 'Premium Pack',
    description: '5 player cards. Higher chance of Epic & Legendary players.',
    cost: 1500,
    cardCount: 5,
    rarityWeights: {
      common: 0.30,
      rare: 0.40,
      epic: 0.20,
      legendary: 0.08,
      icon: 0.02,
    },
    accent: '#a855f7',
    gradient: 'linear-gradient(135deg, #3b0764 0%, #a855f7 50%, #1e1b4b 100%)',
    category: 'premium',
  },

  {
    id: 'gold-premium',
    name: 'Gold Premium Pack',
    description: '5 cards with at least one Legendary or above. The premium experience.',
    cost: 3500,
    cardCount: 5,
    guaranteeRarity: 'legendary',
    rarityWeights: {
      rare: 0.30,
      epic: 0.40,
      legendary: 0.22,
      icon: 0.07,
      'ultimate-icon': 0.01,
    },
    accent: '#fbbf24',
    gradient: 'linear-gradient(135deg, #78350f 0%, #fbbf24 50%, #451a03 100%)',
    badge: 'GOLD',
    category: 'premium',
  },

  // ---- Icon ----
  {
    id: 'icon-pack',
    name: 'Icon Pack',
    description: '1 guaranteed Icon or Ultimate Icon player. The pinnacle of any collection.',
    cost: 10000,
    cardCount: 1,
    guaranteeRarity: 'icon',
    rarityWeights: {
      icon: 0.85,
      'ultimate-icon': 0.15,
    },
    accent: '#fde68a',
    gradient:
      'linear-gradient(135deg, #fef3c7 0%, #f59e0b 50%, #fef3c7 100%)',
    badge: 'ICON',
    category: 'icon',
  },

  // ---- Themed: Club Legends ----
  {
    id: 'barcelona-legends',
    name: 'Barcelona Legends Pack',
    description: '3 cards from Barcelona legends and current stars. Includes Cruyff, Maradona, Ronaldinho, Messi & more.',
    cost: 3000,
    cardCount: 3,
    themes: ['barcelona'],
    guaranteeRarity: 'epic',
    rarityWeights: {
      rare: 0.20,
      epic: 0.40,
      legendary: 0.25,
      icon: 0.13,
      'ultimate-icon': 0.02,
    },
    accent: '#a50044',
    gradient: 'linear-gradient(135deg, #a50044 0%, #004d98 50%, #a50044 100%)',
    badge: 'BARÇA',
    category: 'themed',
  },

  {
    id: 'real-madrid-galacticos',
    name: 'Real Madrid Galácticos Pack',
    description: '3 cards from Real Madrid legends. Di Stéfano, Puskás, R9, Zidane, CR7 & more.',
    cost: 3000,
    cardCount: 3,
    themes: ['real-madrid'],
    guaranteeRarity: 'epic',
    rarityWeights: {
      rare: 0.20,
      epic: 0.40,
      legendary: 0.25,
      icon: 0.13,
      'ultimate-icon': 0.02,
    },
    accent: '#febe10',
    gradient: 'linear-gradient(135deg, #00529f 0%, #febe10 50%, #00529f 100%)',
    badge: 'MADRID',
    category: 'themed',
  },

  {
    id: 'ac-milan-legends',
    name: 'AC Milan Legends Pack',
    description: '3 cards from AC Milan legends. Maldini, Baresi, Van Basten, Gullit & more.',
    cost: 2500,
    cardCount: 3,
    themes: ['ac-milan'],
    guaranteeRarity: 'epic',
    rarityWeights: {
      rare: 0.25,
      epic: 0.40,
      legendary: 0.22,
      icon: 0.11,
      'ultimate-icon': 0.02,
    },
    accent: '#fb090b',
    gradient: 'linear-gradient(135deg, #000000 0%, #fb090b 50%, #000000 100%)',
    badge: 'MILAN',
    category: 'themed',
  },

  {
    id: 'liverpool-legends',
    name: 'Liverpool Legends Pack',
    description: '3 cards from Liverpool legends & current stars. Dalglish, Gerrard, Salah, Van Dijk & more.',
    cost: 2500,
    cardCount: 3,
    themes: ['liverpool'],
    guaranteeRarity: 'epic',
    rarityWeights: {
      rare: 0.25,
      epic: 0.40,
      legendary: 0.22,
      icon: 0.11,
      'ultimate-icon': 0.02,
    },
    accent: '#c8102e',
    gradient: 'linear-gradient(135deg, #00b2a9 0%, #c8102e 50%, #00b2a9 100%)',
    badge: 'LFC',
    category: 'themed',
  },

  // ---- Themed: National Teams ----
  {
    id: 'brazil-legends',
    name: 'Brazil Legends Pack',
    description: '3 cards from Brazilian football legends. Pelé, Garrincha, R9, Ronaldinho, Cafu & more.',
    cost: 3500,
    cardCount: 3,
    themes: ['brazil'],
    guaranteeRarity: 'epic',
    rarityWeights: {
      rare: 0.18,
      epic: 0.36,
      legendary: 0.27,
      icon: 0.15,
      'ultimate-icon': 0.04,
    },
    accent: '#facc15',
    gradient: 'linear-gradient(135deg, #009c3b 0%, #facc15 50%, #002776 100%)',
    badge: 'BRASIL',
    category: 'themed',
  },

  {
    id: 'argentina-world-cup',
    name: 'Argentina World Cup Pack',
    description: '3 cards from Argentina\'s World Cup legends. Maradona 1986, Messi 2022 & more.',
    cost: 4000,
    cardCount: 3,
    themes: ['argentina', 'world-cup'],
    guaranteeRarity: 'legendary',
    rarityWeights: {
      epic: 0.25,
      legendary: 0.40,
      icon: 0.25,
      'ultimate-icon': 0.10,
    },
    accent: '#75aadb',
    gradient: 'linear-gradient(135deg, #75aadb 0%, #ffffff 50%, #75aadb 100%)',
    badge: 'ARG',
    category: 'themed',
  },

  {
    id: 'france-stars',
    name: 'France Stars Pack',
    description: '3 cards from French football legends & current stars. Zidane, Henry, Platini, Mbappé & more.',
    cost: 3000,
    cardCount: 3,
    themes: ['france'],
    guaranteeRarity: 'epic',
    rarityWeights: {
      rare: 0.20,
      epic: 0.40,
      legendary: 0.25,
      icon: 0.13,
      'ultimate-icon': 0.02,
    },
    accent: '#1e3a8a',
    gradient: 'linear-gradient(135deg, #1e3a8a 0%, #ffffff 50%, #dc2626 100%)',
    badge: 'FRA',
    category: 'themed',
  },

  // ---- Themed: Competitions ----
  {
    id: 'champions-league-legends',
    name: 'Champions League Legends Pack',
    description: '3 cards from UCL legends. The greatest to ever play in Europe\'s premier competition.',
    cost: 4500,
    cardCount: 3,
    themes: ['ucl'],
    guaranteeRarity: 'legendary',
    rarityWeights: {
      epic: 0.20,
      legendary: 0.40,
      icon: 0.30,
      'ultimate-icon': 0.10,
    },
    accent: '#0a1a3a',
    gradient:
      'linear-gradient(135deg, #0a1a3a 0%, #ffffff 50%, #0a1a3a 100%)',
    badge: 'UCL',
    category: 'themed',
  },

  // ---- Themed: Player-specific ----
  {
    id: 'messi-pack',
    name: 'Messi Pack',
    description: '2 cards — both versions of Messi. Chase the World Cup Champion or Ultimate Icon.',
    cost: 8000,
    cardCount: 2,
    guaranteeRarity: 'icon',
    rarityWeights: {
      legendary: 0.30,
      icon: 0.55,
      'ultimate-icon': 0.15,
    },
    accent: '#75aadb',
    gradient: 'linear-gradient(135deg, #1e3a8a 0%, #75aadb 50%, #fbbf24 100%)',
    badge: 'MESSI',
    category: 'themed',
    // custom filter applied at opening time via packId === 'messi-pack'
  },

  {
    id: 'ronaldo-pack',
    name: 'Ronaldo Pack',
    description: '2 cards — both versions of Cristiano Ronaldo. From Man Utd wonderkid to Ultimate Icon.',
    cost: 8000,
    cardCount: 2,
    guaranteeRarity: 'icon',
    rarityWeights: {
      legendary: 0.30,
      icon: 0.55,
      'ultimate-icon': 0.15,
    },
    accent: '#dc2626',
    gradient: 'linear-gradient(135deg, #059669 0%, #fbbf24 50%, #dc2626 100%)',
    badge: 'CR7',
    category: 'themed',
  },

  // ---- Prime / Current ----
  {
    id: 'prime-players',
    name: 'Prime Players Pack',
    description: '3 cards featuring prime and legend versions of the greatest to ever play.',
    cost: 5000,
    cardCount: 3,
    themes: ['prime', 'legend'],
    guaranteeRarity: 'legendary',
    rarityWeights: {
      epic: 0.10,
      legendary: 0.45,
      icon: 0.35,
      'ultimate-icon': 0.10,
    },
    accent: '#f59e0b',
    gradient: 'linear-gradient(135deg, #451a03 0%, #f59e0b 50%, #000000 100%)',
    badge: 'PRIME',
    category: 'themed',
  },

  {
    id: 'current-superstars',
    name: 'Current Superstars Pack',
    description: '3 cards from today\'s biggest stars. Mbappé, Haaland, Bellingham, Vini & more.',
    cost: 2000,
    cardCount: 3,
    themes: ['current'],
    guaranteeRarity: 'rare',
    rarityWeights: {
      common: 0.10,
      rare: 0.50,
      epic: 0.30,
      legendary: 0.09,
      icon: 0.01,
    },
    accent: '#22d3ee',
    gradient: 'linear-gradient(135deg, #0e7490 0%, #22d3ee 50%, #155e75 100%)',
    badge: 'CURRENT',
    category: 'themed',
  },
];

export function getPack(packId: string): PackDef | undefined {
  return PACKS.find((p) => p.id === packId);
}

// ============================================================
//  PLAYER VERSION POOL FILTERING
// ============================================================

/** Returns all (player, version) pairs eligible for a given pack */
export function getEligiblePool(pack: PackDef): { player: Player; version: PlayerVersion }[] {
  // Special-case player packs
  if (pack.id === 'messi-pack') {
    const messi = PLAYERS.find((p) => p.id === 'messi')!;
    return messi.versions.map((v) => ({ player: messi, version: v }));
  }
  if (pack.id === 'ronaldo-pack') {
    const cr7 = PLAYERS.find((p) => p.id === 'ronaldo-cr7')!;
    return cr7.versions.map((v) => ({ player: cr7, version: v }));
  }

  // Theme-filtered packs
  if (pack.themes && pack.themes.length > 0) {
    const result: { player: Player; version: PlayerVersion }[] = [];
    for (const player of PLAYERS) {
      for (const version of player.versions) {
        // version must include at least one of the pack's themes
        if (version.themes.some((t) => pack.themes!.includes(t))) {
          result.push({ player, version });
        }
      }
    }
    return result;
  }

  // No theme - use entire database
  const result: { player: Player; version: PlayerVersion }[] = [];
  for (const player of PLAYERS) {
    for (const version of player.versions) {
      result.push({ player, version });
    }
  }
  return result;
}

// ============================================================
//  PROBABILITY & PACK OPENING
// ============================================================

const RARITY_RANK: Record<Rarity, number> = {
  common: 0,
  rare: 1,
  epic: 2,
  legendary: 3,
  icon: 4,
  'ultimate-icon': 5,
  highlight: 6,
  mythic: 7,
};

function pickWeightedRarity(weights: Partial<Record<Rarity, number>>): Rarity {
  const entries = Object.entries(weights) as [Rarity, number][];
  const total = entries.reduce((s, [, w]) => s + w, 0);
  let r = Math.random() * total;
  for (const [rarity, w] of entries) {
    r -= w;
    if (r <= 0) return rarity;
  }
  return entries[entries.length - 1][0];
}

/** Default rarity weights for standard pack (used when pack doesn't define any) */
const DEFAULT_WEIGHTS: Record<Rarity, number> = {
  common: 0.65,
  rare: 0.27,
  epic: 0.07,
  legendary: 0.009,
  icon: 0.0009,
  'ultimate-icon': 0.0001,
  highlight: 0,
  mythic: 0,
};

/** Open a pack and return the cards (player+version pairs) revealed */
export function openPack(pack: PackDef): { player: Player; version: PlayerVersion }[] {
  const pool = getEligiblePool(pack);
  if (pool.length === 0) {
    // Fallback: should never happen, but be safe
    return [];
  }

  const weights = pack.rarityWeights ?? DEFAULT_WEIGHTS;
  const result: { player: Player; version: PlayerVersion }[] = [];
  const usedVersionIds = new Set<string>();

  // First, guarantee a card of guaranteeRarity if specified
  if (pack.guaranteeRarity) {
    const minRank = RARITY_RANK[pack.guaranteeRarity];
    const eligible = pool.filter((p) => RARITY_RANK[p.version.rarity] >= minRank);
    if (eligible.length > 0) {
      const pick = eligible[Math.floor(Math.random() * eligible.length)];
      result.push(pick);
      usedVersionIds.add(`${pick.player.id}__${pick.version.id}`);
    }
  }

  // Fill remaining slots
  while (result.length < pack.cardCount) {
    const targetRarity = pickWeightedRarity(weights);
    // Try to find a version matching the target rarity in the pool
    let candidates = pool.filter(
      (p) =>
        p.version.rarity === targetRarity &&
        !usedVersionIds.has(`${p.player.id}__${p.version.id}`)
    );

    // If no exact rarity match, fall back to a same-or-higher tier
    if (candidates.length === 0) {
      const minRank = RARITY_RANK[targetRarity];
      candidates = pool.filter(
        (p) =>
          RARITY_RANK[p.version.rarity] >= minRank &&
          !usedVersionIds.has(`${p.player.id}__${p.version.id}`)
      );
    }

    // If still nothing, just pick anything from the pool not already used
    if (candidates.length === 0) {
      candidates = pool.filter(
        (p) => !usedVersionIds.has(`${p.player.id}__${p.version.id}`)
      );
    }

    if (candidates.length === 0) {
      // pool exhausted (very small pool). Allow duplicates.
      const fallback = pool[Math.floor(Math.random() * pool.length)];
      result.push(fallback);
      continue;
    }

    const pick = candidates[Math.floor(Math.random() * candidates.length)];
    result.push(pick);
    usedVersionIds.add(`${pick.player.id}__${pick.version.id}`);
  }

  return result;
}

/** Coins awarded for duplicate exchange, by rarity */
export const DUPLICATE_REWARDS: Record<Rarity, number> = {
  common: 30,
  rare: 100,
  epic: 250,
  legendary: 600,
  icon: 1500,
  'ultimate-icon': 5000,
  highlight: 3000,
  mythic: 15000,
};
