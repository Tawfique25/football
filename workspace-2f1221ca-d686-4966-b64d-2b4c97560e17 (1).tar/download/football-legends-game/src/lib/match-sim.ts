import {
  MatchEvent,
  MatchResult,
  Player,
  PlayerVersion,
  CustomFormation,
} from './types';
import { calculateTeamRating, effectiveRating, getFormation } from './formations';

// ============================================================
//  AI OPPONENT TEAMS (preset squads built from the player DB)
// ============================================================

export interface AITeam {
  id: string;
  name: string;
  /** Approximate rating shown in UI; will be recalculated from actual squad at runtime */
  rating: number;
  /** Difficulty tier (used for reward scaling & UI) */
  tier: 'amateur' | 'pro' | 'elite' | 'legend' | 'ultimate';
  accent: string;
  gradient: string;
  /** Each entry is playerId + versionId */
  squad: { playerId: string; versionId: string }[];
  formationId: string;
}

// AI teams are built at runtime against the player DB.
// Squads are carefully constructed so each tier has a genuinely different strength.
// Tier progression (actual squad OVR):
//   amateur  : ~70  (all common-tier squad players)
//   pro      : ~78  (mix of common + rare)
//   elite    : ~86  (mix of rare + epic)
//   legend   : ~93  (mix of legendary + icon)
//   ultimate : ~99  (all icon / ultimate-icon)

export const AI_TEAMS_DEF: AITeam[] = [
  // ===== TIER 1: AMATEURS (genuinely weak — ~70 OVR) =====
  {
    id: 'sunday-league',
    name: 'Sunday League Amateurs',
    rating: 70,
    tier: 'amateur',
    accent: '#94a3b8',
    gradient: 'linear-gradient(135deg, #1e293b 0%, #64748b 100%)',
    formationId: '4-4-2',
    squad: [
      { playerId: 'ramsdale', versionId: 'ramsdale-squad' },
      { playerId: 'tierney', versionId: 'tierney-squad' },
      { playerId: 'maguire', versionId: 'maguire-squad' },
      { playerId: 'dier', versionId: 'dier-squad' },
      { playerId: 'awb', versionId: 'awb-squad' },
      { playerId: 'mctominay', versionId: 'mctominay-squad' },
      { playerId: 'henderson', versionId: 'henderson-squad' },
      { playerId: 'eriksen', versionId: 'eriksen-squad' },
      { playerId: 'zaha', versionId: 'zaha-squad' },
      { playerId: 'werner', versionId: 'werner-squad' },
      { playerId: 'martial', versionId: 'martial-squad' },
    ],
  },

  // ===== TIER 1.5: YOUTH ACADEMY (~74 OVR) =====
  {
    id: 'youth-academy',
    name: 'Youth Academy',
    rating: 74,
    tier: 'amateur',
    accent: '#86efac',
    gradient: 'linear-gradient(135deg, #14532d 0%, #86efac 100%)',
    formationId: '4-3-3',
    // 4-3-3 slots: GK, LB, CB, CB, RB, CM, CM, CM, LW, ST, RW
    squad: [
      { playerId: 'chevalier', versionId: 'chevalier-star' },        // GK
      { playerId: 'balde', versionId: 'balde-star' },                // LB
      { playerId: 'lukeba', versionId: 'lukeba-star' },              // CB
      { playerId: 'branthwaite', versionId: 'branthwaite-star' },    // CB
      { playerId: 'gusto', versionId: 'gusto-star' },                // RB
      { playerId: 'archiegray', versionId: 'archiegray-star' },      // CM
      { playerId: 'mainoo', versionId: 'mainoo-star' },              // CM
      { playerId: 'joaoneves', versionId: 'joaoneves-star' },        // CM
      { playerId: 'bakayoko', versionId: 'bakayoko-star' },          // LW
      { playerId: 'hojlund', versionId: 'hojlund-star' },            // ST
      { playerId: 'ansufati', versionId: 'ansufati-star' },          // RW
    ],
  },

  // ===== TIER 2: PROFESSIONAL (mid-tier — ~78 OVR) =====
  {
    id: 'local-rivals',
    name: 'Local Rivals FC',
    rating: 78,
    tier: 'pro',
    accent: '#22d3ee',
    gradient: 'linear-gradient(135deg, #0e7490 0%, #22d3ee 100%)',
    formationId: '4-3-3',
    // 4-3-3 slots: GK, LB, CB, CB, RB, CM, CM, CM, LW, ST, RW
    squad: [
      { playerId: 'ramsdale', versionId: 'ramsdale-squad' },        // GK
      { playerId: 'tierney', versionId: 'tierney-squad' },          // LB
      { playerId: 'maguire', versionId: 'maguire-squad' },          // CB
      { playerId: 'dier', versionId: 'dier-squad' },                // CB
      { playerId: 'awb', versionId: 'awb-squad' },                  // RB
      { playerId: 'rakitic', versionId: 'rakitic-veteran' },        // CM
      { playerId: 'mctominay', versionId: 'mctominay-squad' },      // CM
      { playerId: 'henderson', versionId: 'henderson-squad' },      // CM
      { playerId: 'zaha', versionId: 'zaha-squad' },                // LW
      { playerId: 'jesus', versionId: 'jesus-squad' },              // ST
      { playerId: 'pulisic', versionId: 'pulisic-squad' },          // RW (alt)
    ],
  },

  // ===== TIER 2.5: RISING STARS (~82 OVR) =====
  {
    id: 'rising-stars',
    name: 'Rising Stars',
    rating: 82,
    tier: 'pro',
    accent: '#60a5fa',
    gradient: 'linear-gradient(135deg, #1e3a8a 0%, #60a5fa 100%)',
    formationId: '4-3-3',
    squad: [
      { playerId: 'mamardashvili', versionId: 'mamardashvili-star' }, // GK
      { playerId: 'balde', versionId: 'balde-star' },                // LB
      { playerId: 'antoniosilva', versionId: 'antoniosilva-star' },  // CB
      { playerId: 'saliba', versionId: 'saliba-arsenal-star' },      // CB
      { playerId: 'hakimi', versionId: 'hakimi-psg-star' },          // RB
      { playerId: 'joaoneves', versionId: 'joaoneves-star' },        // CM
      { playerId: 'barella', versionId: 'barella-inter-star' },      // CM
      { playerId: 'odegaard', versionId: 'odegaard-arsenal-star' },  // CM (CAM→CM)
      { playerId: 'nicowilliams', versionId: 'nicowilliams-star' },  // RW→LW
      { playerId: 'sesko', versionId: 'sesko-star' },                // ST
      { playerId: 'raphinha', versionId: 'raphinha-barca-star' },    // RW
    ],
  },

  // ===== TIER 3: ELITE (current stars — ~86 OVR) =====
  {
    id: 'continental-stars',
    name: 'Continental Stars',
    rating: 86,
    tier: 'elite',
    accent: '#a855f7',
    gradient: 'linear-gradient(135deg, #3b0764 0%, #a855f7 100%)',
    formationId: '4-3-3',
    // 4-3-3 slots: GK, LB, CB, CB, RB, CM, CM, CM, LW, ST, RW
    squad: [
      { playerId: 'alisson', versionId: 'alisson-liverpool-star' },  // GK
      { playerId: 'hernandez', versionId: 'hernandez-milan-star' },  // LB
      { playerId: 'vandijk', versionId: 'vandijk-netherlands-star' },// CB
      { playerId: 'dias', versionId: 'dias-man-city-star' },         // CB
      { playerId: 'trent', versionId: 'trent-liverpool-star' },      // RB ✓
      { playerId: 'rodri', versionId: 'rodri-man-city-star' },       // CM (alt CDM)
      { playerId: 'pedri', versionId: 'pedri-barca-star' },          // CM
      { playerId: 'debruyne', versionId: 'kdb-belgium-star' },       // CM (CAM→CM alt)
      { playerId: 'leao', versionId: 'leao-milan-star' },            // LW ✓
      { playerId: 'kane', versionId: 'kane-tottenham-star' },        // ST ✓
      { playerId: 'saka', versionId: 'saka-arsenal-star' },          // RW (alt LW, same group ATT)
    ],
  },

  // ===== TIER 3.5: CHAMPIONS LEAGUE (~90 OVR) =====
  {
    id: 'champions-league',
    name: 'Champions League XI',
    rating: 90,
    tier: 'elite',
    accent: '#c084fc',
    gradient: 'linear-gradient(135deg, #4c1d95 0%, #c084fc 50%, #1e1b4b 100%)',
    formationId: '4-3-3',
    squad: [
      { playerId: 'courtois', versionId: 'courtois-real-star' },     // GK
      { playerId: 'hernandez', versionId: 'hernandez-milan-star' },  // LB
      { playerId: 'vandijk', versionId: 'vandijk-liverpool-star' },  // CB
      { playerId: 'rudiger', versionId: 'rudiger-real-star' },       // CB
      { playerId: 'hakimi', versionId: 'hakimi-psg-star' },          // RB
      { playerId: 'rodri', versionId: 'rodri-spain-euro' },          // CM
      { playerId: 'valverde', versionId: 'valverde-real-star' },     // CM
      { playerId: 'bellingham', versionId: 'bellingham-real-star' }, // CM (CAM→CM)
      { playerId: 'vinijr', versionId: 'vini-real-star' },           // LW
      { playerId: 'mbappe', versionId: 'mbappe-real-madrid-star' },  // ST (alt)
      { playerId: 'salah', versionId: 'salah-liverpool-star' },      // RW
    ],
  },

  // ===== TIER 4: LEGEND (top current + retired legends — ~93 OVR) =====
  {
    id: 'galacticos-united',
    name: 'Galácticos United',
    rating: 93,
    tier: 'legend',
    accent: '#fbbf24',
    gradient: 'linear-gradient(135deg, #78350f 0%, #fbbf24 100%)',
    formationId: '4-3-3',
    squad: [
      { playerId: 'casillas', versionId: 'casillas-real-legend' },         // GK
      { playerId: 'robertocarlos', versionId: 'rc-real-galactico' },       // LB
      { playerId: 'maldini', versionId: 'maldini-milan-legend' },          // CB
      { playerId: 'beckenbauer', versionId: 'beckenbauer-bayern-legend' }, // CB
      { playerId: 'cafu', versionId: 'cafu-brazil-legend' },               // RB
      { playerId: 'modric', versionId: 'modric-real-legend' },             // CM
      { playerId: 'kroos', versionId: 'kroos-real-legend' },               // CM
      { playerId: 'pirlo', versionId: 'pirlo-italy-legend' },              // CM (alt CDM)
      { playerId: 'ronaldinho', versionId: 'ronaldinho-barca-magician' },  // LW (alt)
      { playerId: 'r9', versionId: 'r9-real-galactico' },                  // ST
      { playerId: 'beckham', versionId: 'beckham-man-utd-star' },          // RW (RM→RW family)
    ],
  },

  // ===== TIER 4.5: WORLD XI (~96 OVR) =====
  {
    id: 'world-xi',
    name: 'World XI',
    rating: 96,
    tier: 'legend',
    accent: '#f59e0b',
    gradient: 'linear-gradient(135deg, #b45309 0%, #f59e0b 50%, #fef3c7 100%)',
    formationId: '4-3-3',
    squad: [
      { playerId: 'courtois', versionId: 'courtois-real-star' },         // GK
      { playerId: 'robertocarlos', versionId: 'rc-ultimate-icon' },      // LB
      { playerId: 'maldini', versionId: 'maldini-ultimate-icon' },       // CB
      { playerId: 'beckenbauer', versionId: 'beckenbauer-ultimate-icon' }, // CB
      { playerId: 'cafu', versionId: 'cafu-ultimate-icon' },             // RB
      { playerId: 'modric', versionId: 'modric-real-legend' },           // CM
      { playerId: 'kroos', versionId: 'kroos-real-legend' },             // CM
      { playerId: 'zidane', versionId: 'zidane-real-galactico' },        // CM (CAM→CM)
      { playerId: 'messi', versionId: 'messi-prime-barca' },             // RW (alt)
      { playerId: 'cr7', versionId: 'cr7-real-galactico' },              // ST (alt LW)
      { playerId: 'ronaldinho', versionId: 'ronaldinho-barca-magician' }, // LW (alt)
    ],
  },

  // ===== TIER 5: ULTIMATE (all-time greats — ~99 OVR) =====
  {
    id: 'all-time-legends',
    name: 'All-Time Legends XI',
    rating: 99,
    tier: 'ultimate',
    accent: '#fde68a',
    gradient: 'linear-gradient(135deg, #fef3c7 0%, #f59e0b 100%)',
    formationId: '4-3-3',
    squad: [
      { playerId: 'yashin', versionId: 'yashin-ultimate-icon' },           // GK
      { playerId: 'robertocarlos', versionId: 'rc-ultimate-icon' },        // LB
      { playerId: 'maldini', versionId: 'maldini-ultimate-icon' },         // CB
      { playerId: 'beckenbauer', versionId: 'beckenbauer-ultimate-icon' }, // CB
      { playerId: 'cafu', versionId: 'cafu-ultimate-icon' },               // RB
      { playerId: 'xavi', versionId: 'xavi-ultimate-icon' },               // CM ✓ (natural CM)
      { playerId: 'iniesta', versionId: 'iniesta-ultimate-icon' },         // CM ✓ (natural CM)
      { playerId: 'zidane', versionId: 'zidane-ultimate-icon' },           // CM (CAM→CM alt)
      { playerId: 'ronaldinho', versionId: 'ronaldinho-ultimate-icon' },   // LW (alt)
      { playerId: 'pele', versionId: 'pele-ultimate-icon' },               // ST ✓ (natural ST)
      { playerId: 'garrincha', versionId: 'garrincha-brazil-legend' },     // RW ✓ (natural RW)
    ],
  },
];

// ============================================================
//  RUNTIME RATING CALCULATION (uses actual squad)
// ============================================================

/** Resolve an AI team's squad into actual player+version entries */
export function resolveAISquad(
  team: AITeam,
  lookup: (pid: string, vid: string) => { player: Player; version: PlayerVersion } | undefined
): ({ player: Player; version: PlayerVersion } | null)[] {
  const resolved = team.squad.map((s) => lookup(s.playerId, s.versionId) ?? null);
  while (resolved.length < 11) resolved.push(null);
  return resolved.slice(0, 11);
}

/** Compute the actual OVR of an AI team from its resolved squad */
export function getAITeamRating(
  team: AITeam,
  lookup: (pid: string, vid: string) => { player: Player; version: PlayerVersion } | undefined
): number {
  const squad = resolveAISquad(team, lookup);
  const formation = getFormation(team.formationId);
  let sum = 0;
  let n = 0;
  squad.forEach((entry, i) => {
    if (!entry) return;
    const slotPos = formation.slots[i].position;
    const eff = effectiveRating(entry.version, slotPos, entry.player);
    sum += eff;
    n++;
  });
  if (n === 0) return team.rating; // fallback
  return Math.min(99, Math.round(sum / n));
}

// ============================================================
//  MATCH SIMULATION ENGINE
// ============================================================

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function resolveSquad(
  squadDef: { playerId: string; versionId: string }[],
  lookup: (pid: string, vid: string) => { player: Player; version: PlayerVersion } | undefined
): ({ player: Player; version: PlayerVersion } | null)[] {
  const resolved = squadDef.map((s) => lookup(s.playerId, s.versionId) ?? null);
  while (resolved.length < 11) resolved.push(null);
  return resolved.slice(0, 11);
}

export interface SimInput {
  homeSquad: ({ player: Player; version: PlayerVersion } | null)[];
  homeFormationId: string;
  homeCustomFormation?: CustomFormation | null;
  awayTeam: AITeam;
  lookup: (pid: string, vid: string) => { player: Player; version: PlayerVersion } | undefined;
}

/**
 * Simulate a match. Uses attack/defense/midfield ratings + chemistry + randomness to produce
 * a believable scoreline and event timeline.
 *
 * Difficulty curve is intentionally amplified so that:
 *   - Beating weaker teams (10+ OVR gap) feels comfortable
 *   - Equal-strength matches are tense 50/50s
 *   - Stronger opponents (10+ OVR gap above) are genuinely tough to beat
 */
export function simulateMatch(input: SimInput): MatchResult {
  const home = calculateTeamRating(input.homeFormationId, input.homeSquad, input.homeCustomFormation);
  const awaySquad = resolveSquad(input.awayTeam.squad, input.lookup);
  const away = calculateTeamRating(input.awayTeam.formationId, awaySquad);

  // Forfeit if home squad is too small
  if (home.filled < 7) {
    return {
      homeScore: 0,
      awayScore: 3,
      events: [
        { minute: 0, type: 'info', team: 'home', text: 'Your squad is too incomplete to play. Default loss.' },
        { minute: 90, type: 'info', team: 'away', text: 'Full-time. Walkover victory for the AI side.' },
      ],
      homeStats: { possession: 30, shots: 0, onTarget: 0 },
      awayStats: { possession: 70, shots: 12, onTarget: 6 },
      homeRating: home.overall,
      awayRating: away.overall,
      chemistryHome: home.chemistry,
      rewards: { coins: 0, xp: 0 },
      won: false,
      draw: false,
    };
  }

  // Strength calculation: weighted blend of overall, attack, defense
  const homeStr =
    home.overall * 0.45 + home.attack * 0.25 + home.midfield * 0.15 + home.defense * 0.15;
  const awayStr =
    away.overall * 0.45 + away.attack * 0.25 + away.midfield * 0.15 + away.defense * 0.15;

  // Chemistry factors (0.85 - 1.15)
  const homeChemFactor = 0.85 + (home.chemistry / 100) * 0.3;
  const awayChemFactor = 0.85 + (away.chemistry / 100) * 0.3;

  const homeEffStr = homeStr * homeChemFactor;
  const awayEffStr = awayStr * awayChemFactor;
  const totalStr = homeEffStr + awayEffStr;

  // Possession: ratio of effective strengths
  const homePossessionPct = Math.round((homeEffStr / totalStr) * 100);
  const awayPossession = 100 - homePossessionPct;

  // =====================================================
  // AMPLIFIED xG MODEL — bigger swings based on gap
  // =====================================================
  // The rating gap drives xG multiplicatively so weak vs strong is dramatic.
  const ratingGap = homeStr - awayStr; // positive = home stronger

  // Base xG around 1.3; gap adds up to +/- 1.5 xG
  const homeXG = Math.max(0.15, 1.3 + ratingGap * 0.07 + (home.attack - away.defense) * 0.03);
  const awayXG = Math.max(0.15, 1.1 - ratingGap * 0.06 + (away.attack - home.defense) * 0.025);

  // Convert xG to goals with poisson-like randomness
  const homeScore = poissonSample(homeXG);
  const awayScore = poissonSample(awayXG);

  // Build event timeline
  const events: MatchEvent[] = [];
  events.push({
    minute: 0,
    type: 'info',
    team: 'home',
    text: `Kick-off! ${home.filled} players on the pitch. Team OVR ${home.overall} vs ${away.overall}.`,
  });

  // Distribute goals across the match
  const homeGoalMinutes = spreadMinutes(homeScore, 90);
  const awayGoalMinutes = spreadMinutes(awayScore, 90);

  for (let i = 0; i < homeScore; i++) {
    const minute = homeGoalMinutes[i];
    const scorer = pickAttacker(input.homeSquad);
    const assister = pickAssister(input.homeSquad, scorer);
    events.push({
      minute,
      type: 'goal',
      team: 'home',
      text: `GOAL! ${scorer?.player.name ?? 'Unknown'} scores for your team!`,
      scorer: scorer?.player.name,
      assist: assister?.player.name,
    });
  }

  for (let i = 0; i < awayScore; i++) {
    const minute = awayGoalMinutes[i];
    const scorer = pickAttacker(awaySquad);
    const assister = pickAssister(awaySquad, scorer);
    events.push({
      minute,
      type: 'goal',
      team: 'away',
      text: `GOAL! ${scorer?.player.name ?? 'Unknown'} scores for ${input.awayTeam.name}.`,
      scorer: scorer?.player.name,
      assist: assister?.player.name,
    });
  }

  // Shots (correlated with xG)
  const homeShots = Math.max(homeScore + 2, Math.round(homeXG * 4) + 2);
  const awayShots = Math.max(awayScore + 2, Math.round(awayXG * 4) + 2);
  const homeOnTarget = Math.min(homeShots, homeScore + Math.floor(Math.random() * 4) + 1);
  const awayOnTarget = Math.min(awayShots, awayScore + Math.floor(Math.random() * 4) + 1);

  // Sort events by minute
  events.sort((a, b) => a.minute - b.minute);

  events.push({
    minute: 90,
    type: 'info',
    team: 'home',
    text: `Full-time. Final score: ${homeScore} - ${awayScore}.`,
  });

  const won = homeScore > awayScore;
  const draw = homeScore === awayScore;

  // =====================================================
  // REWARDS — scaled by opponent tier AND result
  // =====================================================
  // Tier multipliers: amateur 1x, pro 2x, elite 3.5x, legend 5x, ultimate 8x
  const tierMult: Record<AITeam['tier'], number> = {
    amateur: 1,
    pro: 2,
    elite: 3.5,
    legend: 5,
    ultimate: 8,
  };

  // Base rewards per tier
  const baseWinCoins = 100 * tierMult[input.awayTeam.tier];
  const baseDrawCoins = 40 * tierMult[input.awayTeam.tier];
  const baseLossCoins = 15;

  // Bonus: if user beats a stronger team, bonus coins. If loses to weaker, penalty.
  const gapBonus = won ? Math.max(0, -ratingGap) * 8 : 0; // bonus for upset wins

  let coins: number;
  let xp: number;
  if (won) {
    coins = Math.round(baseWinCoins + gapBonus);
    xp = Math.round(40 * tierMult[input.awayTeam.tier] + Math.max(0, -ratingGap) * 1.5);
  } else if (draw) {
    coins = Math.round(baseDrawCoins);
    xp = Math.round(20 * tierMult[input.awayTeam.tier]);
  } else {
    coins = baseLossCoins;
    xp = 10;
  }

  return {
    homeScore,
    awayScore,
    events,
    homeStats: {
      possession: homePossessionPct,
      shots: homeShots,
      onTarget: homeOnTarget,
    },
    awayStats: {
      possession: awayPossession,
      shots: awayShots,
      onTarget: awayOnTarget,
    },
    homeRating: home.overall,
    awayRating: away.overall,
    chemistryHome: home.chemistry,
    rewards: { coins, xp },
    won,
    draw,
  };
}

function poissonSample(lambda: number): number {
  // Knuth's algorithm
  const L = Math.exp(-lambda);
  let k = 0;
  let p = 1;
  do {
    k++;
    p *= Math.random();
  } while (p > L);
  return k - 1;
}

function spreadMinutes(count: number, max: number): number[] {
  if (count === 0) return [];
  const minutes: number[] = [];
  for (let i = 0; i < count; i++) {
    minutes.push(Math.floor(Math.random() * (max - 1)) + 1);
  }
  minutes.sort((a, b) => a - b);
  return minutes;
}

function pickAttacker(
  squad: ({ player: Player; version: PlayerVersion } | null)[]
): { player: Player; version: PlayerVersion } | null {
  const attackers = squad.filter((s) => s && ['ST', 'CF', 'LW', 'RW', 'CAM'].includes(s.player.position));
  if (attackers.length > 0 && Math.random() > 0.15) {
    return pickRandom(attackers);
  }
  const mids = squad.filter((s) => s && ['CM', 'CDM', 'LM', 'RM'].includes(s.player.position));
  if (mids.length > 0) return pickRandom(mids);
  return squad.find((s) => s !== null) ?? null;
}

function pickAssister(
  squad: ({ player: Player; version: PlayerVersion } | null)[],
  scorer: { player: Player; version: PlayerVersion } | null
): { player: Player; version: PlayerVersion } | null {
  if (!scorer) return null;
  if (Math.random() < 0.3) return null;
  const candidates = squad.filter((s) => s && s.player.id !== scorer.player.id && ['CAM', 'CM', 'LW', 'RW', 'LM', 'RM', 'CF'].includes(s.player.position));
  if (candidates.length === 0) return null;
  return pickRandom(candidates);
}

export function getAITeam(id: string): AITeam | undefined {
  return AI_TEAMS_DEF.find((t) => t.id === id);
}
