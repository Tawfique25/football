'use client';

import { useGame } from '@/lib/store';
import { PlayerCard } from '@/components/cards/PlayerCard';
import { SectionHeader } from '@/components/ui-fl/shared';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { getPlayer, getVersion, cardValue } from '@/lib/players';
import { TradeOffer, CollectedCard, Player, PlayerVersion } from '@/lib/types';
import { useEffect, useMemo, useState } from 'react';
import {
  ArrowLeftRight,
  RefreshCw,
  Check,
  X,
  ArrowRight,
  Handshake,
  TrendingUp,
  TrendingDown,
  Minus,
  User,
  Sparkles,
} from 'lucide-react';

export function TradeSection() {
  const tradeOffers = useGame((s) => s.tradeOffers);
  const generateTradeOffers = useGame((s) => s.generateTradeOffers);
  const acceptTrade = useGame((s) => s.acceptTrade);
  const rejectTrade = useGame((s) => s.rejectTrade);
  const collection = useGame((s) => s.collection);
  const tradeRefreshKey = useGame((s) => s.tradeRefreshKey);
  const { toast } = useToast();

  const [refreshing, setRefreshing] = useState(false);
  const [actingId, setActingId] = useState<string | null>(null);

  // Auto-generate offers on mount if no active offers
  useEffect(() => {
    const activeCount = tradeOffers.filter((o) => o.active).length;
    if (activeCount === 0) {
      generateTradeOffers();
    }
  }, []);

  const activeOffers = useMemo(
    () => tradeOffers.filter((o) => o.active),
    [tradeOffers]
  );

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => {
      generateTradeOffers();
      setRefreshing(false);
      toast({
        title: 'Trade offers refreshed',
        description: '4 new merchants have arrived with fresh offers.',
      });
    }, 600);
  };

  const handleAccept = (offer: TradeOffer) => {
    setActingId(offer.id);
    const result = acceptTrade(offer.id);
    setTimeout(() => setActingId((id) => (id === offer.id ? null : id)), 500);
    if (result.success) {
      const giveNames = offer.give
        .map((g) => getPlayer(g.playerId)?.name)
        .filter(Boolean)
        .join(', ');
      toast({
        title: 'Trade accepted!',
        description: `You acquired ${giveNames || 'new cards'} from ${offer.merchantName}.`,
      });
    } else {
      toast({ title: 'Trade failed', description: result.error, variant: 'destructive' });
    }
  };

  const handleReject = (offer: TradeOffer) => {
    setActingId(offer.id);
    rejectTrade(offer.id);
    setTimeout(() => setActingId((id) => (id === offer.id ? null : id)), 300);
    toast({
      title: 'Offer rejected',
      description: `${offer.merchantName}'s offer has been dismissed.`,
    });
  };

  return (
    <div>
      <SectionHeader
        title="Trade Post"
        subtitle="NPC scouts and agents are offering card-for-card trades. Compare values, check your collection, and strike the best deals."
        icon={<ArrowLeftRight size={28} />}
      />

      {/* Top bar with summary + refresh */}
      <div className="fl-glass rounded-2xl p-4 mb-6 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-fl-neon-dim to-fl-neon flex items-center justify-center fl-glow-neon">
            <Handshake size={24} className="text-fl-navy" />
          </div>
          <div>
            <div className="text-2xl font-black tabular-nums text-fl-neon fl-text-shadow-neon">
              {activeOffers.length}
            </div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Active Offers</div>
          </div>
        </div>
        <button
          onClick={handleRefresh}
          disabled={refreshing}
          className={cn(
            'px-4 py-2.5 rounded-lg font-bold text-sm transition-all flex items-center gap-2',
            'bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy hover:scale-105 fl-glow-neon',
            refreshing && 'opacity-70 cursor-wait hover:scale-100'
          )}
        >
          <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
          {refreshing ? 'Refreshing…' : 'Refresh Offers'}
        </button>
      </div>

      {/* Offers grid OR empty state */}
      {activeOffers.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="fl-glass rounded-2xl p-12 text-center"
        >
          <div className="text-6xl mb-4">🤝</div>
          <h3 className="text-xl font-black mb-2">No active trade offers</h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            No merchants are offering trades right now. Refresh to meet new scouts and agents with fresh deals.
          </p>
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-bold text-sm bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy hover:scale-105 fl-glow-neon transition-all disabled:opacity-70"
          >
            <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
            {refreshing ? 'Generating…' : 'Generate Offers'}
          </button>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          <AnimatePresence mode="popLayout">
            {activeOffers.map((offer, i) => (
              <TradeOfferCard
                key={offer.id}
                offer={offer}
                collection={collection}
                index={i}
                acting={actingId === offer.id}
                onAccept={() => handleAccept(offer)}
                onReject={() => handleReject(offer)}
              />
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Footer hint */}
      {tradeRefreshKey && (
        <div className="text-center text-[10px] text-muted-foreground mt-6 tabular-nums">
          Offers last generated: {new Date(tradeRefreshKey).toLocaleString([], {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
          })}
        </div>
      )}
    </div>
  );
}

interface ResolvedCardEntry {
  playerId: string;
  versionId: string;
  player: Player;
  version: PlayerVersion;
  owned: boolean;
  value: number;
}

function resolveEntries(
  cards: { playerId: string; versionId: string }[],
  collection: CollectedCard[],
  checkOwnership: boolean
): ResolvedCardEntry[] {
  return cards
    .map((c) => {
      const player = getPlayer(c.playerId);
      const version = player ? getVersion(player.id, c.versionId) : undefined;
      if (!player || !version) return null;
      const cardId = `${c.playerId}__${c.versionId}`;
      const ownedCard = collection.find((cc) => cc.id === cardId && cc.count > 0);
      return {
        playerId: c.playerId,
        versionId: c.versionId,
        player,
        version,
        owned: checkOwnership ? !!ownedCard : false,
        value: cardValue(version),
      } as ResolvedCardEntry;
    })
    .filter((x): x is ResolvedCardEntry => x !== null);
}

function TradeOfferCard({
  offer,
  collection,
  index,
  acting,
  onAccept,
  onReject,
}: {
  offer: TradeOffer;
  collection: CollectedCard[];
  index: number;
  acting: boolean;
  onAccept: () => void;
  onReject: () => void;
}) {
  const giveEntries = useMemo(
    () => resolveEntries(offer.give, collection, false),
    [offer, collection]
  );
  const wantEntries = useMemo(
    () => resolveEntries(offer.want, collection, true),
    [offer, collection]
  );

  const giveValue = giveEntries.reduce((s, e) => s + e.value, 0);
  const wantValue = wantEntries.reduce((s, e) => s + e.value, 0);
  const delta = giveValue - wantValue;
  const hasWants = wantEntries.length > 0;
  const canAccept = hasWants && wantEntries.every((e) => e.owned);
  const dealType: 'good' | 'fair' | 'bad' = delta > 150 ? 'good' : delta < -150 ? 'bad' : 'fair';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 16, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95, y: -10 }}
      transition={{ duration: 0.35, delay: Math.min(index * 0.07, 0.35) }}
      className="fl-glass-strong rounded-2xl overflow-hidden flex flex-col"
    >
      {/* Merchant header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/5 bg-black/25">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-fl-panel to-fl-panel-2 flex items-center justify-center text-xl border border-white/10 fl-glow-neon">
            <span>{offer.merchantAvatar}</span>
          </div>
          <div>
            <div className="font-bold text-sm leading-tight">{offer.merchantName}</div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1">
              <User size={9} /> Merchant
            </div>
          </div>
        </div>
        <div
          className={cn(
            'px-2 py-1 rounded-md text-[10px] font-black uppercase tracking-wider flex items-center gap-1',
            dealType === 'good' && 'bg-fl-neon/20 text-fl-neon',
            dealType === 'bad' && 'bg-red-500/20 text-red-300',
            dealType === 'fair' && 'bg-fl-gold/20 text-fl-gold'
          )}
        >
          {dealType === 'good' && <TrendingUp size={11} />}
          {dealType === 'bad' && <TrendingDown size={11} />}
          {dealType === 'fair' && <Minus size={11} />}
          {dealType === 'good' ? 'Good Deal' : dealType === 'bad' ? 'Bad Deal' : 'Fair Trade'}
        </div>
      </div>

      {/* GIVES / arrow / WANTS */}
      <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] gap-3 p-4 items-center">
        {/* GIVES */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-[10px] uppercase tracking-wider font-black text-fl-neon flex items-center gap-1">
              <Sparkles size={10} /> Gives You
            </div>
            <div className="text-[10px] tabular-nums text-muted-foreground">
              {giveValue.toLocaleString()} 🪙
            </div>
          </div>
          <div className="flex flex-wrap gap-2 justify-center md:justify-start min-h-[154px] items-center">
            {giveEntries.length === 0 ? (
              <div className="text-xs text-muted-foreground italic py-4">Nothing offered</div>
            ) : (
              giveEntries.map((e) => (
                <PlayerCard
                  key={`give-${e.playerId}__${e.versionId}`}
                  player={e.player}
                  version={e.version}
                  size="sm"
                />
              ))
            )}
          </div>
        </div>

        {/* Arrow */}
        <div className="flex items-center justify-center py-1 md:py-0">
          <div className="w-10 h-10 rounded-full bg-fl-neon/10 border border-fl-neon/40 flex items-center justify-center fl-glow-neon">
            <ArrowRight size={18} className="text-fl-neon rotate-90 md:rotate-0" />
          </div>
        </div>

        {/* WANTS */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-[10px] uppercase tracking-wider font-black text-fl-gold flex items-center gap-1">
              <ArrowLeftRight size={10} /> Wants From You
            </div>
            <div className="text-[10px] tabular-nums text-muted-foreground">
              {wantValue.toLocaleString()} 🪙
            </div>
          </div>
          <div className="flex flex-wrap gap-2 justify-center md:justify-start min-h-[154px] items-center">
            {wantEntries.length === 0 ? (
              <div className="text-xs text-muted-foreground italic py-4">No demands</div>
            ) : (
              wantEntries.map((e) => (
                <div key={`want-${e.playerId}__${e.versionId}`} className="relative">
                  <PlayerCard player={e.player} version={e.version} size="sm" />
                  <div
                    className={cn(
                      'absolute -top-1.5 -right-1.5 w-6 h-6 rounded-full flex items-center justify-center border-2 border-fl-navy z-30 shadow-lg',
                      e.owned
                        ? 'bg-fl-neon text-fl-navy fl-glow-neon'
                        : 'bg-red-500 text-white shadow-red-500/50'
                    )}
                  >
                    {e.owned ? <Check size={13} strokeWidth={3} /> : <X size={13} strokeWidth={3} />}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Value comparison bar */}
      <div className="px-4 pb-3">
        <div className="fl-glass rounded-lg p-2.5 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-muted-foreground">Net Value:</span>
            <span
              className={cn(
                'font-black tabular-nums',
                dealType === 'good' && 'text-fl-neon',
                dealType === 'bad' && 'text-red-300',
                dealType === 'fair' && 'text-fl-gold'
              )}
            >
              {delta >= 0 ? '+' : ''}
              {delta.toLocaleString()} 🪙
            </span>
            <span className="text-muted-foreground mx-1 hidden sm:inline">·</span>
            <span className="text-muted-foreground hidden sm:inline tabular-nums">
              ({giveValue.toLocaleString()} vs {wantValue.toLocaleString()})
            </span>
          </div>
          <div
            className={cn(
              'text-[10px] font-bold uppercase tracking-wider',
              dealType === 'good' && 'text-fl-neon',
              dealType === 'bad' && 'text-red-300',
              dealType === 'fair' && 'text-fl-gold'
            )}
          >
            {dealType === 'good' ? 'Profit' : dealType === 'bad' ? 'Loss' : 'Even'}
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="grid grid-cols-2 gap-2 p-4 pt-1 mt-auto">
        <button
          onClick={onReject}
          disabled={acting}
          className="py-2.5 rounded-lg font-bold text-sm bg-black/40 text-muted-foreground hover:bg-red-900/40 hover:text-red-200 border border-white/5 hover:border-red-500/30 transition-all flex items-center justify-center gap-1.5 disabled:opacity-60"
        >
          <X size={14} /> Reject
        </button>
        <button
          onClick={onAccept}
          disabled={!canAccept || acting}
          className={cn(
            'py-2.5 rounded-lg font-bold text-sm transition-all flex items-center justify-center gap-1.5',
            canAccept
              ? 'bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy hover:scale-[1.02] fl-glow-neon'
              : 'bg-black/40 text-muted-foreground cursor-not-allowed border border-white/5',
            acting && 'opacity-70 cursor-wait'
          )}
        >
          {acting ? (
            <RefreshCw size={14} className="animate-spin" />
          ) : (
            <Check size={14} />
          )}
          {!canAccept && hasWants
            ? 'Missing Cards'
            : !hasWants
              ? 'No Demands'
              : acting
                ? 'Processing…'
                : 'Accept Trade'}
        </button>
      </div>
    </motion.div>
  );
}
