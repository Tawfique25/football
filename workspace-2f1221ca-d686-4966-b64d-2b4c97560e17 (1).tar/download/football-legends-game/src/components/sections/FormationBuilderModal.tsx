'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Check, RotateCcw, Plus, Info, Hand } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { Position } from '@/lib/types';

// All selectable positions for the builder (matches the game's Position union)
const BUILDER_POSITIONS: { id: Position; label: string; group: 'GK' | 'DEF' | 'MID' | 'ATT' }[] = [
  { id: 'GK', label: 'GK', group: 'GK' },
  { id: 'CB', label: 'CB', group: 'DEF' },
  { id: 'LB', label: 'LB', group: 'DEF' },
  { id: 'RB', label: 'RB', group: 'DEF' },
  { id: 'CDM', label: 'CDM', group: 'MID' },
  { id: 'CM', label: 'CM', group: 'MID' },
  { id: 'CAM', label: 'CAM', group: 'MID' },
  { id: 'LM', label: 'LM', group: 'MID' },
  { id: 'RM', label: 'RM', group: 'MID' },
  { id: 'LW', label: 'LW', group: 'ATT' },
  { id: 'RW', label: 'RW', group: 'ATT' },
  { id: 'ST', label: 'ST', group: 'ATT' },
  { id: 'CF', label: 'CF', group: 'ATT' },
];

const POSITION_COLORS: Record<'GK' | 'DEF' | 'MID' | 'ATT', string> = {
  GK: '#fbbf24', // gold
  DEF: '#60a5fa', // blue
  MID: '#b3ff3a', // neon green
  ATT: '#fb7185', // red-pink
};

export interface BuilderSlot {
  position: string;
  x: number;
  y: number;
}

export interface FormationBuilderModalProps {
  open: boolean;
  /** Initial slots to seed the builder (used when editing an existing custom formation) */
  initialSlots?: BuilderSlot[];
  onSave: (slots: BuilderSlot[]) => void;
  onCancel: () => void;
}

const MIN_PLAYERS = 7;
const MAX_PLAYERS = 11;
const REQUIRED_GK = 1;
// Min distance (in %) between two slot centers to avoid overlapping click targets
const MIN_SLOT_DISTANCE = 6;

/**
 * Outer shell: handles mount/unmount + animations.
 * The inner <BuilderBody> is keyed by open so its useState is freshly seeded each time
 * the modal opens, which avoids setState-in-effect lint warnings and keeps state sync clean.
 */
export function FormationBuilderModal({ open, initialSlots, onSave, onCancel }: FormationBuilderModalProps) {
  return (
    <AnimatePresence>
      {open && (
        <BuilderBody
          key="formation-builder"
          initialSlots={initialSlots ?? []}
          onSave={onSave}
          onCancel={onCancel}
        />
      )}
    </AnimatePresence>
  );
}

function BuilderBody({
  initialSlots,
  onSave,
  onCancel,
}: {
  initialSlots: BuilderSlot[];
  onSave: (slots: BuilderSlot[]) => void;
  onCancel: () => void;
}) {
  const { toast } = useToast();
  const [slots, setSlots] = useState<BuilderSlot[]>(() =>
    initialSlots.length > 0 ? initialSlots.map((s) => ({ ...s })) : []
  );
  const [selectedPosition, setSelectedPosition] = useState<Position>('GK');
  const [hoverPoint, setHoverPoint] = useState<{ x: number; y: number } | null>(null);
  const [removingIdx, setRemovingIdx] = useState<number | null>(null);
  const pitchRef = useRef<HTMLDivElement | null>(null);

  // Close on Escape + lock body scroll. Pure side-effect (no setState), so no lint warning.
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onCancel();
    };
    window.addEventListener('keydown', handler);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handler);
      document.body.style.overflow = prevOverflow;
    };
  }, [onCancel]);

  const gkCount = slots.filter((s) => s.position === 'GK').length;
  const canPlaceGK = gkCount < REQUIRED_GK;
  const isGKSelected = selectedPosition === 'GK';
  const atCapacity = slots.length >= MAX_PLAYERS;
  const valid =
    slots.length >= MIN_PLAYERS &&
    slots.length <= MAX_PLAYERS &&
    gkCount === REQUIRED_GK;

  const convertClickToSlot = useCallback(
    (clientX: number, clientY: number): { x: number; y: number } | null => {
      const el = pitchRef.current;
      if (!el) return null;
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return null;
      const px = ((clientX - rect.left) / rect.width) * 100;
      const py = ((clientY - rect.top) / rect.height) * 100;
      // Clamp to a safe range so players aren't visually clipped at the edges
      const x = Math.max(5, Math.min(95, px));
      // Convert visual top % to slot.y (y=100 is goalkeeper area at top of screen)
      const slotY = Math.max(5, Math.min(95, 100 - py));
      return { x: Math.round(x * 100) / 100, y: Math.round(slotY * 100) / 100 };
    },
    []
  );

  const handlePitchClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (atCapacity) {
      toast({
        title: 'Pitch full',
        description: `Maximum of ${MAX_PLAYERS} players. Remove one before adding more.`,
        variant: 'destructive',
      });
      return;
    }
    if (isGKSelected && !canPlaceGK) {
      toast({
        title: 'GK already placed',
        description: 'Only one goalkeeper is allowed. Pick another position.',
        variant: 'destructive',
      });
      return;
    }
    const point = convertClickToSlot(e.clientX, e.clientY);
    if (!point) return;
    // Reject clicks that overlap with existing slots
    const tooClose = slots.some((s) => {
      const dx = s.x - point.x;
      const dy = s.y - point.y;
      return Math.sqrt(dx * dx + dy * dy) < MIN_SLOT_DISTANCE;
    });
    if (tooClose) {
      toast({
        title: 'Too close to another position',
        description: 'Space your players out a little.',
        variant: 'destructive',
      });
      return;
    }
    setSlots((prev) => [...prev, { position: selectedPosition, x: point.x, y: point.y }]);
    // Auto-advance: switch to a sensible next position
    if (isGKSelected) {
      setSelectedPosition('CB');
    }
  };

  const handleSlotClick = (idx: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setRemovingIdx(idx);
    // Defer the actual removal slightly so the exit animation can play
    window.setTimeout(() => {
      setSlots((prev) => prev.filter((_, i) => i !== idx));
      setRemovingIdx(null);
    }, 120);
  };

  const handleClear = () => {
    setSlots([]);
    setSelectedPosition('GK');
    toast({ title: 'Cleared', description: 'All positions removed.' });
  };

  const handleSave = () => {
    if (!valid) return;
    onSave(slots);
  };

  const handlePitchMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (atCapacity) {
      setHoverPoint(null);
      return;
    }
    if (isGKSelected && !canPlaceGK) {
      setHoverPoint(null);
      return;
    }
    const point = convertClickToSlot(e.clientX, e.clientY);
    if (!point) return;
    setHoverPoint(point);
  };

  const handlePitchLeave = () => setHoverPoint(null);

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 md:p-6 overflow-auto"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onCancel}
    >
      <motion.div
        className="relative w-full max-w-5xl fl-glass-strong rounded-2xl border border-white/10 fl-card-shadow"
        initial={{ scale: 0.95, y: 20, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        exit={{ scale: 0.95, y: 20, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 320, damping: 26 }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-3 p-4 md:p-5 border-b border-white/10">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-fl-neon/15 text-fl-neon flex items-center justify-center flex-shrink-0">
              <Plus size={20} />
            </div>
            <div className="min-w-0">
              <h2 className="text-xl md:text-2xl font-black tracking-tight fl-text-shadow-neon">
                Formation Builder
              </h2>
              <p className="text-[11px] md:text-xs text-muted-foreground truncate">
                Design your own formation — place {MIN_PLAYERS}–{MAX_PLAYERS} players, exactly 1 GK.
              </p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="p-2 rounded-lg bg-black/40 hover:bg-red-500/20 transition-colors flex-shrink-0"
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 md:p-5 grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-4 max-h-[80vh] overflow-y-auto fl-scroll">
          {/* Pitch column */}
          <div className="flex flex-col gap-3">
            {/* Instructions */}
            <div className="flex items-start gap-2 p-3 rounded-lg bg-fl-neon/5 border border-fl-neon/20 text-[11px] md:text-xs text-muted-foreground">
              <Info size={14} className="text-fl-neon flex-shrink-0 mt-0.5" />
              <span>
                Click anywhere on the pitch to add a player of the selected position. Click an existing
                position to remove it. You must place exactly{' '}
                <span className="text-fl-neon font-bold">1 GK</span> and between{' '}
                <span className="text-fl-neon font-bold">
                  {MIN_PLAYERS}–{MAX_PLAYERS}
                </span>{' '}
                players.
              </span>
            </div>

            {/* Pitch */}
            <div
              ref={pitchRef}
              onClick={handlePitchClick}
              onMouseMove={handlePitchMove}
              onMouseLeave={handlePitchLeave}
              className={cn(
                'relative fl-pitch rounded-xl overflow-hidden select-none',
                atCapacity
                  ? 'cursor-not-allowed'
                  : isGKSelected && !canPlaceGK
                    ? 'cursor-not-allowed'
                    : 'cursor-crosshair'
              )}
              style={{ aspectRatio: '0.7', minHeight: 460 }}
            >
              <PitchMarkings />

              {/* Hover ghost */}
              {hoverPoint && !atCapacity && !(isGKSelected && !canPlaceGK) && (
                <div
                  className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none"
                  style={{ left: `${hoverPoint.x}%`, top: `${100 - hoverPoint.y}%`, zIndex: 3 }}
                >
                  <div
                    className="w-12 h-12 md:w-14 md:h-14 rounded-full border-2 border-dashed flex items-center justify-center opacity-50"
                    style={{
                      borderColor:
                        POSITION_COLORS[
                          BUILDER_POSITIONS.find((p) => p.id === selectedPosition)?.group ?? 'MID'
                        ],
                    }}
                  >
                    <span
                      className="text-[11px] font-black"
                      style={{
                        color:
                          POSITION_COLORS[
                            BUILDER_POSITIONS.find((p) => p.id === selectedPosition)?.group ?? 'MID'
                          ],
                      }}
                    >
                      {selectedPosition}
                    </span>
                  </div>
                </div>
              )}

              {/* Placed slots */}
              {slots.map((slot, idx) => {
                const meta = BUILDER_POSITIONS.find((p) => p.id === slot.position);
                const color = POSITION_COLORS[meta?.group ?? 'MID'];
                const top = 100 - slot.y;
                return (
                  <motion.button
                    key={`${idx}-${slot.position}-${slot.x}-${slot.y}`}
                    type="button"
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: removingIdx === idx ? 0 : 1, opacity: removingIdx === idx ? 0 : 1 }}
                    exit={{ scale: 0, opacity: 0 }}
                    transition={{ type: 'spring', stiffness: 360, damping: 22 }}
                    whileHover={{ scale: 1.12 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={(e) => handleSlotClick(idx, e)}
                    className="absolute -translate-x-1/2 -translate-y-1/2 group focus:outline-none"
                    style={{ left: `${slot.x}%`, top: `${top}%`, zIndex: 5 }}
                    title={`${slot.position} — click to remove`}
                  >
                    <div
                      className="w-12 h-12 md:w-14 md:h-14 rounded-full flex flex-col items-center justify-center border-2"
                      style={{
                        borderColor: color,
                        background: 'rgba(0,0,0,0.65)',
                        boxShadow: `0 0 14px ${color}55, 0 0 0 4px rgba(0,0,0,0.25)`,
                      }}
                    >
                      <span className="text-xs font-black" style={{ color }}>
                        {slot.position}
                      </span>
                    </div>
                    {/* Remove indicator */}
                    <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-red-500 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity border border-black/60">
                      <X size={11} />
                    </span>
                  </motion.button>
                );
              })}

              {/* Empty hint */}
              {slots.length === 0 && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="flex flex-col items-center gap-2 text-white/70">
                    <Hand size={28} className="opacity-60" />
                    <span className="text-xs font-semibold tracking-wide uppercase">
                      Tap the pitch to begin
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Legend */}
            <div className="flex items-center justify-between flex-wrap gap-2 text-[10px] md:text-xs">
              <div className="flex items-center gap-3">
                {(['GK', 'DEF', 'MID', 'ATT'] as const).map((g) => (
                  <span key={g} className="flex items-center gap-1.5">
                    <span
                      className="w-2.5 h-2.5 rounded-full inline-block"
                      style={{ background: POSITION_COLORS[g] }}
                    />
                    <span className="text-muted-foreground">
                      {g === 'GK'
                        ? 'Goalkeeper'
                        : g === 'DEF'
                          ? 'Defense'
                          : g === 'MID'
                            ? 'Midfield'
                            : 'Attack'}
                    </span>
                  </span>
                ))}
              </div>
              <div className="text-muted-foreground">y-axis: top = goalkeeper, bottom = attack</div>
            </div>
          </div>

          {/* Side panel */}
          <div className="flex flex-col gap-3">
            {/* Position selector */}
            <div className="fl-glass rounded-xl p-3">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">
                Position to place
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {BUILDER_POSITIONS.map((p) => {
                  const color = POSITION_COLORS[p.group];
                  const isSelected = selectedPosition === p.id;
                  const isGKDisabled = p.id === 'GK' && !canPlaceGK;
                  return (
                    <button
                      key={p.id}
                      type="button"
                      disabled={isGKDisabled}
                      onClick={() => setSelectedPosition(p.id)}
                      className={cn(
                        'py-2 rounded-md text-[11px] font-black transition-all border',
                        isSelected
                          ? 'border-2'
                          : 'border border-white/10 bg-black/30 hover:bg-white/5',
                        isGKDisabled && 'opacity-30 cursor-not-allowed line-through'
                      )}
                      style={
                        isSelected
                          ? {
                              color,
                              borderColor: color,
                              background: `${color}22`,
                              boxShadow: `0 0 10px ${color}55`,
                            }
                          : { color }
                      }
                    >
                      {p.label}
                    </button>
                  );
                })}
              </div>
              {isGKSelected && !canPlaceGK && (
                <div className="mt-2 text-[10px] text-fl-gold/80">
                  GK already placed. Choose an outfield position.
                </div>
              )}
            </div>

            {/* Counter */}
            <div className="fl-glass rounded-xl p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  Players
                </span>
                <span
                  className={cn(
                    'text-2xl font-black tabular-nums',
                    valid
                      ? 'text-fl-neon'
                      : slots.length > MAX_PLAYERS
                        ? 'text-red-400'
                        : 'text-fl-gold'
                  )}
                >
                  {slots.length}
                  <span className="text-base text-muted-foreground font-bold">/{MAX_PLAYERS}</span>
                </span>
              </div>
              <div className="h-2 rounded-full bg-black/40 overflow-hidden">
                <motion.div
                  className={cn('h-full', valid ? 'bg-fl-neon' : 'bg-fl-gold')}
                  animate={{ width: `${Math.min(100, (slots.length / MAX_PLAYERS) * 100)}%` }}
                  transition={{ type: 'spring', stiffness: 220, damping: 24 }}
                />
              </div>
              <div className="mt-2 flex items-center justify-between text-[10px] text-muted-foreground">
                <span>
                  GK:{' '}
                  <span className={gkCount === 1 ? 'text-fl-neon font-bold' : 'text-fl-gold font-bold'}>
                    {gkCount}/1
                  </span>
                </span>
                <span>Min: {MIN_PLAYERS}</span>
              </div>
            </div>

            {/* Validation status */}
            <div className="fl-glass rounded-xl p-3 text-xs space-y-1.5">
              <ValidationRow ok={slots.length >= MIN_PLAYERS} label={`At least ${MIN_PLAYERS} players`} />
              <ValidationRow ok={slots.length <= MAX_PLAYERS} label={`At most ${MAX_PLAYERS} players`} />
              <ValidationRow ok={gkCount === REQUIRED_GK} label={`Exactly ${REQUIRED_GK} GK`} />
            </div>

            {/* Action buttons */}
            <div className="flex flex-col gap-2 mt-auto">
              <button
                onClick={handleSave}
                disabled={!valid}
                className={cn(
                  'w-full px-4 py-3 rounded-lg font-black text-sm flex items-center justify-center gap-2 transition-all',
                  valid
                    ? 'bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy hover:scale-[1.02] fl-glow-neon'
                    : 'bg-black/40 text-muted-foreground cursor-not-allowed'
                )}
              >
                <Check size={16} /> Save Formation
              </button>
              <div className="flex gap-2">
                <button
                  onClick={handleClear}
                  disabled={slots.length === 0}
                  className={cn(
                    'flex-1 px-3 py-2 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1.5',
                    slots.length === 0
                      ? 'bg-black/30 text-muted-foreground cursor-not-allowed'
                      : 'bg-black/40 hover:bg-red-500/20'
                  )}
                >
                  <RotateCcw size={12} /> Clear All
                </button>
                <button
                  onClick={onCancel}
                  className="flex-1 px-3 py-2 rounded-lg bg-black/40 hover:bg-white/10 text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                >
                  <X size={12} /> Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

function ValidationRow({ ok, label }: { ok: boolean; label: string }) {
  return (
    <div className="flex items-center gap-2">
      <span
        className={cn(
          'w-4 h-4 rounded-full flex items-center justify-center border',
          ok
            ? 'bg-fl-neon/20 border-fl-neon text-fl-neon'
            : 'bg-black/30 border-white/20 text-muted-foreground'
        )}
      >
        {ok ? <Check size={10} /> : <span className="text-[9px]">•</span>}
      </span>
      <span className={ok ? 'text-foreground' : 'text-muted-foreground'}>{label}</span>
    </div>
  );
}

// Local copy of the pitch markings (mirrors DreamTeam.tsx) so the modal is self-contained.
function PitchMarkings() {
  return (
    <div className="absolute inset-0 pointer-events-none">
      <div className="absolute inset-2 border-2 border-white/30 rounded-md" />
      <div className="absolute left-2 right-2 top-1/2 h-0.5 bg-white/30" />
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 border-2 border-white/30 rounded-full" />
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-white/40 rounded-full" />
      <div className="absolute left-1/2 -translate-x-1/2 top-2 w-40 h-12 border-2 border-white/30 border-t-0" />
      <div className="absolute left-1/2 -translate-x-1/2 top-2 w-20 h-6 border-2 border-white/30 border-t-0" />
      <div className="absolute left-1/2 -translate-x-1/2 top-12 w-1 h-1 bg-white/40 rounded-full" />
      <div className="absolute left-1/2 -translate-x-1/2 bottom-2 w-40 h-12 border-2 border-white/30 border-b-0" />
      <div className="absolute left-1/2 -translate-x-1/2 bottom-2 w-20 h-6 border-2 border-white/30 border-b-0" />
      <div className="absolute left-1/2 -translate-x-1/2 bottom-12 w-1 h-1 bg-white/40 rounded-full" />
    </div>
  );
}
