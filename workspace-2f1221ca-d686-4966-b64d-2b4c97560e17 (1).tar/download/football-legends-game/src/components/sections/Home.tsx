'use client';

import { useGame } from '@/lib/store';
import { PlayerCard } from '@/components/cards/PlayerCard';
import { SectionHeader } from '@/components/ui-fl/shared';
import { BOX_PACKS, getPackTierCounts } from '@/lib/box-packs';
import { getFormation } from '@/lib/formations';
import { calculateTeamRating, calculateChemistry } from '@/lib/formations';
import { ACHIEVEMENTS, getAchievementProgress, isAchievementComplete } from '@/lib/achievements';
import { motion } from 'framer-motion';
import { Home as HomeIcon, Package, Sparkles, Calendar, ChevronRight, Trophy, Gift } from 'lucide-react';
import { useEffect, useState } from 'react';
import { DAILY_REWARDS } from '@/lib/store';

interface HomeProps {
  onNavigate: (section: string, payload?: any) => void;
}

export function HomeSection({ onNavigate }: HomeProps) {
  const coins = useGame((s) => s.coins);
  const level = useGame((s) => s.level);
  const xp = useGame((s) => s.xp);
  const collection = useGame((s) => s.collection);
  const formationId = useGame((s) => s.formationId);
  const customFormation = useGame((s) => s.customFormation);
  const matchesWon = useGame((s) => s.matchesWon);
  const loginStreak = useGame((s) => s.loginStreak);
  const lookupCard = useGame((s) => s.lookupCard);
  const claimDailyLogin = useGame((s) => s.claimDailyLogin);
  const canClaimDailySpin = useGame((s) => s.canClaimDailySpin);
  const resolveSquad = useGame((s) => s.resolveSquad);
  const lastLoginReward = useGame((s) => s.lastLoginReward);
  const todayKey = new Date().toISOString().slice(0, 10);
  const canClaimLogin = lastLoginReward !== todayKey;

  const [loginClaimed, setLoginClaimed] = useState<{ coins: number; day: number } | null>(null);

  const squad = resolveSquad();
  const teamRating = calculateTeamRating(formationId, squad, customFormation);
  const formation = getFormation(formationId, customFormation);

  // Latest acquired card
  const sortedCollection = [...collection].sort(
    (a, b) => new Date(b.lastAcquiredAt).getTime() - new Date(a.lastAcquiredAt).getTime()
  );
  const latestCard = sortedCollection[0] ? lookupCard(sortedCollection[0].id) : undefined;

  // Featured box-draw packs
  const featuredPacks = BOX_PACKS.slice(0, 5);

  // Recent achievements (top 3 unclaimed, closest to complete)
  const recentAchievements = ACHIEVEMENTS.filter((a) => !useGame.getState().achievementsClaimed.includes(a.id))
    .map((a) => ({ a, p: getAchievementProgress(a, useGame.getState()) }))
    .sort((x, y) => (y.p / y.a.goal) - (x.p / x.a.goal))
    .slice(0, 3);

  // XP progress to next level
  const xpForCurrent = (level - 1) * 200;
  const xpForNext = level * 200;
  const xpProgress = ((xp - xpForCurrent) / 200) * 100;

  const handleClaimLogin = () => {
    const r = claimDailyLogin();
    if (r.claimed) {
      setLoginClaimed({ coins: r.coins, day: r.day });
      setTimeout(() => setLoginClaimed(null), 2500);
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl fl-glass-strong p-6 md:p-8 fl-grid-bg"
      >
        <div className="absolute inset-0 fl-shimmer pointer-events-none opacity-30" />
        <div className="relative flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-fl-neon mb-2">
              <Sparkles size={16} />
              <span className="text-xs uppercase tracking-widest font-bold">Welcome back, Manager</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-black tracking-tight mb-2 fl-text-shadow-neon">
              FOOTBALL <span className="fl-text-gold">LEGENDS</span>
            </h1>
            <p className="text-muted-foreground text-sm md:text-base max-w-xl">
              Build your <span className="text-fl-neon font-bold">Dream XI</span> from the greatest footballers of all time. Spin packs, collect legends, and conquer the pitch.
            </p>
          </div>
          {/* Level + XP bar */}
          <div className="fl-glass rounded-2xl p-4 min-w-[200px]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs uppercase tracking-wider text-muted-foreground">Manager Level</span>
              <span className="font-black text-fl-neon text-lg">{level}</span>
            </div>
            <div className="h-2 bg-black/40 rounded-full overflow-hidden">
              <motion.div
                className="h-full rounded-full"
                style={{ background: 'linear-gradient(90deg, #b3ff3a 0%, #fbbf24 100%)' }}
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, xpProgress)}%` }}
                transition={{ duration: 0.6, ease: 'easeOut' }}
              />
            </div>
            <div className="text-xs text-muted-foreground mt-1.5">
              {xp - xpForCurrent} / 200 XP to level {level + 1}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Daily reward + spin banner */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Daily Login Reward */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="fl-glass rounded-2xl p-5 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 opacity-10">
            <Calendar size={120} />
          </div>
          <div className="relative">
            <div className="flex items-center gap-2 mb-2">
              <Gift size={18} className="text-fl-gold" />
              <h3 className="font-black uppercase tracking-wide text-fl-gold">Daily Login Reward</h3>
            </div>
            <p className="text-xs text-muted-foreground mb-3">Login streak: Day {loginStreak}/7</p>
            <div className="grid grid-cols-7 gap-1.5 mb-4">
              {DAILY_REWARDS.map((r) => {
                const claimed = loginStreak >= r.day;
                const isToday = loginStreak === r.day - 1 && canClaimLogin;
                return (
                  <div
                    key={r.day}
                    className={`aspect-square rounded-lg flex flex-col items-center justify-center text-center p-1 ${
                      claimed
                        ? 'bg-fl-neon/20 border border-fl-neon/50'
                        : isToday
                        ? 'bg-fl-gold/30 border-2 border-fl-gold fl-glow-gold'
                        : 'bg-black/30 border border-white/5'
                    }`}
                  >
                    <div className="text-[9px] uppercase opacity-70">{r.day === 7 ? '7★' : r.day}</div>
                    <div className="text-[10px] font-black tabular-nums">{r.coins}</div>
                  </div>
                );
              })}
            </div>
            <button
              onClick={handleClaimLogin}
              disabled={!canClaimLogin}
              className={`w-full py-2.5 rounded-lg font-black text-sm transition-all ${
                canClaimLogin
                  ? 'bg-gradient-to-r from-fl-gold-deep to-fl-gold text-fl-navy hover:scale-[1.02] fl-glow-gold'
                  : 'bg-black/40 text-muted-foreground cursor-not-allowed'
              }`}
            >
              {canClaimLogin
                ? `CLAIM ${DAILY_REWARDS[Math.min(loginStreak, 6)].coins} COINS`
                : '✓ CLAIMED TODAY'}
            </button>
          </div>
          {loginClaimed && (
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              className="absolute top-2 right-2 bg-fl-gold text-fl-navy px-3 py-1.5 rounded-lg font-black text-sm fl-glow-gold"
            >
              +{loginClaimed.coins} 🪙 Day {loginClaimed.day}!
            </motion.div>
          )}
        </motion.div>

        {/* Daily Free Spin */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="fl-glass rounded-2xl p-5 relative overflow-hidden flex flex-col"
        >
          <div className="absolute top-0 right-0 opacity-10">
            <Sparkles size={120} />
          </div>
          <div className="relative flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Package size={18} className="text-fl-neon" />
              <h3 className="font-black uppercase tracking-wide text-fl-neon">Daily Free Spin</h3>
            </div>
            <p className="text-xs text-muted-foreground mb-4">
              One free spin every day. Guaranteed at least a <span className="text-fl-neon font-bold">Rare</span> player + 100 bonus coins.
            </p>
            <div className="flex items-center justify-center mb-4">
              <motion.div
                animate={canClaimDailySpin() ? { rotate: [0, 360] } : {}}
                transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
                className="text-7xl"
              >
                🎡
              </motion.div>
            </div>
          </div>
          <button
            onClick={() => onNavigate('packs', { openDaily: true })}
            disabled={!canClaimDailySpin()}
            className={`w-full py-2.5 rounded-lg font-black text-sm transition-all ${
              canClaimDailySpin()
                ? 'bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy hover:scale-[1.02] fl-glow-neon'
                : 'bg-black/40 text-muted-foreground cursor-not-allowed'
            }`}
          >
            {canClaimDailySpin() ? '🎰 SPIN NOW' : '✓ SPUN TODAY — COME BACK TOMORROW'}
          </button>
        </motion.div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatTile label="Coins" value={coins.toLocaleString()} icon="🪙" color="gold" />
        <StatTile label="Team OVR" value={teamRating.filled > 0 ? teamRating.overall : '—'} icon="⚽" color="neon" />
        <StatTile label="Chemistry" value={`${teamRating.chemistry}%`} icon="🧪" color="blue" />
        <StatTile label="Collection" value={collection.length} icon="🃏" color="gold" />
      </div>

      {/* Latest acquired + Squad preview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Latest acquired */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fl-glass rounded-2xl p-5"
        >
          <h3 className="font-black uppercase tracking-wide text-fl-gold mb-4 flex items-center gap-2">
            <Sparkles size={16} /> Latest Acquisition
          </h3>
          {latestCard ? (
            <div className="flex justify-center">
              <PlayerCard player={latestCard.player} version={latestCard.version} size="md" isNew />
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground text-sm">
              <div className="text-4xl mb-2">📦</div>
              No cards yet. Open your first pack!
            </div>
          )}
          {latestCard && (
            <button
              onClick={() => onNavigate('club')}
              className="w-full mt-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-sm font-bold transition-colors flex items-center justify-center gap-1"
            >
              View Collection <ChevronRight size={14} />
            </button>
          )}
        </motion.div>

        {/* Squad preview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="fl-glass rounded-2xl p-5 lg:col-span-2"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-black uppercase tracking-wide text-fl-neon flex items-center gap-2">
              <Trophy size={16} /> Your Squad — {formation.name}
            </h3>
            <button
              onClick={() => onNavigate('team')}
              className="text-xs text-fl-neon hover:underline flex items-center gap-1"
            >
              Manage <ChevronRight size={12} />
            </button>
          </div>
          {teamRating.filled > 0 ? (
            <div>
              <div className="flex flex-wrap gap-3 mb-3">
                <RatingTile label="OVR" value={teamRating.overall} color="neon" />
                <RatingTile label="ATT" value={teamRating.attack} color="gold" />
                <RatingTile label="MID" value={teamRating.midfield} color="blue" />
                <RatingTile label="DEF" value={teamRating.defense} color="gold" />
                <RatingTile label="CHEM" value={`${teamRating.chemistry}%`} color="neon" />
              </div>
              <div className="fl-pitch rounded-xl p-3 relative" style={{ height: 220 }}>
                <SquadMiniPreview formationId={formationId} squad={squad} />
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="text-4xl mb-2">👥</div>
              <p className="text-muted-foreground text-sm mb-3">No players in your squad yet.</p>
              <button
                onClick={() => onNavigate('team')}
                className="px-4 py-2 rounded-lg bg-fl-neon text-fl-navy font-bold text-sm hover:scale-105 transition-transform"
              >
                Build Your Dream XI
              </button>
            </div>
          )}
        </motion.div>
      </div>

      {/* Featured packs */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="fl-glass rounded-2xl p-5"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-black uppercase tracking-wide text-fl-gold flex items-center gap-2">
            <Package size={16} /> Featured Packs
          </h3>
          <button
            onClick={() => onNavigate('packs')}
            className="text-xs text-fl-neon hover:underline flex items-center gap-1"
          >
            View All <ChevronRight size={12} />
          </button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {featuredPacks.map((p) => {
            const tiers = getPackTierCounts(p);
            return (
              <button
                key={p.id}
                onClick={() => onNavigate('packs')}
                className="relative overflow-hidden rounded-xl p-4 text-left transition-all hover:scale-105 hover:-translate-y-1 group"
                style={{
                  background: p.gradient,
                  border: `1.5px solid ${p.accent}`,
                  boxShadow: `0 4px 16px ${p.accent}33`,
                  minHeight: 140,
                }}
              >
                <div className="absolute top-2 right-2 bg-black/50 backdrop-blur-sm px-2 py-0.5 rounded-full text-[9px] font-black tracking-wider">
                  {p.theme}
                </div>
                <div className="text-3xl mb-2">🎁</div>
                <div className="font-black text-sm leading-tight mb-1 drop-shadow-md">{p.name}</div>
                <div className="text-xs opacity-80 mb-2">150 players</div>
                <div className="absolute bottom-2 right-2 flex items-center gap-1 bg-black/60 px-2 py-0.5 rounded-full text-xs font-black">
                  🪙 100/1K
                </div>
                <div className="absolute bottom-2 left-2 flex gap-1 text-[8px] font-bold">
                  <span className="bg-black/50 px-1 rounded">👑{tiers.epic}</span>
                  <span className="bg-black/50 px-1 rounded">⭐{tiers.highlight}</span>
                </div>
              </button>
            );
          })}
        </div>
      </motion.div>

      {/* Recent achievements */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="fl-glass rounded-2xl p-5"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-black uppercase tracking-wide text-fl-gold flex items-center gap-2">
            <Trophy size={16} /> Recent Achievements
          </h3>
          <button
            onClick={() => onNavigate('achievements')}
            className="text-xs text-fl-neon hover:underline flex items-center gap-1"
          >
            View All <ChevronRight size={12} />
          </button>
        </div>
        <div className="space-y-2">
          {recentAchievements.map(({ a, p }) => {
            const pct = Math.min(100, (p / a.goal) * 100);
            return (
              <div key={a.id} className="bg-black/30 rounded-lg p-3 flex items-center gap-3">
                <div className="text-2xl">{a.icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-sm truncate">{a.name}</span>
                    <span className="text-xs text-fl-gold font-bold whitespace-nowrap">+{a.reward} 🪙</span>
                  </div>
                  <div className="text-xs text-muted-foreground truncate mb-1">{a.description}</div>
                  <div className="h-1.5 bg-black/40 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-fl-neon-dim to-fl-neon"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">
                    {p} / {a.goal}
                  </div>
                </div>
              </div>
            );
          })}
          {recentAchievements.length === 0 && (
            <div className="text-center py-6 text-muted-foreground text-sm">
              All achievements claimed! 🎉
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}

function StatTile({ label, value, icon, color }: { label: string; value: any; icon: string; color: 'gold' | 'neon' | 'blue' }) {
  const colorMap = { gold: 'text-fl-gold', neon: 'text-fl-neon', blue: 'text-blue-400' };
  return (
    <div className="fl-glass rounded-xl p-4 flex items-center gap-3">
      <div className="text-3xl">{icon}</div>
      <div>
        <div className={`text-2xl font-black tabular-nums ${colorMap[color]}`}>{value}</div>
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      </div>
    </div>
  );
}

function RatingTile({ label, value, color }: { label: string; value: any; color: 'gold' | 'neon' | 'blue' }) {
  const colorMap = {
    gold: 'border-fl-gold text-fl-gold',
    neon: 'border-fl-neon text-fl-neon',
    blue: 'border-blue-400 text-blue-400',
  };
  return (
    <div className={`px-3 py-1.5 rounded-lg bg-black/30 border ${colorMap[color]} text-center`}>
      <div className="text-[10px] uppercase tracking-wider opacity-80">{label}</div>
      <div className="text-lg font-black tabular-nums">{value}</div>
    </div>
  );
}

/** Mini squad preview on home */
function SquadMiniPreview({ formationId, squad }: { formationId: string; squad: any[] }) {
  const customFormation = useGame((s) => s.customFormation);
  const formation = getFormation(formationId, customFormation);
  return (
    <div className="relative w-full h-full">
      {formation.slots.map((slot, i) => {
        const entry = squad[i];
        const top = 100 - slot.y;
        return (
          <div
            key={i}
            className="absolute -translate-x-1/2 -translate-y-1/2"
            style={{ left: `${slot.x}%`, top: `${top}%` }}
          >
            {entry ? (
              <div className="w-10 h-10 rounded-full bg-fl-neon text-fl-navy flex items-center justify-center font-black text-xs border-2 border-white/80 fl-glow-neon">
                {entry.version.ovr}
              </div>
            ) : (
              <div className="w-10 h-10 rounded-full bg-black/50 border border-white/30 flex items-center justify-center text-[9px] text-white/60 font-bold">
                {slot.position}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
