'use client';

import { useState } from 'react';
import { useAuth } from '@/lib/auth-context';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, Lock, User, LogOut, X, Loader2, AlertCircle, Trophy } from 'lucide-react';
import { cn } from '@/lib/utils';

export function AuthButton() {
  const { user, profile, signOut, isFirebaseReady } = useAuth();
  const [showModal, setShowModal] = useState(false);

  if (!isFirebaseReady) {
    // Firebase not configured — don't show auth UI
    return null;
  }

  if (user) {
    return (
      <div className="flex items-center gap-2">
        <div className="fl-glass rounded-lg px-3 py-1.5 flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-fl-neon to-fl-neon-dim flex items-center justify-center text-fl-navy font-black text-xs">
            {(profile?.displayName || user.email || 'M')[0].toUpperCase()}
          </div>
          <div className="hidden sm:flex flex-col leading-tight">
            <span className="text-xs font-bold">{profile?.displayName || 'Manager'}</span>
            <span className="text-[9px] text-muted-foreground truncate max-w-[120px]">{user.email}</span>
          </div>
        </div>
        <button
          onClick={() => signOut()}
          className="p-2 rounded-lg bg-black/40 hover:bg-red-500/20 transition-colors"
          title="Sign out"
        >
          <LogOut size={16} />
        </button>
      </div>
    );
  }

  return (
    <>
      <button
        onClick={() => setShowModal(true)}
        className="px-4 py-2 rounded-lg bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy font-black text-sm hover:scale-105 transition-transform fl-glow-neon flex items-center gap-2"
      >
        <Trophy size={14} />
        Sign In
      </button>
      <AnimatePresence>
        {showModal && <AuthModal onClose={() => setShowModal(false)} />}
      </AnimatePresence>
    </>
  );
}

function AuthModal({ onClose }: { onClose: () => void }) {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const result = mode === 'signin'
      ? await signIn(email, password)
      : await signUp(email, password, displayName || 'Manager');

    setLoading(false);

    if (result.success) {
      onClose();
    } else {
      setError(result.error || 'Something went wrong');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="fl-glass-strong rounded-2xl p-6 max-w-md w-full relative"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-3 right-3 p-2 rounded-lg bg-black/40 hover:bg-black/60 transition-colors"
        >
          <X size={18} />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
            className="text-4xl mb-2 inline-block"
          >
            ⚽
          </motion.div>
          <h2 className="text-2xl font-black fl-text-shadow-neon">
            {mode === 'signin' ? 'Welcome Back' : 'Join the Game'}
          </h2>
          <p className="text-xs text-muted-foreground mt-1">
            {mode === 'signin'
              ? 'Sign in to sync your progress across devices'
              : 'Create an account to save your collection online'}
          </p>
        </div>

        {/* Mode toggle */}
        <div className="flex gap-1 mb-4 bg-black/30 rounded-lg p-1">
          <button
            onClick={() => { setMode('signin'); setError(null); }}
            className={cn(
              'flex-1 py-2 rounded-md text-sm font-bold transition-colors',
              mode === 'signin' ? 'bg-fl-neon text-fl-navy' : 'text-muted-foreground hover:text-foreground'
            )}
          >
            Sign In
          </button>
          <button
            onClick={() => { setMode('signup'); setError(null); }}
            className={cn(
              'flex-1 py-2 rounded-md text-sm font-bold transition-colors',
              mode === 'signup' ? 'bg-fl-neon text-fl-navy' : 'text-muted-foreground hover:text-foreground'
            )}
          >
            Sign Up
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3">
          {mode === 'signup' && (
            <div>
              <label className="text-xs uppercase tracking-wider text-muted-foreground mb-1 block">Manager Name</label>
              <div className="relative">
                <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Your manager name"
                  className="w-full pl-10 pr-3 py-2.5 rounded-lg bg-black/30 border border-white/10 text-sm focus:outline-none focus:border-fl-neon transition-colors"
                  required
                />
              </div>
            </div>
          )}

          <div>
            <label className="text-xs uppercase tracking-wider text-muted-foreground mb-1 block">Email</label>
            <div className="relative">
              <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full pl-10 pr-3 py-2.5 rounded-lg bg-black/30 border border-white/10 text-sm focus:outline-none focus:border-fl-neon transition-colors"
                required
              />
            </div>
          </div>

          <div>
            <label className="text-xs uppercase tracking-wider text-muted-foreground mb-1 block">Password</label>
            <div className="relative">
              <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-3 py-2.5 rounded-lg bg-black/30 border border-white/10 text-sm focus:outline-none focus:border-fl-neon transition-colors"
                required
                minLength={6}
              />
            </div>
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2 p-2.5 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-xs"
            >
              <AlertCircle size={14} className="flex-shrink-0" />
              <span>{error}</span>
            </motion.div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-lg bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy font-black text-sm hover:scale-[1.02] transition-transform disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 fl-glow-neon"
          >
            {loading ? (
              <>
                <Loader2 size={16} className="animate-spin" />
                {mode === 'signin' ? 'Signing in...' : 'Creating account...'}
              </>
            ) : (
              mode === 'signin' ? 'Sign In' : 'Create Account'
            )}
          </button>
        </form>

        <p className="text-[10px] text-muted-foreground text-center mt-4">
          {mode === 'signup'
            ? 'By signing up, your game progress will be saved to your account and synced across devices.'
            : 'Don\'t have an account? Switch to Sign Up above.'}
        </p>
      </motion.div>
    </motion.div>
  );
}
