'use client';

import { useGame, DAILY_REWARDS } from '@/lib/store';
import { PLAYERS, TOTAL_VERSIONS } from '@/lib/players';
import { PACKS } from '@/lib/packs';
import { ACHIEVEMENTS } from '@/lib/achievements';
import { SectionHeader } from '@/components/ui-fl/shared';
import { Settings as SettingsIcon, Volume2, VolumeX, Sparkles, RotateCcw, AlertTriangle } from 'lucide-react';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

export function SettingsSection() {
  const settings = useGame((s) => s.settings);
  const updateSettings = useGame((s) => s.updateSettings);
  const resetGame = useGame((s) => s.resetGame);
  const state = useGame();
  const [confirmReset, setConfirmReset] = useState(false);
  const { toast } = useToast();

  return (
    <div>
      <SectionHeader
        title="Settings"
        subtitle="Customize your game experience and view your account stats."
        icon={<SettingsIcon size={28} />}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Preferences */}
        <div className="fl-glass rounded-2xl p-5">
          <h3 className="font-black uppercase tracking-wide text-fl-neon mb-4">Preferences</h3>
          <div className="space-y-3">
            <SettingRow
              icon={settings.sound ? <Volume2 size={18} /> : <VolumeX size={18} />}
              label="Sound Effects"
              description="Audio feedback for pack openings and goals"
            >
              <button
                onClick={() => updateSettings({ sound: !settings.sound })}
                className={cn(
                  'relative w-12 h-6 rounded-full transition-colors',
                  settings.sound ? 'bg-fl-neon' : 'bg-black/50'
                )}
              >
                <motion.div
                  className="absolute top-0.5 w-5 h-5 rounded-full bg-white shadow"
                  animate={{ left: settings.sound ? '26px' : '2px' }}
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                />
              </button>
            </SettingRow>

            <SettingRow
              icon={<Sparkles size={18} />}
              label="Card Animations"
              description="Premium card shimmer and glow effects"
            >
              <button
                onClick={() => updateSettings({ animations: !settings.animations })}
                className={cn(
                  'relative w-12 h-6 rounded-full transition-colors',
                  settings.animations ? 'bg-fl-neon' : 'bg-black/50'
                )}
              >
                <motion.div
                  className="absolute top-0.5 w-5 h-5 rounded-full bg-white shadow"
                  animate={{ left: settings.animations ? '26px' : '2px' }}
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                />
              </button>
            </SettingRow>

            <SettingRow
              icon={<AlertTriangle size={18} />}
              label="Reduce Motion"
              description="Minimize animations for better performance"
            >
              <button
                onClick={() => updateSettings({ reduceMotion: !settings.reduceMotion })}
                className={cn(
                  'relative w-12 h-6 rounded-full transition-colors',
                  settings.reduceMotion ? 'bg-fl-neon' : 'bg-black/50'
                )}
              >
                <motion.div
                  className="absolute top-0.5 w-5 h-5 rounded-full bg-white shadow"
                  animate={{ left: settings.reduceMotion ? '26px' : '2px' }}
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                />
              </button>
            </SettingRow>
          </div>
        </div>

        {/* Stats summary */}
        <div className="fl-glass rounded-2xl p-5">
          <h3 className="font-black uppercase tracking-wide text-fl-gold mb-4">Your Stats</h3>
          <div className="grid grid-cols-2 gap-3">
            <StatBlock label="Manager Level" value={state.level} accent="neon" />
            <StatBlock label="Total XP" value={state.xp.toLocaleString()} accent="neon" />
            <StatBlock label="Coins" value={state.coins.toLocaleString()} accent="gold" />
            <StatBlock label="Packs Opened" value={state.packsOpened} accent="gold" />
            <StatBlock label="Unique Cards" value={state.collection.length} accent="blue" />
            <StatBlock label="Total Cards" value={state.collection.reduce((s, c) => s + c.count, 0)} accent="blue" />
            <StatBlock label="Matches Played" value={state.matchesPlayed} accent="gold" />
            <StatBlock label="Matches Won" value={state.matchesWon} accent="neon" />
            <StatBlock label="Win Rate" value={state.matchesPlayed > 0 ? `${Math.round((state.matchesWon / state.matchesPlayed) * 100)}%` : '—'} accent="neon" />
            <StatBlock label="Login Streak" value={`${state.loginStreak}/7`} accent="gold" />
            <StatBlock label="Achievements" value={`${state.achievementsClaimed.length}/${ACHIEVEMENTS.length}`} accent="gold" />
            <StatBlock label="Unique Players" value={`${state.uniquePlayersCollected.length}/${PLAYERS.length}`} accent="blue" />
          </div>
        </div>
      </div>

      {/* Database info */}
      <div className="fl-glass rounded-2xl p-5 mt-4">
        <h3 className="font-black uppercase tracking-wide text-fl-neon mb-3">Game Database</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
          <InfoTile label="Players" value={PLAYERS.length} />
          <InfoTile label="Card Versions" value={TOTAL_VERSIONS} />
          <InfoTile label="Packs" value={PACKS.length} />
          <InfoTile label="Achievements" value={ACHIEVEMENTS.length} />
        </div>
      </div>

      {/* Danger zone */}
      <div className="fl-glass rounded-2xl p-5 mt-4 border-2 border-red-500/30">
        <h3 className="font-black uppercase tracking-wide text-red-400 mb-3 flex items-center gap-2">
          <AlertTriangle size={16} /> Danger Zone
        </h3>
        <p className="text-sm text-muted-foreground mb-4">
          Reset your entire game progress. All coins, cards, squad, and achievements will be lost permanently.
        </p>
        {!confirmReset ? (
          <button
            onClick={() => setConfirmReset(true)}
            className="px-4 py-2 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-400 font-bold text-sm transition-colors flex items-center gap-2"
          >
            <RotateCcw size={14} /> Reset Game
          </button>
        ) : (
          <div className="flex flex-col sm:flex-row gap-2">
            <button
              onClick={() => {
                resetGame();
                setConfirmReset(false);
                toast({ title: 'Game reset', description: 'Your progress has been wiped. Welcome back to the start!' });
              }}
              className="px-4 py-2 rounded-lg bg-red-500 hover:bg-red-600 text-white font-black text-sm transition-colors"
            >
              ✓ Yes, Reset Everything
            </button>
            <button
              onClick={() => setConfirmReset(false)}
              className="px-4 py-2 rounded-lg bg-black/40 hover:bg-black/60 text-sm font-bold transition-colors"
            >
              Cancel
            </button>
          </div>
        )}
      </div>

      {/* About */}
      <div className="fl-glass rounded-2xl p-5 mt-4 text-center">
        <div className="text-2xl font-black mb-1 fl-text-shadow-neon">
          FOOTBALL <span className="fl-text-gold">LEGENDS</span>
        </div>
        <div className="text-xs text-muted-foreground">Dream XI — Card Collector & Team Builder</div>
        <div className="text-[10px] text-muted-foreground mt-2">
          All player ratings are game ratings for entertainment purposes and do not reflect official ratings.
          Player names are used to celebrate football history. No real-money gambling involved.
        </div>
      </div>
    </div>
  );
}

function SettingRow({ icon, label, description, children }: {
  icon: React.ReactNode;
  label: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-3 p-3 rounded-lg bg-black/20">
      <div className="text-fl-neon">{icon}</div>
      <div className="flex-1">
        <div className="font-bold text-sm">{label}</div>
        <div className="text-xs text-muted-foreground">{description}</div>
      </div>
      {children}
    </div>
  );
}

function StatBlock({ label, value, accent }: { label: string; value: any; accent: 'neon' | 'gold' | 'blue' }) {
  const colorMap = { neon: 'text-fl-neon', gold: 'text-fl-gold', blue: 'text-blue-400' };
  return (
    <div className="bg-black/30 rounded-lg p-3 text-center">
      <div className={cn('text-xl font-black tabular-nums', colorMap[accent])}>{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
    </div>
  );
}

function InfoTile({ label, value }: { label: string; value: any }) {
  return (
    <div className="bg-black/30 rounded-lg p-3 text-center">
      <div className="text-xl font-black text-fl-neon tabular-nums">{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
    </div>
  );
}
