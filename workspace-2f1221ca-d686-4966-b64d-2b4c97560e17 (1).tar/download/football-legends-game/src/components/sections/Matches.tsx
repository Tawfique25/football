'use client';

import { useGame } from '@/lib/store';
import { AI_TEAMS_DEF, simulateMatch, AITeam, getAITeamRating } from '@/lib/match-sim';
import { getFormation, calculateTeamRating } from '@/lib/formations';
import { PLAYERS, getVersion } from '@/lib/players';
import { MatchResult, Player, PlayerVersion } from '@/lib/types';
import { SectionHeader } from '@/components/ui-fl/shared';
import { motion } from 'framer-motion';
import { useState, useMemo } from 'react';
import { Trophy, Play, ChevronRight, Goal, Coins, Zap, Shield, Swords } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

// Tier metadata for UI
const TIER_META: Record<AITeam['tier'], { label: string; icon: string; color: string }> = {
  amateur: { label: 'Amateur', icon: '🌱', color: '#94a3b8' },
  pro: { label: 'Professional', icon: '⚽', color: '#22d3ee' },
  elite: { label: 'Elite', icon: '⭐', color: '#a855f7' },
  legend: { label: 'Legend', icon: '👑', color: '#fbbf24' },
  ultimate: { label: 'Ultimate', icon: '🏆', color: '#fde68a' },
};

// Tier-based reward estimates (matches match-sim.ts)
const TIER_REWARDS: Record<AITeam['tier'], { win: number; draw: number; xp: number }> = {
  amateur: { win: 100, draw: 40, xp: 40 },
  pro: { win: 200, draw: 80, xp: 80 },
  elite: { win: 350, draw: 140, xp: 140 },
  legend: { win: 500, draw: 200, xp: 200 },
  ultimate: { win: 800, draw: 320, xp: 320 },
};

export function MatchesSection() {
  const formationId = useGame((s) => s.formationId);
  const customFormation = useGame((s) => s.customFormation);
  const resolveSquad = useGame((s) => s.resolveSquad);
  const recordMatch = useGame((s) => s.recordMatch);
  const [selectedOpponent, setSelectedOpponent] = useState<AITeam | null>(null);
  const [result, setResult] = useState<MatchResult | null>(null);
  const [simulating, setSimulating] = useState(false);
  const { toast } = useToast();

  const homeSquad = resolveSquad();
  const homeRating = calculateTeamRating(formationId, homeSquad, customFormation);

  // Lookup function for AI team squad resolution
  const lookup = useMemo(() => (pid: string, vid: string): { player: Player; version: PlayerVersion } | undefined => {
    const player = PLAYERS.find((p) => p.id === pid);
    const version = getVersion(pid, vid);
    if (!player || !version) return undefined;
    return { player, version };
  }, []);

  // Pre-calculate actual ratings for all AI teams
  const aiRatings = useMemo(() => {
    const map: Record<string, number> = {};
    for (const team of AI_TEAMS_DEF) {
      map[team.id] = getAITeamRating(team, lookup);
    }
    return map;
  }, [lookup]);

  const handlePlay = () => {
    if (!selectedOpponent) return;
    if (homeRating.filled < 7) {
      toast({
        title: 'Squad too small',
        description: 'Place at least 7 players in your Dream Team before playing a match.',
        variant: 'destructive',
      });
      return;
    }
    setSimulating(true);
    setResult(null);

    setTimeout(() => {
      const res = simulateMatch({
        homeSquad,
        homeFormationId: formationId,
        homeCustomFormation: customFormation,
        awayTeam: selectedOpponent,
        lookup,
      });
      setResult(res);
      setSimulating(false);
      recordMatch(res.won, res.draw, res.rewards.coins, res.rewards.xp);
      if (res.rewards.coins > 0) {
        toast({
          title: res.won ? '🏆 Victory!' : res.draw ? '🤝 Draw' : 'Defeat',
          description: `+${res.rewards.coins} coins, +${res.rewards.xp} XP`,
        });
      }
    }, 2400);
  };

  return (
    <div>
      <SectionHeader
        title="Matches"
        subtitle="Test your Dream XI against AI-controlled teams. Five tiers of difficulty — bigger rewards for tougher opponents."
        icon={<Trophy size={28} />}
      />

      {/* Squad readiness */}
      <div className="fl-glass rounded-2xl p-4 mb-6 grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatBox label="Your OVR" value={homeRating.filled > 0 ? homeRating.overall : '—'} accent="neon" />
        <StatBox label="Players" value={`${homeRating.filled}/11`} accent={homeRating.filled >= 7 ? 'neon' : 'gold'} />
        <StatBox label="Chemistry" value={`${homeRating.chemistry}%`} accent="blue" />
        <StatBox label="Attack" value={homeRating.attack || '—'} accent="gold" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Opponent selection */}
        <div className="fl-glass rounded-2xl p-5">
          <h3 className="font-black uppercase tracking-wide text-fl-gold mb-4">Choose Your Opponent</h3>
          <div className="space-y-3">
            {AI_TEAMS_DEF.map((team) => {
              const isSelected = selectedOpponent?.id === team.id;
              const actualRating = aiRatings[team.id] ?? team.rating;
              const tier = TIER_META[team.tier];
              // Win probability — use actual rating gap
              const gap = homeRating.overall - actualRating;
              const chemAdj = (homeRating.chemistry - 50) / 200;
              const winChance = homeRating.filled > 0
                ? Math.max(5, Math.min(95, Math.round(50 + gap * 3 + chemAdj * 100)))
                : 0;
              return (
                <motion.button
                  key={team.id}
                  whileHover={{ scale: 1.01 }}
                  onClick={() => setSelectedOpponent(team)}
                  className={cn(
                    'w-full text-left rounded-xl p-4 transition-all border-2 flex items-center gap-4',
                    isSelected ? 'bg-white/5' : 'bg-black/30 hover:bg-black/50'
                  )}
                  style={isSelected ? { borderColor: team.accent, boxShadow: `0 0 20px ${team.accent}40` } : { borderColor: 'transparent' }}
                >
                  <div
                    className="w-14 h-14 rounded-lg flex flex-col items-center justify-center font-black flex-shrink-0 relative overflow-hidden"
                    style={{ background: team.gradient, color: '#fff', border: `2px solid ${team.accent}` }}
                  >
                    <div className="text-lg leading-none">{actualRating}</div>
                    <div className="text-[8px] opacity-80 mt-0.5">OVR</div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="font-black truncate">{team.name}</span>
                      <span
                        className="text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider whitespace-nowrap"
                        style={{ background: `${tier.color}22`, color: tier.color, border: `1px solid ${tier.color}66` }}
                      >
                        {tier.icon} {tier.label}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground">{team.formationId} formation • {team.squad.length} players</div>
                    {homeRating.filled > 0 && (
                      <div className="mt-1.5">
                        <div className="flex items-center justify-between text-[10px] mb-0.5">
                          <span className="uppercase tracking-wider text-muted-foreground">Win Probability</span>
                          <span className="font-black tabular-nums" style={{ color: winChance >= 60 ? '#b3ff3a' : winChance >= 35 ? '#fbbf24' : '#fb7185' }}>
                            {winChance}%
                          </span>
                        </div>
                        <div className="h-1.5 bg-black/40 rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all"
                            style={{
                              width: `${winChance}%`,
                              background: winChance >= 60 ? '#b3ff3a' : winChance >= 35 ? '#fbbf24' : '#fb7185',
                            }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                  <ChevronRight size={16} className="text-muted-foreground flex-shrink-0" />
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Match panel */}
        <div className="fl-glass rounded-2xl p-5 flex flex-col">
          <h3 className="font-black uppercase tracking-wide text-fl-neon mb-4">Match Center</h3>
          {!selectedOpponent ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center py-12">
              <div className="text-6xl mb-3">⚔️</div>
              <p className="text-sm text-muted-foreground max-w-xs mb-4">
                Select an opponent to start a match. Five tiers of difficulty await — from Sunday League amateurs to all-time legends.
              </p>
              <div className="grid grid-cols-5 gap-2 w-full max-w-md text-center">
                {AI_TEAMS_DEF.map((t) => {
                  const tier = TIER_META[t.tier];
                  return (
                    <div key={t.id} className="bg-black/30 rounded-lg p-2">
                      <div className="text-xl">{tier.icon}</div>
                      <div className="text-[9px] uppercase tracking-wider mt-0.5" style={{ color: tier.color }}>{tier.label}</div>
                      <div className="text-xs font-black mt-0.5">{aiRatings[t.id] ?? t.rating}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : simulating ? (
            <MatchSimulating
              homeRating={homeRating.overall}
              awayRating={aiRatings[selectedOpponent.id] ?? selectedOpponent.rating}
              awayName={selectedOpponent.name}
            />
          ) : result ? (
            <MatchResultView result={result} awayTeam={selectedOpponent} awayRating={aiRatings[selectedOpponent.id] ?? selectedOpponent.rating} onDismiss={() => setResult(null)} />
          ) : (
            <MatchPreview
              homeName="Your Dream XI"
              homeRating={homeRating.overall}
              homeFilled={homeRating.filled}
              away={selectedOpponent}
              awayRating={aiRatings[selectedOpponent.id] ?? selectedOpponent.rating}
              onPlay={handlePlay}
              onClear={() => setSelectedOpponent(null)}
            />
          )}
        </div>
      </div>
    </div>
  );
}

function StatBox({ label, value, accent }: { label: string; value: any; accent: 'neon' | 'gold' | 'blue' }) {
  const colorMap = { neon: 'text-fl-neon', gold: 'text-fl-gold', blue: 'text-blue-400' };
  return (
    <div className="text-center">
      <div className={cn('text-2xl font-black tabular-nums', colorMap[accent])}>{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
    </div>
  );
}

function MatchPreview({ homeName, homeRating, homeFilled, away, awayRating, onPlay, onClear }: {
  homeName: string;
  homeRating: number;
  homeFilled: number;
  away: AITeam;
  awayRating: number;
  onPlay: () => void;
  onClear: () => void;
}) {
  const canPlay = homeFilled >= 7;
  const tier = TIER_META[away.tier];
  const rewards = TIER_REWARDS[away.tier];
  const gap = homeRating - awayRating;
  const advantage = gap > 5 ? 'You are stronger' : gap < -5 ? 'Opponent is stronger' : 'Even match';

  return (
    <div className="flex-1 flex flex-col">
      <div className="flex-1 flex flex-col items-center justify-center py-6">
        {/* Tier badge */}
        <div
          className="px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider mb-4"
          style={{ background: `${tier.color}22`, color: tier.color, border: `1px solid ${tier.color}` }}
        >
          {tier.icon} {tier.label} Tier
        </div>

        <div className="flex items-center justify-center gap-6 w-full">
          <div className="text-center flex-1">
            <div className="text-xs uppercase tracking-wider text-fl-neon mb-2 flex items-center justify-center gap-1">
              <Shield size={12} /> Home
            </div>
            <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-fl-neon-dim to-fl-neon flex items-center justify-center font-black text-3xl text-fl-navy fl-glow-neon">
              {homeRating || '—'}
            </div>
            <div className="text-xs mt-2 font-bold truncate">{homeName}</div>
          </div>
          <div className="text-3xl font-black text-muted-foreground">VS</div>
          <div className="text-center flex-1">
            <div className="text-xs uppercase tracking-wider mb-2 flex items-center justify-center gap-1" style={{ color: tier.color }}>
              <Swords size={12} /> Away
            </div>
            <div
              className="w-20 h-20 mx-auto rounded-full flex items-center justify-center font-black text-3xl text-white"
              style={{ background: away.gradient, border: `2px solid ${away.accent}`, boxShadow: `0 0 20px ${away.accent}40` }}
            >
              {awayRating}
            </div>
            <div className="text-xs mt-2 font-bold truncate">{away.name}</div>
          </div>
        </div>

        {/* Difficulty indicator */}
        <div className="mt-4 text-center">
          <div className="text-xs text-muted-foreground mb-1">Difficulty</div>
          <div
            className="text-sm font-black"
            style={{ color: gap > 5 ? '#b3ff3a' : gap < -5 ? '#fb7185' : '#fbbf24' }}
          >
            {advantage} ({gap > 0 ? '+' : ''}{gap} OVR)
          </div>
        </div>

        {/* Rewards preview */}
        <div className="mt-6 text-center">
          <div className="text-xs text-muted-foreground mb-2">Potential Rewards</div>
          <div className="flex items-center justify-center gap-3 text-sm">
            <div className="fl-glass rounded-lg px-3 py-1.5">
              <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Win</div>
              <div className="font-black text-fl-gold flex items-center gap-1">
                <Coins size={12} className="fill-fl-gold" /> {rewards.win}
              </div>
            </div>
            <div className="fl-glass rounded-lg px-3 py-1.5">
              <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Draw</div>
              <div className="font-black text-fl-gold flex items-center gap-1">
                <Coins size={12} className="fill-fl-gold" /> {rewards.draw}
              </div>
            </div>
            <div className="fl-glass rounded-lg px-3 py-1.5">
              <div className="text-[9px] uppercase tracking-wider text-muted-foreground">XP (Win)</div>
              <div className="font-black text-fl-neon flex items-center gap-1">
                <Zap size={12} /> {rewards.xp}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="flex gap-2">
        <button
          onClick={onClear}
          className="px-4 py-2.5 rounded-lg bg-black/40 hover:bg-black/60 text-sm font-bold transition-colors"
        >
          Change
        </button>
        <button
          onClick={onPlay}
          disabled={!canPlay}
          className={cn(
            'flex-1 py-2.5 rounded-lg font-black text-sm transition-all flex items-center justify-center gap-2',
            canPlay
              ? 'bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy hover:scale-[1.02] fl-glow-neon'
              : 'bg-black/40 text-muted-foreground cursor-not-allowed'
          )}
        >
          <Play size={14} fill="currentColor" /> {canPlay ? 'KICK OFF' : 'NEED 7+ PLAYERS'}
        </button>
      </div>
    </div>
  );
}

function MatchSimulating({ homeRating, awayRating, awayName }: { homeRating: number; awayRating: number; awayName: string }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center py-12">
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
        className="text-7xl mb-6"
      >
        ⚽
      </motion.div>
      <div className="text-lg font-black mb-1 fl-text-neon">Match in Progress...</div>
      <div className="text-sm text-muted-foreground">Your XI ({homeRating}) vs {awayName} ({awayRating})</div>
      <div className="mt-6 flex items-center gap-1.5">
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            className="w-2 h-2 rounded-full bg-fl-neon"
            animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.2 }}
          />
        ))}
      </div>
    </div>
  );
}

function MatchResultView({ result, awayTeam, awayRating, onDismiss }: {
  result: MatchResult;
  awayTeam: AITeam;
  awayRating: number;
  onDismiss: () => void;
}) {
  const won = result.won;
  const draw = result.draw;
  const headline = won ? '🏆 VICTORY!' : draw ? '🤝 DRAW' : '❌ DEFEAT';
  const headlineColor = won ? 'text-fl-neon' : draw ? 'text-fl-gold' : 'text-red-400';

  return (
    <div className="flex-1 flex flex-col">
      {/* Scoreboard */}
      <div className="text-center mb-4">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className={cn('text-3xl font-black mb-2', headlineColor)}
        >
          {headline}
        </motion.div>
        <div className="fl-glass rounded-xl p-4 inline-block">
          <div className="flex items-center gap-6">
            <div className="text-center">
              <div className="text-xs text-fl-neon uppercase tracking-wider">You ({result.homeRating})</div>
              <div className="text-5xl font-black tabular-nums">{result.homeScore}</div>
            </div>
            <div className="text-2xl text-muted-foreground">—</div>
            <div className="text-center">
              <div className="text-xs text-fl-gold uppercase tracking-wider">{awayTeam.name} ({awayRating})</div>
              <div className="text-5xl font-black tabular-nums">{result.awayScore}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2 mb-4 text-xs">
        <StatCompare label="Possession" home={result.homeStats.possession} away={result.awayStats.possession} suffix="%" />
        <StatCompare label="Shots" home={result.homeStats.shots} away={result.awayStats.shots} />
        <StatCompare label="On Target" home={result.homeStats.onTarget} away={result.awayStats.onTarget} />
      </div>

      {/* Event timeline */}
      <div className="fl-glass rounded-xl p-3 mb-4 max-h-48 overflow-y-auto fl-scroll">
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Match Events</div>
        <div className="space-y-1.5">
          {result.events.map((e, i) => (
            <motion.div
              key={i}
              initial={{ x: -10, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: i * 0.05 }}
              className={cn(
                'flex items-start gap-2 text-xs p-1.5 rounded',
                e.type === 'goal' && 'bg-fl-neon/10',
                e.type === 'info' && 'opacity-70'
              )}
            >
              <div className="font-black tabular-nums w-8 flex-shrink-0 text-muted-foreground">{e.minute}'</div>
              <div className="flex-1">
                {e.type === 'goal' && <Goal size={10} className="inline mr-1 text-fl-neon" />}
                {e.text}
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Rewards */}
      <div className="fl-glass rounded-xl p-3 mb-3 flex items-center justify-around">
        <div className="text-center">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Coins Earned</div>
          <div className="text-2xl font-black text-fl-gold flex items-center gap-1 justify-center">
            <Coins size={16} className="fill-fl-gold" />
            +{result.rewards.coins}
          </div>
        </div>
        <div className="text-center">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">XP Earned</div>
          <div className="text-2xl font-black text-fl-neon flex items-center gap-1 justify-center">
            <Zap size={16} />
            +{result.rewards.xp}
          </div>
        </div>
      </div>

      <button
        onClick={onDismiss}
        className="w-full py-2.5 rounded-lg bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy font-black text-sm hover:scale-[1.02] transition-transform"
      >
        Continue
      </button>
    </div>
  );
}

function StatCompare({ label, home, away, suffix }: { label: string; home: number; away: number; suffix?: string }) {
  const total = home + away;
  const homePct = total > 0 ? (home / total) * 100 : 50;
  return (
    <div>
      <div className="text-[9px] uppercase tracking-wider text-muted-foreground mb-1">{label}</div>
      <div className="flex items-center gap-1 text-[11px] font-bold tabular-nums">
        <span className="w-7 text-right text-fl-neon">{home}{suffix}</span>
        <div className="flex-1 h-1.5 bg-black/40 rounded-full overflow-hidden flex">
          <div className="h-full bg-fl-neon" style={{ width: `${homePct}%` }} />
          <div className="h-full bg-fl-gold" style={{ width: `${100 - homePct}%` }} />
        </div>
        <span className="w-7 text-fl-gold">{away}{suffix}</span>
      </div>
    </div>
  );
}
