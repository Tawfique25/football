'use client';

import { useGame } from '@/lib/store';
import { FORMATIONS, getFormation, calculateTeamRating, calculateChemistry, effectiveRating, positionCompatibility } from '@/lib/formations';
import { PLAYERS, RARITY_META, flagEmoji } from '@/lib/players';
import { Player, PlayerVersion, Position } from '@/lib/types';
import { PlayerCard, PlayerCardMini } from '@/components/cards/PlayerCard';
import { SectionHeader } from '@/components/ui-fl/shared';
import { motion, AnimatePresence } from 'framer-motion';
import { useState, useMemo } from 'react';
import { Users, X, Wand2, RotateCcw, ChevronDown, ChevronUp, Check, Flame, Plus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { FormationBuilderModal, BuilderSlot } from './FormationBuilderModal';

export function DreamTeamSection() {
  const formationId = useGame((s) => s.formationId);
  const customFormation = useGame((s) => s.customFormation);
  const squad = useGame((s) => s.squad);
  const collection = useGame((s) => s.collection);
  const lookupCard = useGame((s) => s.lookupCard);
  const setFormation = useGame((s) => s.setFormation);
  const setCustomFormation = useGame((s) => s.setCustomFormation);
  const placePlayerInSlot = useGame((s) => s.placePlayerInSlot);
  const removePlayerFromSlot = useGame((s) => s.removePlayerFromSlot);
  const autoFillSquad = useGame((s) => s.autoFillSquad);
  const clearSquad = useGame((s) => s.clearSquad);
  const { toast } = useToast();

  const [selectedSlot, setSelectedSlot] = useState<number | null>(null);
  const [showBench, setShowBench] = useState(true);
  const [positionFilter, setPositionFilter] = useState<'all' | 'compatible'>('compatible');
  const [builderOpen, setBuilderOpen] = useState(false);

  const formation = getFormation(formationId, customFormation);
  const resolvedSquad = squad.map((cardId) => (cardId ? lookupCard(cardId) ?? null : null));
  const teamRating = calculateTeamRating(formationId, resolvedSquad, customFormation);
  const chemistry = calculateChemistry(formationId, resolvedSquad, customFormation);

  // Cards available to be placed in the selected slot (not already on pitch)
  const availableCards = useMemo(() => {
    if (selectedSlot === null) return [];
    const slotPos = formation.slots[selectedSlot].position as Position;
    const onPitch = new Set(squad.filter((_, i) => i !== selectedSlot));
    return collection
      .filter((c) => !onPitch.has(c.id))
      .map((c) => {
        const entry = lookupCard(c.id);
        if (!entry) return null;
        const compat = positionCompatibility(slotPos, entry.player.position, entry.player.altPositions as Position[]);
        return { card: c, entry, compat };
      })
      .filter((x): x is NonNullable<typeof x> => x !== null)
      .filter((x) => positionFilter === 'all' ? true : x.compat > 0.3)
      .sort((a, b) => {
        if (positionFilter === 'compatible') {
          if (b.compat !== a.compat) return b.compat - a.compat;
        }
        return b.entry.version.ovr - a.entry.version.ovr;
      });
  }, [selectedSlot, formation, squad, collection, lookupCard, positionFilter]);

  const handleAutoFill = () => {
    autoFillSquad();
    toast({ title: 'Squad auto-filled', description: 'Best players placed by position compatibility.' });
  };

  const handleClear = () => {
    clearSquad();
    toast({ title: 'Squad cleared' });
  };

  const handleSaveCustom = (slots: BuilderSlot[]) => {
    setCustomFormation({ slots });
    setBuilderOpen(false);
    toast({
      title: 'Custom formation saved',
      description: `${slots.length} players placed. Switched to your custom formation.`,
    });
  };

  const handleCancelBuilder = () => setBuilderOpen(false);

  return (
    <div>
      <SectionHeader
        title="Dream Team"
        subtitle="Build your ultimate XI. Choose a formation, place players, and watch chemistry come alive."
        icon={<Users size={28} />}
      />

      {/* Formation selector + actions */}
      <div className="fl-glass rounded-2xl p-4 mb-4 flex flex-col md:flex-row md:items-center gap-3 flex-wrap">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs uppercase tracking-wider text-muted-foreground">Formation:</span>
          {FORMATIONS.map((f) => (
            <button
              key={f.id}
              onClick={() => setFormation(f.id)}
              className={cn(
                'px-3 py-1.5 rounded-lg text-sm font-bold transition-all',
                formationId === f.id
                  ? 'bg-fl-neon text-fl-navy fl-glow-neon'
                  : 'bg-black/30 hover:bg-white/10'
              )}
            >
              {f.name}
            </button>
          ))}
          {/* Custom formation button — either opens builder (no custom saved) or switches to it */}
          {customFormation && customFormation.slots.length > 0 ? (
            <>
              <button
                onClick={() => setFormation('custom')}
                className={cn(
                  'px-3 py-1.5 rounded-lg text-sm font-bold transition-all border border-fl-gold/40',
                  formationId === 'custom'
                    ? 'bg-fl-gold text-fl-navy fl-glow-gold'
                    : 'bg-fl-gold/10 text-fl-gold hover:bg-fl-gold/20'
                )}
                title="Switch to your custom formation"
              >
                Custom
              </button>
              <button
                onClick={() => setBuilderOpen(true)}
                className="px-2 py-1.5 rounded-lg text-xs font-bold bg-black/30 hover:bg-fl-gold/20 text-fl-gold transition-colors flex items-center gap-1"
                title="Edit your custom formation"
              >
                <RotateCcw size={12} /> Edit
              </button>
            </>
          ) : null}
          <button
            onClick={() => setBuilderOpen(true)}
            className={cn(
              'px-3 py-1.5 rounded-lg text-sm font-bold transition-all flex items-center gap-1.5 border border-dashed',
              formationId === 'custom' && customFormation
                ? 'bg-fl-gold text-fl-navy border-fl-gold fl-glow-gold'
                : 'border-fl-gold/50 text-fl-gold hover:bg-fl-gold/15'
            )}
            title={customFormation && customFormation.slots.length > 0 ? 'Edit custom formation' : 'Create your own formation'}
          >
            <Plus size={14} />
            {customFormation && customFormation.slots.length > 0 ? 'Edit Custom' : 'Create Formation'}
          </button>
        </div>
        <div className="flex-1" />
        <div className="flex items-center gap-2">
          <button
            onClick={handleAutoFill}
            className="px-4 py-2 rounded-lg bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy font-black text-sm hover:scale-105 transition-transform flex items-center gap-2"
          >
            <Wand2 size={14} /> Auto Fill
          </button>
          <button
            onClick={handleClear}
            className="px-3 py-2 rounded-lg bg-black/40 hover:bg-red-500/20 text-sm font-bold transition-colors flex items-center gap-2"
          >
            <RotateCcw size={14} /> Clear
          </button>
        </div>
      </div>

      {/* Team ratings */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
        <RatingTile label="Team OVR" value={teamRating.filled > 0 ? teamRating.overall : '—'} accent="neon" big />
        <RatingTile label="Attack" value={teamRating.attack || '—'} accent="gold" />
        <RatingTile label="Midfield" value={teamRating.midfield || '—'} accent="blue" />
        <RatingTile label="Defense" value={teamRating.defense || '—'} accent="gold" />
        <RatingTile label="Chemistry" value={`${teamRating.chemistry}%`} accent="neon" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Pitch */}
        <div className="lg:col-span-2 fl-glass rounded-2xl p-3">
          <div className="relative fl-pitch rounded-xl overflow-hidden" style={{ aspectRatio: '0.7', minHeight: 500 }}>
            {/* Pitch markings */}
            <PitchMarkings />

            {/* Chemistry links */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 1 }}>
              {chemistry.links.map((link, i) => {
                const slotA = formation.slots[link.from];
                const slotB = formation.slots[link.to];
                const topA = 100 - slotA.y;
                const topB = 100 - slotB.y;
                const opacity = Math.min(0.9, 0.3 + link.strength * 0.25);
                const width = 1 + link.strength * 1.2;
                const color = link.strength >= 2 ? '#b3ff3a' : link.strength >= 1 ? '#fbbf24' : '#60a5fa';
                return (
                  <line
                    key={i}
                    x1={`${slotA.x}%`} y1={`${topA}%`}
                    x2={`${slotB.x}%`} y2={`${topB}%`}
                    stroke={color}
                    strokeWidth={width}
                    strokeOpacity={opacity}
                    strokeDasharray="4 4"
                  />
                );
              })}
            </svg>

            {/* Slots */}
            {formation.slots.map((slot, i) => {
              const entry = resolvedSquad[i];
              const top = 100 - slot.y;
              const isSelected = selectedSlot === i;
              const chemScore = chemistry.perSlot[i] ?? 0;
              return (
                <div
                  key={i}
                  className="absolute -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${slot.x}%`, top: `${top}%`, zIndex: isSelected ? 10 : 2 }}
                >
                  {entry ? (
                    <FilledSlot
                      player={entry.player}
                      version={entry.version}
                      slotPos={slot.position as Position}
                      chemScore={chemScore}
                      isSelected={isSelected}
                      onClick={() => setSelectedSlot(isSelected ? null : i)}
                      onRemove={() => {
                        removePlayerFromSlot(i);
                        setSelectedSlot(null);
                      }}
                    />
                  ) : (
                    <EmptySlot
                      position={slot.position}
                      isSelected={isSelected}
                      onClick={() => setSelectedSlot(isSelected ? null : i)}
                    />
                  )}
                </div>
              );
            })}
          </div>
          <div className="mt-3 flex items-center justify-between flex-wrap gap-2 text-xs">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-fl-neon inline-block" /> Strong link</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-fl-gold inline-block" /> Medium link</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-400 inline-block" /> Weak link</span>
            </div>
            <div className="text-muted-foreground">
              {teamRating.filled}/11 players placed
            </div>
          </div>
        </div>

        {/* Side panel: player picker */}
        <div className="fl-glass rounded-2xl p-4 flex flex-col" style={{ maxHeight: 700 }}>
          {selectedSlot !== null ? (
            <PlayerPicker
              slotPos={formation.slots[selectedSlot].position as Position}
              available={availableCards}
              positionFilter={positionFilter}
              onFilterChange={setPositionFilter}
              onPlace={(cardId) => {
                placePlayerInSlot(selectedSlot, cardId);
                setSelectedSlot(null);
                toast({ title: 'Player placed', description: 'Added to your starting XI.' });
              }}
              onClose={() => setSelectedSlot(null)}
            />
          ) : (
            <div className="text-center py-8 flex-1 flex flex-col items-center justify-center">
              <div className="text-5xl mb-3">👆</div>
              <p className="text-sm text-muted-foreground mb-4 max-w-xs">
                Tap any position on the pitch to add a player. Try Auto Fill to instantly place your best XI.
              </p>
              <div className="text-xs text-muted-foreground space-y-1">
                <p>• Same-club & same-nation players get chemistry bonuses</p>
                <p>• Out-of-position players receive a rating penalty</p>
                <p>• Higher chemistry = better match performance</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Formation builder modal */}
      <FormationBuilderModal
        open={builderOpen}
        initialSlots={
          customFormation && customFormation.slots.length > 0
            ? customFormation.slots.map((s) => ({ position: s.position, x: s.x, y: s.y }))
            : []
        }
        onSave={handleSaveCustom}
        onCancel={handleCancelBuilder}
      />
    </div>
  );
}

function PitchMarkings() {
  return (
    <div className="absolute inset-0 pointer-events-none">
      {/* Outer boundary */}
      <div className="absolute inset-2 border-2 border-white/30 rounded-md" />
      {/* Center line */}
      <div className="absolute left-2 right-2 top-1/2 h-0.5 bg-white/30" />
      {/* Center circle */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 border-2 border-white/30 rounded-full" />
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-white/40 rounded-full" />
      {/* Top penalty box */}
      <div className="absolute left-1/2 -translate-x-1/2 top-2 w-40 h-12 border-2 border-white/30 border-t-0" />
      <div className="absolute left-1/2 -translate-x-1/2 top-2 w-20 h-6 border-2 border-white/30 border-t-0" />
      <div className="absolute left-1/2 -translate-x-1/2 top-12 w-1 h-1 bg-white/40 rounded-full" />
      {/* Bottom penalty box */}
      <div className="absolute left-1/2 -translate-x-1/2 bottom-2 w-40 h-12 border-2 border-white/30 border-b-0" />
      <div className="absolute left-1/2 -translate-x-1/2 bottom-2 w-20 h-6 border-2 border-white/30 border-b-0" />
      <div className="absolute left-1/2 -translate-x-1/2 bottom-12 w-1 h-1 bg-white/40 rounded-full" />
    </div>
  );
}

function EmptySlot({ position, isSelected, onClick }: {
  position: string;
  isSelected: boolean;
  onClick: () => void;
}) {
  return (
    <motion.button
      whileHover={{ scale: 1.08 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={cn(
        'w-12 h-12 md:w-14 md:h-14 rounded-full border-2 border-dashed flex flex-col items-center justify-center transition-colors',
        isSelected ? 'border-fl-neon bg-fl-neon/20 fl-glow-neon' : 'border-white/40 bg-black/40 hover:bg-black/60 hover:border-fl-neon/60'
      )}
    >
      <span className="text-[10px] font-black">{position}</span>
      <span className="text-[10px] opacity-60">+</span>
    </motion.button>
  );
}

function FilledSlot({ player, version, slotPos, chemScore, isSelected, onClick, onRemove }: {
  player: Player;
  version: PlayerVersion;
  slotPos: Position;
  chemScore: number;
  isSelected: boolean;
  onClick: () => void;
  onRemove: () => void;
}) {
  const meta = RARITY_META[version.rarity];
  const compat = positionCompatibility(slotPos, player.position, player.altPositions as Position[]);
  const effOvr = effectiveRating(version, slotPos, player);
  const compatColor = compat >= 0.85 ? '#b3ff3a' : compat >= 0.7 ? '#fbbf24' : '#fb7185';
  const chemColor = chemScore >= 70 ? '#b3ff3a' : chemScore >= 40 ? '#fbbf24' : '#fb7185';

  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      onClick={onClick}
      className="relative cursor-pointer"
    >
      {/* Card */}
      <div
        className="w-14 h-18 md:w-16 md:h-20 rounded-lg flex flex-col items-center justify-center p-1 relative overflow-hidden"
        style={{
          background: meta.gradient,
          border: `2px solid ${meta.border}`,
          boxShadow: `0 0 12px ${meta.glow}`,
        }}
      >
        {version.rarity !== 'common' && (
          <div className="absolute inset-0 fl-shimmer pointer-events-none opacity-50" />
        )}
        <div className="font-black text-base md:text-lg leading-none" style={{ color: meta.text }}>
          {effOvr}
        </div>
        <div className="text-[8px] font-bold mt-0.5" style={{ color: meta.text }}>{slotPos}</div>
        <div className="text-[8px] mt-0.5 leading-tight text-center px-0.5 truncate w-full" style={{ color: meta.text }}>
          {player.name.split(' ').slice(-1)[0]}
        </div>
      </div>

      {/* Chemistry indicator */}
      <div
        className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-black border border-black"
        style={{ background: chemColor, color: '#000' }}
      >
        {Math.round(chemScore / 33)}
      </div>

      {/* Compatibility indicator */}
      {compat < 0.85 && (
        <div
          className="absolute -top-1 -right-1 w-3 h-3 rounded-full border border-black"
          style={{ background: compatColor }}
          title={`Position compat: ${Math.round(compat * 100)}%`}
        />
      )}

      {/* Remove button on hover/selected */}
      {isSelected && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="absolute -top-2 -left-2 w-5 h-5 rounded-full bg-red-500 text-white flex items-center justify-center hover:scale-110 transition-transform"
        >
          <X size={12} />
        </button>
      )}
    </motion.div>
  );
}

function PlayerPicker({ slotPos, available, positionFilter, onFilterChange, onPlace, onClose }: {
  slotPos: Position;
  available: { card: any; entry: { player: Player; version: PlayerVersion }; compat: number }[];
  positionFilter: 'all' | 'compatible';
  onFilterChange: (f: 'all' | 'compatible') => void;
  onPlace: (cardId: string) => void;
  onClose: () => void;
}) {
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-3">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Selecting for</div>
          <div className="text-xl font-black text-fl-neon">{slotPos}</div>
        </div>
        <button onClick={onClose} className="p-2 rounded-lg bg-black/40 hover:bg-black/60 transition-colors">
          <X size={16} />
        </button>
      </div>

      <div className="flex gap-1 mb-3">
        <button
          onClick={() => onFilterChange('compatible')}
          className={cn(
            'flex-1 px-2 py-1.5 rounded text-xs font-bold transition-colors',
            positionFilter === 'compatible' ? 'bg-fl-neon text-fl-navy' : 'bg-black/30 hover:bg-white/10'
          )}
        >
          Compatible First
        </button>
        <button
          onClick={() => onFilterChange('all')}
          className={cn(
            'flex-1 px-2 py-1.5 rounded text-xs font-bold transition-colors',
            positionFilter === 'all' ? 'bg-fl-neon text-fl-navy' : 'bg-black/30 hover:bg-white/10'
          )}
        >
          All Cards
        </button>
      </div>

      <div className="flex-1 overflow-y-auto fl-scroll space-y-1.5 pr-1">
        {available.length === 0 ? (
          <div className="text-center py-8 text-sm text-muted-foreground">
            No available cards{positionFilter === 'compatible' ? ' compatible with this position' : ''}. Try a different position or open more packs.
          </div>
        ) : (
          available.map(({ card, entry, compat }) => (
            <PlayerPickerRow
              key={card.id}
              player={entry.player}
              version={entry.version}
              compat={compat}
              slotPos={slotPos}
              onClick={() => onPlace(card.id)}
            />
          ))
        )}
      </div>
    </div>
  );
}

function PlayerPickerRow({ player, version, compat, slotPos, onClick }: {
  player: Player;
  version: PlayerVersion;
  compat: number;
  slotPos: Position;
  onClick: () => void;
}) {
  const meta = RARITY_META[version.rarity];
  const effOvr = effectiveRating(version, slotPos, player);
  const compatColor = compat >= 0.85 ? '#b3ff3a' : compat >= 0.7 ? '#fbbf24' : '#fb7185';
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-2 p-2 rounded-lg bg-black/30 hover:bg-white/5 transition-colors text-left"
    >
      <div
        className="w-10 h-12 rounded-md flex flex-col items-center justify-center font-black flex-shrink-0"
        style={{ background: meta.gradient, border: `1px solid ${meta.border}`, color: meta.text }}
      >
        <div className="text-base leading-none">{effOvr}</div>
        <div className="text-[8px] mt-0.5">{slotPos}</div>
      </div>
      <div className="flex-1 min-w-0">
        <div className="font-bold text-sm truncate">{player.name}</div>
        <div className="text-[10px] text-muted-foreground truncate">
          {version.versionName} • {player.position} • {flagEmoji(player.countryCode)} {player.club}
        </div>
      </div>
      <div className="flex flex-col items-end">
        <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Fit</div>
        <div className="w-10 h-1.5 rounded-full bg-black/40 overflow-hidden">
          <div className="h-full" style={{ width: `${compat * 100}%`, background: compatColor }} />
        </div>
      </div>
    </button>
  );
}

function RatingTile({ label, value, accent, big }: {
  label: string;
  value: any;
  accent: 'neon' | 'gold' | 'blue';
  big?: boolean;
}) {
  const colorMap = {
    neon: 'border-fl-neon text-fl-neon',
    gold: 'border-fl-gold text-fl-gold',
    blue: 'border-blue-400 text-blue-400',
  };
  return (
    <div className={cn('fl-glass rounded-xl p-3 text-center border-l-4', colorMap[accent])}>
      <div className={cn('font-black tabular-nums', big ? 'text-3xl' : 'text-2xl')}>{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
    </div>
  );
}
