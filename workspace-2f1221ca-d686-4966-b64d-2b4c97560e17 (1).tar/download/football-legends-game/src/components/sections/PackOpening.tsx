'use client';

import { useGame } from '@/lib/store';
import { BOX_PACKS, BoxPack, getPackTierCounts, resolveBoxPlayer } from '@/lib/box-packs';
import { Player, PlayerVersion, CardTier } from '@/lib/types';
import { RARITY_META, flagEmoji, getPlayer, getVersion } from '@/lib/players';
import { PackReveal } from '@/components/cards/PackReveal';
import { PlayerCard } from '@/components/cards/PlayerCard';
import { SectionHeader } from '@/components/ui-fl/shared';
import { motion, AnimatePresence } from 'framer-motion';
import { useState, useMemo } from 'react';
import { Package, Coins, RotateCcw, Play, Check, X, Lock, Zap, Crown, Star, Sparkles, ChevronRight, RefreshCw, History } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export function PackOpeningSection() {
  const coins = useGame((s) => s.coins);
  const boxStates = useGame((s) => s.boxStates);
  const spinBox = useGame((s) => s.spinBox);
  const resetBox = useGame((s) => s.resetBox);
  const collection = useGame((s) => s.collection);
  const lookupCard = useGame((s) => s.lookupCard);
  const { toast } = useToast();

  const [selectedPack, setSelectedPack] = useState<BoxPack | null>(null);
  const [revealing, setRevealing] = useState<{ player: Player; version: PlayerVersion; tier: CardTier }[] | null>(null);
  const [confirmSpin, setConfirmSpin] = useState<{ pack: BoxPack; spins: 1 | 10 } | null>(null);
  const [showHistory, setShowHistory] = useState<string | null>(null);

  const handleSpin = (pack: BoxPack, spins: 1 | 10) => {
    const cost = spins === 1 ? 100 : 1000;
    if (coins < cost) {
      toast({
        title: 'Not enough coins',
        description: `You need ${cost - coins} more coins for ${spins} spin${spins > 1 ? 's' : ''}.`,
        variant: 'destructive',
      });
      return;
    }
    setConfirmSpin({ pack, spins });
  };

  const confirmAndSpin = () => {
    if (!confirmSpin) return;
    const { pack, spins } = confirmSpin;
    const result = spinBox(pack.id, spins);
    if (!result.success) {
      toast({ title: 'Cannot spin', description: result.error, variant: 'destructive' });
      setConfirmSpin(null);
      return;
    }
    setConfirmSpin(null);
    setRevealing(result.cards);
  };

  const handleResetBox = (packId: string) => {
    resetBox(packId);
    toast({ title: 'Box reset', description: 'All 150 players restored.' });
  };

  // Get obtained cards for a pack (for history view)
  const getObtainedCards = (packId: string) => {
    const boxState = boxStates[packId];
    if (!boxState) return [];
    const pack = BOX_PACKS.find((p) => p.id === packId);
    if (!pack) return [];
    return boxState.obtained.map((key) => {
      const bp = pack.players.find((p) => `${p.playerId}__${p.versionId}` === key);
      if (!bp) return null;
      const resolved = resolveBoxPlayer(bp);
      if (!resolved) return null;
      return { ...resolved, tier: bp.tier, key };
    }).filter((x): x is NonNullable<typeof x> => x !== null);
  };

  return (
    <div>
      <SectionHeader
        title="Pack Opening"
        subtitle="5 themed box-draw packs. Each contains 150 players (3 Epic + 7 Highlight + 140 Standard). 1 spin = 100 coins, 10 spins = 1,000 coins."
        icon={<Package size={28} />}
      />

      {/* Coin balance */}
      <div className="fl-glass rounded-2xl p-4 mb-6 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-fl-gold to-fl-gold-deep flex items-center justify-center fl-glow-gold">
            <Coins size={24} className="text-fl-navy" />
          </div>
          <div>
            <div className="text-2xl font-black tabular-nums text-fl-gold">{coins.toLocaleString()}</div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Your Coins</div>
          </div>
        </div>
        <div className="flex gap-4 text-sm">
          <div className="text-center">
            <div className="font-black text-fl-neon">100 🪙</div>
            <div className="text-[10px] uppercase text-muted-foreground">1 Spin</div>
          </div>
          <div className="text-center">
            <div className="font-black text-fl-neon">1,000 🪙</div>
            <div className="text-[10px] uppercase text-muted-foreground">10 Spins</div>
          </div>
        </div>
      </div>

      {/* Pack grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {BOX_PACKS.map((pack) => (
          <PackCard
            key={pack.id}
            pack={pack}
            boxState={boxStates[pack.id]}
            coins={coins}
            onSpin={(spins) => handleSpin(pack, spins)}
            onSelect={() => setSelectedPack(pack)}
            onReset={() => handleResetBox(pack.id)}
            onHistory={() => setShowHistory(pack.id)}
          />
        ))}
      </div>

      {/* Confirmation modal */}
      <AnimatePresence>
        {confirmSpin && (
          <ConfirmSpinModal
            pack={confirmSpin.pack}
            spins={confirmSpin.spins}
            coins={coins}
            onConfirm={confirmAndSpin}
            onCancel={() => setConfirmSpin(null)}
          />
        )}
      </AnimatePresence>

      {/* Pack detail modal */}
      <AnimatePresence>
        {selectedPack && (
          <PackDetailModal
            pack={selectedPack}
            boxState={boxStates[selectedPack.id]}
            onClose={() => setSelectedPack(null)}
            onSpin={(spins) => {
              setSelectedPack(null);
              handleSpin(selectedPack, spins);
            }}
          />
        )}
      </AnimatePresence>

      {/* History modal */}
      <AnimatePresence>
        {showHistory && (
          <HistoryModal
            packId={showHistory}
            obtained={getObtainedCards(showHistory)}
            onClose={() => setShowHistory(null)}
          />
        )}
      </AnimatePresence>

      {/* Reveal stage */}
      {revealing && (
        <PackReveal cards={revealing} onClose={() => setRevealing(null)} />
      )}
    </div>
  );
}

// ============================================================
//  PACK CARD (grid item)
// ============================================================

function PackCard({ pack, boxState, coins, onSpin, onSelect, onReset, onHistory }: {
  pack: BoxPack;
  boxState: { remaining: string[]; obtained: string[] } | undefined;
  coins: number;
  onSpin: (spins: 1 | 10) => void;
  onSelect: () => void;
  onReset: () => void;
  onHistory: () => void;
}) {
  // Initialize box state if not exists
  const totalPlayers = pack.players.length;
  const remaining = boxState?.remaining.length ?? totalPlayers;
  const obtained = boxState?.obtained.length ?? 0;
  const isComplete = remaining === 0;

  // Count tiers remaining
  const tierCounts = useMemo(() => {
    const packTiers = getPackTierCounts(pack);
    let epicRemaining = 0, highlightRemaining = 0, standardRemaining = 0;
    const remainingSet = new Set(boxState?.remaining ?? pack.players.map(p => `${p.playerId}__${p.versionId}`));
    for (const bp of pack.players) {
      const key = `${bp.playerId}__${bp.versionId}`;
      if (remainingSet.has(key)) {
        if (bp.tier === 'epic') epicRemaining++;
        else if (bp.tier === 'highlight') highlightRemaining++;
        else standardRemaining++;
      }
    }
    return { epicRemaining, highlightRemaining, standardRemaining, epicTotal: packTiers.epic, highlightTotal: packTiers.highlight, standardTotal: packTiers.standard };
  }, [pack, boxState]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fl-glass rounded-2xl overflow-hidden flex flex-col"
      style={{ border: `1.5px solid ${pack.accent}40` }}
    >
      {/* Banner */}
      <button
        onClick={onSelect}
        className="relative h-40 overflow-hidden cursor-pointer"
        style={{ background: pack.bannerGradient }}
      >
        <div className="absolute inset-0 fl-shimmer opacity-40" />
        {/* Featured Epic players */}
        <div className="absolute bottom-2 left-2 flex gap-1">
          {pack.featuredEpic.slice(0, 3).map((fe, i) => {
            const player = getPlayer(fe.playerId);
            const version = player ? getVersion(fe.playerId, fe.versionId) : undefined;
            if (!player || !version) return null;
            return (
              <div
                key={i}
                className="w-8 h-8 rounded-full flex items-center justify-center font-black text-xs border-2 fl-icon-pulse"
                style={{
                  background: 'rgba(0,0,0,0.7)',
                  borderColor: '#fbbf24',
                  color: '#fde68a',
                }}
                title={player.name}
              >
                {version.ovr}
              </div>
            );
          })}
        </div>
        {isComplete && (
          <div className="absolute top-2 right-2 bg-fl-neon text-fl-navy px-2 py-1 rounded-md text-[10px] font-black uppercase tracking-wider fl-glow-neon">
            ✓ Complete
          </div>
        )}
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            animate={{ y: [0, -6, 0] }}
            transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
            className="text-6xl drop-shadow-2xl"
          >
            🎁
          </motion.div>
        </div>
        <div
          className="absolute top-2 left-2 px-2 py-1 rounded-md text-[10px] font-black tracking-wider uppercase backdrop-blur-sm"
          style={{ background: 'rgba(0,0,0,0.6)', color: pack.accent, border: `1px solid ${pack.accent}` }}
        >
          {pack.theme}
        </div>
      </button>

      {/* Info */}
      <div className="p-4 flex-1 flex flex-col">
        <h3 className="font-black text-base mb-1" style={{ color: pack.accent }}>{pack.name}</h3>
        <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{pack.description}</p>

        {/* Box progress */}
        <div className="bg-black/30 rounded-lg p-2.5 mb-3">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Box Progress</span>
            <span className="text-xs font-black tabular-nums">
              {obtained}/{totalPlayers}
            </span>
          </div>
          <div className="h-1.5 bg-black/40 rounded-full overflow-hidden mb-2">
            <motion.div
              className="h-full rounded-full"
              style={{ background: pack.accent }}
              initial={{ width: 0 }}
              animate={{ width: `${(obtained / totalPlayers) * 100}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
          {/* Tier breakdown */}
          <div className="grid grid-cols-3 gap-1.5 text-center">
            <TierBadge icon={<Crown size={9} />} label="Epic" remaining={tierCounts.epicRemaining} total={tierCounts.epicTotal} color="#fbbf24" />
            <TierBadge icon={<Star size={9} />} label="HLG" remaining={tierCounts.highlightRemaining} total={tierCounts.highlightTotal} color="#fcd34d" />
            <TierBadge icon={<Sparkles size={9} />} label="Std" remaining={tierCounts.standardRemaining} total={tierCounts.standardTotal} color="#94a3b8" />
          </div>
        </div>

        {/* Action buttons */}
        <div className="grid grid-cols-2 gap-2 mb-2">
          <button
            onClick={() => onSpin(1)}
            disabled={isComplete || coins < 100}
            className={cn(
              'py-2 rounded-lg font-black text-xs transition-all flex items-center justify-center gap-1',
              isComplete || coins < 100
                ? 'bg-black/40 text-muted-foreground cursor-not-allowed'
                : 'bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy hover:scale-105 fl-glow-neon'
            )}
          >
            <Play size={11} fill="currentColor" />
            1× Spin
            <span className="opacity-70">100</span>
          </button>
          <button
            onClick={() => onSpin(10)}
            disabled={isComplete || coins < 1000 || remaining < 10}
            className={cn(
              'py-2 rounded-lg font-black text-xs transition-all flex items-center justify-center gap-1',
              isComplete || coins < 1000 || remaining < 10
                ? 'bg-black/40 text-muted-foreground cursor-not-allowed'
                : 'bg-gradient-to-r from-fl-gold-deep to-fl-gold text-fl-navy hover:scale-105 fl-glow-gold'
            )}
          >
            <Zap size={11} />
            10× Spin
            <span className="opacity-70">1K</span>
          </button>
        </div>

        {/* Secondary actions */}
        <div className="flex gap-2">
          <button
            onClick={onHistory}
            className="flex-1 py-1.5 rounded-lg bg-black/30 hover:bg-white/5 text-[10px] font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-1"
          >
            <History size={10} /> History ({obtained})
          </button>
          <button
            onClick={onReset}
            className="px-2.5 py-1.5 rounded-lg bg-black/30 hover:bg-red-500/20 text-[10px] font-bold uppercase tracking-wider transition-colors"
            title="Reset box — restores all 150 players"
          >
            <RotateCcw size={10} />
          </button>
        </div>
      </div>
    </motion.div>
  );
}

function TierBadge({ icon, label, remaining, total, color }: {
  icon: React.ReactNode;
  label: string;
  remaining: number;
  total: number;
  color: string;
}) {
  return (
    <div className="bg-black/40 rounded px-1 py-0.5">
      <div className="flex items-center justify-center gap-0.5" style={{ color }}>
        {icon}
        <span className="text-[8px] uppercase font-bold">{label}</span>
      </div>
      <div className="text-[10px] font-black tabular-nums" style={{ color: remaining > 0 ? '#fff' : '#666' }}>
        {remaining}/{total}
      </div>
    </div>
  );
}

// ============================================================
//  CONFIRM SPIN MODAL
// ============================================================

function ConfirmSpinModal({ pack, spins, coins, onConfirm, onCancel }: {
  pack: BoxPack;
  spins: 1 | 10;
  coins: number;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const cost = spins === 1 ? 100 : 1000;
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
      onClick={onCancel}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="fl-glass-strong rounded-2xl p-6 max-w-sm w-full"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="text-center mb-4">
          <div className="text-4xl mb-2">🎰</div>
          <h3 className="text-xl font-black mb-1">Confirm Spin</h3>
          <p className="text-sm text-muted-foreground">
            {spins === 1 ? '1 spin' : '10 spins'} on <span style={{ color: pack.accent }} className="font-bold">{pack.name}</span>
          </p>
        </div>

        <div className="fl-glass rounded-xl p-4 mb-4 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Cost</span>
            <span className="font-black text-fl-gold">{cost.toLocaleString()} 🪙</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Your balance</span>
            <span className="font-black">{coins.toLocaleString()} 🪙</span>
          </div>
          <div className="flex justify-between text-sm border-t border-white/10 pt-2">
            <span className="text-muted-foreground">After spin</span>
            <span className="font-black text-fl-neon">{(coins - cost).toLocaleString()} 🪙</span>
          </div>
        </div>

        <div className="flex gap-2">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 rounded-lg bg-black/40 hover:bg-black/60 text-sm font-bold transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 py-2.5 rounded-lg bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy font-black text-sm hover:scale-105 transition-transform fl-glow-neon"
          >
            ✓ Confirm
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ============================================================
//  PACK DETAIL MODAL (shows featured players)
// ============================================================

function PackDetailModal({ pack, boxState, onClose, onSpin }: {
  pack: BoxPack;
  boxState: { remaining: string[]; obtained: string[] } | undefined;
  onClose: () => void;
  onSpin: (spins: 1 | 10) => void;
}) {
  const totalPlayers = pack.players.length;
  const remaining = boxState?.remaining.length ?? totalPlayers;
  const obtained = boxState?.obtained.length ?? 0;

  // Get featured Epic + Highlight players
  const featuredPlayers = pack.players
    .filter((p) => p.tier === 'epic' || p.tier === 'highlight')
    .map((bp) => {
      const resolved = resolveBoxPlayer(bp);
      return resolved ? { ...resolved, tier: bp.tier } : null;
    })
    .filter((x): x is NonNullable<typeof x> => x !== null);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="fl-glass-strong rounded-2xl p-6 max-w-2xl w-full my-8"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-3 right-3 p-2 rounded-lg bg-black/40 hover:bg-black/60 transition-colors"
        >
          <X size={18} />
        </button>

        {/* Header */}
        <div
          className="rounded-xl p-4 mb-4 text-center"
          style={{ background: pack.bannerGradient }}
        >
          <div className="text-3xl mb-1">🎁</div>
          <h2 className="text-2xl font-black" style={{ color: '#fff' }}>{pack.name}</h2>
          <p className="text-sm opacity-80">{pack.description}</p>
        </div>

        {/* Box stats */}
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="fl-glass rounded-xl p-3 text-center">
            <div className="text-2xl font-black text-fl-gold">{obtained}</div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Obtained</div>
          </div>
          <div className="fl-glass rounded-xl p-3 text-center">
            <div className="text-2xl font-black text-fl-neon">{remaining}</div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Remaining</div>
          </div>
          <div className="fl-glass rounded-xl p-3 text-center">
            <div className="text-2xl font-black text-blue-400">{totalPlayers}</div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Total</div>
          </div>
        </div>

        {/* Featured players */}
        <div className="mb-4">
          <h3 className="font-black uppercase tracking-wide text-fl-gold mb-3 flex items-center gap-2">
            <Crown size={14} /> Featured Epic & Highlight Players
          </h3>
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 justify-items-center">
            {featuredPlayers.map((fp, i) => (
              <PlayerCard
                key={i}
                player={fp.player}
                version={fp.version}
                size="sm"
                compact
              />
            ))}
          </div>
        </div>

        {/* Spin buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => onSpin(1)}
            className="py-3 rounded-lg bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy font-black text-sm hover:scale-105 transition-transform fl-glow-neon flex items-center justify-center gap-2"
          >
            <Play size={14} fill="currentColor" />
            1× Spin — 100 🪙
          </button>
          <button
            onClick={() => onSpin(10)}
            disabled={remaining < 10}
            className="py-3 rounded-lg bg-gradient-to-r from-fl-gold-deep to-fl-gold text-fl-navy font-black text-sm hover:scale-105 transition-transform fl-glow-gold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Zap size={14} />
            10× Spin — 1,000 🪙
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ============================================================
//  HISTORY MODAL
// ============================================================

function HistoryModal({ packId, obtained, onClose }: {
  packId: string;
  obtained: { player: Player; version: PlayerVersion; tier: CardTier; key: string }[];
  onClose: () => void;
}) {
  const pack = BOX_PACKS.find((p) => p.id === packId);
  if (!pack) return null;

  const sorted = [...obtained].sort((a, b) => {
    const tierOrder = { epic: 0, highlight: 1, standard: 2 };
    if (tierOrder[a.tier] !== tierOrder[b.tier]) return tierOrder[a.tier] - tierOrder[b.tier];
    return b.version.ovr - a.version.ovr;
  });

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="fl-glass-strong rounded-2xl p-6 max-w-3xl w-full max-h-[85vh] overflow-y-auto fl-scroll"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-3 right-3 p-2 rounded-lg bg-black/40 hover:bg-black/60 transition-colors z-10"
        >
          <X size={18} />
        </button>

        <h2 className="text-2xl font-black mb-1" style={{ color: pack.accent }}>{pack.name}</h2>
        <p className="text-sm text-muted-foreground mb-4">
          Obtained {obtained.length} of {pack.players.length} players from this box
        </p>

        {obtained.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <div className="text-5xl mb-3">📦</div>
            <p>No players obtained from this box yet. Start spinning!</p>
          </div>
        ) : (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3 justify-items-center">
            {sorted.map((item) => (
              <div key={item.key} className="relative">
                <PlayerCard player={item.player} version={item.version} size="sm" compact />
                {item.tier === 'epic' && (
                  <div className="absolute -top-1 -right-1 bg-fl-gold text-fl-navy text-[8px] font-black px-1.5 py-0.5 rounded-full fl-glow-gold">
                    EPIC
                  </div>
                )}
                {item.tier === 'highlight' && (
                  <div className="absolute -top-1 -right-1 bg-yellow-400 text-black text-[8px] font-black px-1.5 py-0.5 rounded-full">
                    HLG
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}
