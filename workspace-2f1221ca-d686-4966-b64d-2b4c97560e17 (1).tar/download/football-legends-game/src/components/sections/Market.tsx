'use client';

import { useGame } from '@/lib/store';
import { PlayerCard } from '@/components/cards/PlayerCard';
import { SectionHeader } from '@/components/ui-fl/shared';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import {
  getPlayer,
  getVersion,
  cardValue,
  RARITY_META,
  RARITY_ORDER,
} from '@/lib/players';
import { MarketListing, Player, PlayerVersion, Rarity } from '@/lib/types';
import { useEffect, useMemo, useState } from 'react';
import {
  ShoppingBag,
  RefreshCw,
  Coins,
  Store,
  AlertCircle,
  TrendingUp,
  TrendingDown,
} from 'lucide-react';

type SortKey = 'price-asc' | 'price-desc' | 'ovr-desc';
type FilterRarity = 'all' | Rarity;

export function MarketSection() {
  const coins = useGame((s) => s.coins);
  const marketListings = useGame((s) => s.marketListings);
  const generateMarketListings = useGame((s) => s.generateMarketListings);
  const buyMarketCard = useGame((s) => s.buyMarketCard);
  const marketRefreshKey = useGame((s) => s.marketRefreshKey);
  const { toast } = useToast();

  const [rarityFilter, setRarityFilter] = useState<FilterRarity>('all');
  const [sortKey, setSortKey] = useState<SortKey>('price-asc');
  const [refreshing, setRefreshing] = useState(false);
  const [buyingId, setBuyingId] = useState<string | null>(null);

  // Auto-generate listings on mount if empty
  useEffect(() => {
    if (marketListings.length === 0) {
      generateMarketListings();
    }
  }, []);

  // Build listing display data with resolved player/version
  const displayListings = useMemo(() => {
    const result: {
      listing: MarketListing;
      player: Player;
      version: PlayerVersion;
    }[] = [];
    for (const listing of marketListings) {
      const player = getPlayer(listing.playerId);
      const version = player ? getVersion(player.id, listing.versionId) : undefined;
      if (!player || !version) continue;
      if (rarityFilter !== 'all' && version.rarity !== rarityFilter) continue;
      result.push({ listing, player, version });
    }
    result.sort((a, b) => {
      switch (sortKey) {
        case 'price-asc':
          return a.listing.price - b.listing.price;
        case 'price-desc':
          return b.listing.price - a.listing.price;
        case 'ovr-desc':
          return b.version.ovr - a.version.ovr;
        default:
          return 0;
      }
    });
    return result;
  }, [marketListings, rarityFilter, sortKey]);

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => {
      generateMarketListings();
      setRefreshing(false);
      toast({
        title: 'Market refreshed',
        description: '18 fresh listings have arrived on the transfer market.',
      });
    }, 600);
  };

  const handleBuy = (listing: MarketListing, playerName: string) => {
    if (coins < listing.price) {
      toast({
        title: 'Not enough coins',
        description: `You need ${(listing.price - coins).toLocaleString()} more coins to buy ${playerName}.`,
        variant: 'destructive',
      });
      return;
    }
    setBuyingId(listing.id);
    const result = buyMarketCard(listing.id);
    setTimeout(() => setBuyingId((id) => (id === listing.id ? null : id)), 500);
    if (result.success) {
      toast({
        title: 'Card purchased!',
        description: `${playerName} has been added to your club for ${listing.price.toLocaleString()} coins.`,
      });
    } else {
      toast({ title: 'Purchase failed', description: result.error, variant: 'destructive' });
    }
  };

  return (
    <div>
      <SectionHeader
        title="Transfer Market"
        subtitle="Browse live listings and snap up football legends. New cards arrive with every refresh — act fast before they're gone!"
        icon={<ShoppingBag size={28} />}
      />

      {/* Coin balance + refresh bar */}
      <div className="fl-glass rounded-2xl p-4 mb-5 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-fl-gold to-fl-gold-deep flex items-center justify-center fl-glow-gold">
            <Coins size={24} className="text-fl-navy" />
          </div>
          <div>
            <div className="text-2xl font-black tabular-nums text-fl-gold fl-text-shadow-gold">
              {coins.toLocaleString()}
            </div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Your Coin Balance</div>
          </div>
        </div>
        <button
          onClick={handleRefresh}
          disabled={refreshing}
          className={cn(
            'px-4 py-2.5 rounded-lg font-bold text-sm transition-all flex items-center gap-2',
            'bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy hover:scale-105 fl-glow-neon',
            refreshing && 'opacity-70 cursor-wait hover:scale-100'
          )}
        >
          <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
          {refreshing ? 'Refreshing…' : 'Refresh Market'}
        </button>
      </div>

      {/* Filters + sort */}
      <div className="fl-glass rounded-2xl p-4 mb-6 space-y-3">
        <div className="flex flex-col md:flex-row md:items-start gap-3 md:gap-6">
          {/* Rarity filter */}
          <div className="flex-1">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">Filter by Rarity</div>
            <div className="flex flex-wrap gap-1">
              <button
                onClick={() => setRarityFilter('all')}
                className={cn(
                  'px-2.5 py-1 rounded text-xs font-bold transition-colors',
                  rarityFilter === 'all' ? 'bg-fl-neon text-fl-navy' : 'bg-black/30 hover:bg-white/10'
                )}
              >
                ALL
              </button>
              {RARITY_ORDER.map((r) => (
                <button
                  key={r}
                  onClick={() => setRarityFilter(r)}
                  className={cn(
                    'px-2.5 py-1 rounded text-xs font-bold transition-colors',
                    rarityFilter === r ? 'bg-fl-neon text-fl-navy' : 'bg-black/30 hover:bg-white/10'
                  )}
                  style={rarityFilter === r ? undefined : { color: RARITY_META[r].border }}
                >
                  {RARITY_META[r].label}
                </button>
              ))}
            </div>
          </div>

          {/* Sort */}
          <div className="md:w-60">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">Sort</div>
            <select
              value={sortKey}
              onChange={(e) => setSortKey(e.target.value as SortKey)}
              className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:border-fl-neon"
            >
              <option value="price-asc">Price: Low → High</option>
              <option value="price-desc">Price: High → Low</option>
              <option value="ovr-desc">OVR: Highest First</option>
            </select>
          </div>
        </div>

        {/* Meta row */}
        <div className="flex items-center justify-between text-xs text-muted-foreground pt-1 border-t border-white/5">
          <div className="flex items-center gap-1.5">
            <Store size={12} />
            <span>
              {displayListings.length} listing{displayListings.length !== 1 ? 's' : ''} available
            </span>
          </div>
          {marketRefreshKey && (
            <div className="text-[10px] tabular-nums">
              Last refresh: {new Date(marketRefreshKey).toLocaleString([], {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })}
            </div>
          )}
        </div>
      </div>

      {/* Empty state OR grid */}
      {displayListings.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="fl-glass rounded-2xl p-12 text-center"
        >
          <div className="text-6xl mb-4">🛒</div>
          <h3 className="text-xl font-black mb-2">No listings available</h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            The transfer market is empty right now. Generate fresh listings to discover new cards up for sale.
          </p>
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg font-bold text-sm bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy hover:scale-105 fl-glow-neon transition-all disabled:opacity-70"
          >
            <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
            {refreshing ? 'Generating…' : 'Generate Listings'}
          </button>
        </motion.div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 md:gap-4 justify-items-center">
          <AnimatePresence mode="popLayout">
            {displayListings.map(({ listing, player, version }, i) => (
              <MarketListingCard
                key={listing.id}
                listing={listing}
                player={player}
                version={version}
                affordable={coins >= listing.price}
                buying={buyingId === listing.id}
                index={i}
                onBuy={() => handleBuy(listing, player.name)}
              />
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}

function MarketListingCard({
  listing,
  player,
  version,
  affordable,
  buying,
  index,
  onBuy,
}: {
  listing: MarketListing;
  player: Player;
  version: PlayerVersion;
  affordable: boolean;
  buying: boolean;
  index: number;
  onBuy: () => void;
}) {
  const meta = RARITY_META[version.rarity];
  const marketValue = cardValue(version);
  const dealType: 'deal' | 'fair' | 'overpriced' =
    listing.price < marketValue * 0.92
      ? 'deal'
      : listing.price > marketValue * 1.1
        ? 'overpriced'
        : 'fair';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9, y: 12 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.85, y: -8 }}
      transition={{ duration: 0.3, delay: Math.min(index * 0.02, 0.4) }}
      whileHover={{ y: -4 }}
      className="fl-glass rounded-2xl p-3 flex flex-col items-center gap-2.5 w-full max-w-[180px]"
      style={{ border: `1.5px solid ${meta.border}30` }}
    >
      <PlayerCard player={player} version={version} size="sm" />

      {/* Price + value + deal indicator */}
      <div className="w-full flex flex-col items-center gap-0.5">
        <div className="flex items-center gap-1 text-fl-gold font-black tabular-nums text-lg fl-text-shadow-gold">
          <Coins size={14} className="fill-fl-gold text-fl-gold-deep" />
          {listing.price.toLocaleString()}
        </div>
        <div className="text-[9px] uppercase tracking-wider text-muted-foreground">
          Value {marketValue.toLocaleString()}
        </div>
        {dealType === 'deal' && (
          <div className="mt-0.5 text-[9px] font-black uppercase tracking-wider text-fl-neon flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-fl-neon/15">
            <TrendingUp size={9} /> Below Market
          </div>
        )}
        {dealType === 'overpriced' && (
          <div className="mt-0.5 text-[9px] font-black uppercase tracking-wider text-orange-400 flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-orange-500/15">
            <TrendingDown size={9} /> Above Market
          </div>
        )}
      </div>

      {/* Buy button */}
      <button
        onClick={onBuy}
        disabled={buying}
        className={cn(
          'w-full py-2 rounded-lg font-bold text-xs uppercase tracking-wide transition-all flex items-center justify-center gap-1.5',
          affordable && !buying
            ? 'bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy hover:scale-[1.03] fl-glow-neon'
            : 'bg-black/40 text-muted-foreground hover:bg-black/60 hover:text-foreground border border-white/5',
          buying && 'opacity-70 cursor-wait'
        )}
      >
        {buying ? (
          <>
            <RefreshCw size={12} className="animate-spin" /> Buying…
          </>
        ) : affordable ? (
          <>
            <ShoppingBag size={12} /> Buy Now
          </>
        ) : (
          <>
            <AlertCircle size={12} /> Insufficient
          </>
        )}
      </button>
    </motion.div>
  );
}
