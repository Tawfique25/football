'use client';

import { useGame } from '@/lib/store';
import { PLAYERS, RARITY_META, RARITY_ORDER, flagEmoji, cardValue, cardSellPrice } from '@/lib/players';
import { Player, PlayerVersion, Rarity, Position, CollectedCard } from '@/lib/types';
import { PlayerCard } from '@/components/cards/PlayerCard';
import { SectionHeader } from '@/components/ui-fl/shared';
import { DUPLICATE_REWARDS } from '@/lib/packs';
import { motion, AnimatePresence } from 'framer-motion';
import { useMemo, useState, useEffect } from 'react';
import { Search, Filter, ArrowUpDown, Users, Repeat, X, Coins, Tag } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

type SortKey = 'recent' | 'rating-desc' | 'rating-asc' | 'name';

export function MyClubSection() {
  const collection = useGame((s) => s.collection);
  const lookupCard = useGame((s) => s.lookupCard);
  const exchangeDuplicate = useGame((s) => s.exchangeDuplicate);
  const exchangeAllDuplicates = useGame((s) => s.exchangeAllDuplicates);
  const clearNewFlags = useGame((s) => s.clearNewFlags);
  const sellCard = useGame((s) => s.sellCard);
  const { toast } = useToast();

  const [search, setSearch] = useState('');
  const [posFilter, setPosFilter] = useState<string>('all');
  const [rarityFilter, setRarityFilter] = useState<string>('all');
  const [nationalityFilter, setNationalityFilter] = useState<string>('all');
  const [sortKey, setSortKey] = useState<SortKey>('recent');
  const [selectedCard, setSelectedCard] = useState<CollectedCard | null>(null);

  // Clear NEW flags on first mount
  useEffect(() => {
    const t = setTimeout(() => clearNewFlags(), 4000);
    return () => clearTimeout(t);
     
  }, []);

  // Build nationality options from collection
  const nationalities = useMemo(() => {
    const set = new Set<string>();
    for (const c of collection) {
      const entry = lookupCard(c.id);
      if (entry) set.add(entry.player.nationality);
    }
    return Array.from(set).sort();
  }, [collection, lookupCard]);

  // Apply filters
  const filteredCards = useMemo(() => {
    const result: { card: CollectedCard; player: Player; version: PlayerVersion }[] = [];
    for (const c of collection) {
      const entry = lookupCard(c.id);
      if (!entry) continue;
      const { player, version } = entry;

      if (search && !player.name.toLowerCase().includes(search.toLowerCase()) && !version.versionName.toLowerCase().includes(search.toLowerCase())) continue;
      if (posFilter !== 'all') {
        if (posFilter === 'GK' && player.position !== 'GK') continue;
        if (posFilter === 'DEF' && !['CB', 'LB', 'RB', 'LWB', 'RWB'].includes(player.position)) continue;
        if (posFilter === 'MID' && !['CDM', 'CM', 'CAM', 'LM', 'RM'].includes(player.position)) continue;
        if (posFilter === 'ATT' && !['LW', 'RW', 'ST', 'CF'].includes(player.position)) continue;
      }
      if (rarityFilter !== 'all' && version.rarity !== rarityFilter) continue;
      if (nationalityFilter !== 'all' && player.nationality !== nationalityFilter) continue;

      result.push({ card: c, player, version });
    }

    result.sort((a, b) => {
      switch (sortKey) {
        case 'recent':
          return new Date(b.card.lastAcquiredAt).getTime() - new Date(a.card.lastAcquiredAt).getTime();
        case 'rating-desc':
          return b.version.ovr - a.version.ovr;
        case 'rating-asc':
          return a.version.ovr - b.version.ovr;
        case 'name':
          return a.player.name.localeCompare(b.player.name);
      }
    });
    return result;
  }, [collection, lookupCard, search, posFilter, rarityFilter, nationalityFilter, sortKey]);

  const duplicateCount = collection.filter((c) => c.count > 1).reduce((s, c) => s + (c.count - 1), 0);
  const totalDupReward = collection.reduce((s, c) => {
    if (c.count > 1) {
      const entry = lookupCard(c.id);
      if (entry) return s + DUPLICATE_REWARDS[entry.version.rarity] * (c.count - 1);
    }
    return s;
  }, 0);

  const handleExchangeAll = () => {
    const total = exchangeAllDuplicates();
    if (total > 0) {
      toast({
        title: 'Duplicates exchanged!',
        description: `Exchanged ${duplicateCount} duplicate cards for ${total.toLocaleString()} coins.`,
      });
    } else {
      toast({ title: 'No duplicates to exchange', variant: 'destructive' });
    }
  };

  const handleExchangeOne = (card: CollectedCard) => {
    if (card.count <= 1) {
      toast({ title: 'Cannot exchange', description: 'You only have one copy of this card.', variant: 'destructive' });
      return;
    }
    const entry = lookupCard(card.id);
    if (!entry) return;
    const reward = DUPLICATE_REWARDS[entry.version.rarity];
    exchangeDuplicate(card.id);
    toast({
      title: 'Card exchanged',
      description: `+${reward} coins for a duplicate ${entry.version.rarity} card.`,
    });
    // Update selected card
    setSelectedCard({ ...card, count: card.count - 1 });
  };

  const handleSell = (card: CollectedCard) => {
    const entry = lookupCard(card.id);
    if (!entry) return;
    const result = sellCard(card.id);
    if (result.success) {
      toast({
        title: 'Card sold',
        description: `+${result.coins} coins for selling ${entry.player.name}.`,
      });
      // Close modal if no more copies, else update count
      if (card.count <= 1) {
        setSelectedCard(null);
      } else {
        setSelectedCard({ ...card, count: card.count - 1 });
      }
    } else {
      toast({ title: 'Cannot sell', description: result.error, variant: 'destructive' });
    }
  };

  return (
    <div>
      <SectionHeader
        title="My Club"
        subtitle={`You've collected ${collection.length} unique cards from ${PLAYERS.length} football legends and stars.`}
        icon={<Users size={28} />}
      />

      {/* Top bar with stats + exchange */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <div className="fl-glass rounded-xl p-3 text-center">
          <div className="text-2xl font-black text-fl-neon tabular-nums">{collection.length}</div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Unique Cards</div>
        </div>
        <div className="fl-glass rounded-xl p-3 text-center">
          <div className="text-2xl font-black text-fl-gold tabular-nums">{collection.reduce((s, c) => s + c.count, 0)}</div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Total Cards</div>
        </div>
        <div className="fl-glass rounded-xl p-3 text-center">
          <div className="text-2xl font-black text-blue-400 tabular-nums">{duplicateCount}</div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Duplicates</div>
        </div>
        <button
          onClick={handleExchangeAll}
          disabled={duplicateCount === 0}
          className={cn(
            'fl-glass rounded-xl p-3 text-center transition-all',
            duplicateCount > 0 ? 'hover:scale-105 hover:bg-fl-gold/10 cursor-pointer' : 'opacity-50 cursor-not-allowed'
          )}
        >
          <div className="text-2xl font-black text-fl-gold tabular-nums">{totalDupReward.toLocaleString()}</div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center justify-center gap-1">
            <Repeat size={10} /> Exchange All
          </div>
        </button>
      </div>

      {/* Filters */}
      <div className="fl-glass rounded-2xl p-4 mb-6 space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search */}
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search by player or version name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-3 py-2 rounded-lg bg-black/30 border border-white/10 text-sm focus:outline-none focus:border-fl-neon"
            />
          </div>
          {/* Sort */}
          <div className="flex items-center gap-2">
            <ArrowUpDown size={14} className="text-muted-foreground" />
            <select
              value={sortKey}
              onChange={(e) => setSortKey(e.target.value as SortKey)}
              className="bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-fl-neon"
            >
              <option value="recent">Most Recent</option>
              <option value="rating-desc">Rating (High to Low)</option>
              <option value="rating-asc">Rating (Low to High)</option>
              <option value="name">Name (A-Z)</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Position filter */}
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Position</div>
            <div className="flex flex-wrap gap-1">
              {['all', 'GK', 'DEF', 'MID', 'ATT'].map((p) => (
                <button
                  key={p}
                  onClick={() => setPosFilter(p)}
                  className={cn(
                    'px-2.5 py-1 rounded text-xs font-bold transition-colors',
                    posFilter === p ? 'bg-fl-neon text-fl-navy' : 'bg-black/30 hover:bg-white/10'
                  )}
                >
                  {p === 'all' ? 'ALL' : p}
                </button>
              ))}
            </div>
          </div>
          {/* Rarity filter */}
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Rarity</div>
            <div className="flex flex-wrap gap-1">
              <button
                onClick={() => setRarityFilter('all')}
                className={cn(
                  'px-2.5 py-1 rounded text-xs font-bold transition-colors',
                  rarityFilter === 'all' ? 'bg-fl-neon text-fl-navy' : 'bg-black/30 hover:bg-white/10'
                )}
              >
                ALL
              </button>
              {RARITY_ORDER.map((r) => (
                <button
                  key={r}
                  onClick={() => setRarityFilter(r)}
                  className={cn(
                    'px-2.5 py-1 rounded text-xs font-bold transition-colors',
                    rarityFilter === r ? 'bg-fl-neon text-fl-navy' : 'bg-black/30 hover:bg-white/10'
                  )}
                  style={rarityFilter === r ? {} : { color: RARITY_META[r].border }}
                >
                  {RARITY_META[r].label}
                </button>
              ))}
            </div>
          </div>
          {/* Nationality filter */}
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Nationality</div>
            <select
              value={nationalityFilter}
              onChange={(e) => setNationalityFilter(e.target.value)}
              className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-fl-neon"
            >
              <option value="all">All Nationalities</option>
              {nationalities.map((n) => (
                <option key={n} value={n}>{n}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Cards grid */}
      {filteredCards.length === 0 ? (
        <div className="fl-glass rounded-2xl p-12 text-center">
          <div className="text-6xl mb-3">📭</div>
          <p className="text-muted-foreground mb-4">
            {collection.length === 0
              ? 'You haven\'t collected any cards yet. Open your first pack!'
              : 'No cards match your filters.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 justify-items-center">
          {filteredCards.map(({ card, player, version }) => (
            <PlayerCard
              key={card.id}
              player={player}
              version={version}
              size="sm"
              count={card.count}
              isNew={card.isNew}
              onClick={() => setSelectedCard(card)}
            />
          ))}
        </div>
      )}

      {/* Detail modal */}
      <AnimatePresence>
        {selectedCard && (
          <CardDetailModal
            card={selectedCard}
            onClose={() => setSelectedCard(null)}
            onExchange={() => handleExchangeOne(selectedCard)}
            onSell={() => handleSell(selectedCard)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function CardDetailModal({ card, onClose, onExchange, onSell }: {
  card: CollectedCard;
  onClose: () => void;
  onExchange: () => void;
  onSell: () => void;
}) {
  const entry = useGame.getState().lookupCard(card.id);
  if (!entry) return null;
  const { player, version } = entry;
  const meta = RARITY_META[version.rarity];
  const dupReward = DUPLICATE_REWARDS[version.rarity];
  const marketValue = cardValue(version);
  const sellPrice = cardSellPrice(version);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.85, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.85, opacity: 0 }}
        className="fl-glass-strong rounded-2xl p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto fl-scroll"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-3 right-3 p-2 rounded-lg bg-black/40 hover:bg-black/60 transition-colors"
        >
          <X size={18} />
        </button>

        <div className="flex flex-col md:flex-row gap-6">
          {/* Card */}
          <div className="flex-shrink-0 flex justify-center">
            <PlayerCard player={player} version={version} size="lg" count={card.count} isNew={card.isNew} />
          </div>

          {/* Details */}
          <div className="flex-1 space-y-4">
            <div>
              <div className="text-xs uppercase tracking-widest font-bold" style={{ color: meta.border }}>
                {meta.label}
              </div>
              <h2 className="text-3xl font-black">{player.name}</h2>
              <p className="text-sm text-muted-foreground">{version.versionName}</p>
            </div>

            <div className="grid grid-cols-2 gap-2 text-sm">
              <InfoRow label="Position" value={player.position} />
              <InfoRow label="Alt Positions" value={player.altPositions.length > 0 ? player.altPositions.join(', ') : '—'} />
              <InfoRow label="Nationality" value={`${flagEmoji(player.countryCode)} ${player.nationality}`} />
              <InfoRow label="Club" value={player.club} />
              <InfoRow label="League" value={player.league} />
              <InfoRow label="Overall" value={`${version.ovr} OVR`} />
            </div>

            {/* Stats bars */}
            <div className="space-y-1.5">
              <div className="text-xs uppercase tracking-wider font-bold mb-2">Attributes</div>
              {(['pac', 'sho', 'pas', 'dri', 'def', 'phy'] as const).map((stat) => (
                <StatBar key={stat} label={stat.toUpperCase()} value={(version.stats as any)[stat]} />
              ))}
            </div>

            {/* Market value + owned + sell/exchange */}
            <div className="fl-glass rounded-xl p-3 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                    <Tag size={10} /> Market Value
                  </div>
                  <div className="text-xl font-black text-fl-gold">{marketValue.toLocaleString()} 🪙</div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-muted-foreground uppercase tracking-wider">Owned</div>
                  <div className="text-xl font-black text-fl-neon">×{card.count}</div>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={onSell}
                  className="flex-1 px-3 py-2 rounded-lg font-bold text-sm transition-all flex items-center justify-center gap-2 bg-gradient-to-r from-fl-neon-dim to-fl-neon text-fl-navy hover:scale-105 fl-glow-neon"
                >
                  <Coins size={14} />
                  Sell for {sellPrice.toLocaleString()} 🪙
                </button>
                <button
                  onClick={onExchange}
                  disabled={card.count <= 1}
                  className={cn(
                    'px-3 py-2 rounded-lg font-bold text-sm transition-all flex items-center gap-2',
                    card.count > 1
                      ? 'bg-gradient-to-r from-fl-gold-deep to-fl-gold text-fl-navy hover:scale-105 fl-glow-gold'
                      : 'bg-black/40 text-muted-foreground cursor-not-allowed'
                  )}
                  title="Exchange a duplicate for coins"
                >
                  <Repeat size={14} />
                  Exchange Dupe
                </button>
              </div>
            </div>

            <div className="text-xs text-muted-foreground">
              Acquired: {new Date(card.acquiredAt).toLocaleDateString()} • Last: {new Date(card.lastAcquiredAt).toLocaleString()}
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="fl-glass rounded-lg p-2">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="font-bold text-sm">{value}</div>
    </div>
  );
}

function StatBar({ label, value }: { label: string; value: number }) {
  const color = value >= 90 ? '#b3ff3a' : value >= 80 ? '#fbbf24' : value >= 70 ? '#fb923c' : '#94a3b8';
  return (
    <div className="flex items-center gap-2">
      <div className="w-10 text-xs font-bold">{label}</div>
      <div className="w-8 text-sm font-black tabular-nums" style={{ color }}>{value}</div>
      <div className="flex-1 h-2 bg-black/40 rounded-full overflow-hidden">
        <motion.div
          className="h-full rounded-full"
          style={{ background: color }}
          initial={{ width: 0 }}
          animate={{ width: `${value}%` }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
        />
      </div>
    </div>
  );
}
