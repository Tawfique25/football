'use client';

import { useGame } from '@/lib/store';
import { ACHIEVEMENTS, getAchievementProgress, isAchievementComplete } from '@/lib/achievements';
import { SectionHeader } from '@/components/ui-fl/shared';
import { motion } from 'framer-motion';
import { Trophy, Coins, Check, Lock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export function AchievementsSection() {
  const achievementsClaimed = useGame((s) => s.achievementsClaimed);
  const claimAchievement = useGame((s) => s.claimAchievement);
  const state = useGame();
  const { toast } = useToast();

  const stats = ACHIEVEMENTS.reduce(
    (acc, a) => {
      const p = getAchievementProgress(a, state);
      if (p >= a.goal) acc.completed++;
      return acc;
    },
    { completed: 0 }
  );

  const handleClaim = (id: string, name: string, reward: number) => {
    claimAchievement(id);
    toast({
      title: '🎉 Achievement Unlocked!',
      description: `${name} — +${reward} coins`,
    });
  };

  return (
    <div>
      <SectionHeader
        title="Achievements"
        subtitle={`${achievementsClaimed.length} / ${ACHIEVEMENTS.length} unlocked. Complete challenges to earn coins and bragging rights.`}
        icon={<Trophy size={28} />}
      />

      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <div className="fl-glass rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-fl-gold">{achievementsClaimed.length}</div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Claimed</div>
        </div>
        <div className="fl-glass rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-fl-neon">{stats.completed - achievementsClaimed.length}</div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Ready to Claim</div>
        </div>
        <div className="fl-glass rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-blue-400">{ACHIEVEMENTS.length - stats.completed}</div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">In Progress</div>
        </div>
        <div className="fl-glass rounded-xl p-4 text-center">
          <div className="text-3xl font-black text-fl-gold">
            {ACHIEVEMENTS.filter((a) => achievementsClaimed.includes(a.id)).reduce((s, a) => s + a.reward, 0).toLocaleString()}
          </div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Coins Earned</div>
        </div>
      </div>

      {/* Achievement grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {ACHIEVEMENTS.map((a, i) => {
          const progress = getAchievementProgress(a, state);
          const completed = progress >= a.goal;
          const claimed = achievementsClaimed.includes(a.id);
          const readyToClaim = completed && !claimed;
          const pct = Math.min(100, (progress / a.goal) * 100);

          return (
            <motion.div
              key={a.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.02 }}
              className={cn(
                'fl-glass rounded-xl p-4 relative overflow-hidden',
                claimed && 'opacity-70',
                readyToClaim && 'border-2 border-fl-gold fl-glow-gold'
              )}
            >
              {claimed && (
                <div className="absolute top-2 right-2 bg-fl-neon/20 text-fl-neon text-[9px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider flex items-center gap-1">
                  <Check size={10} /> Claimed
                </div>
              )}
              {readyToClaim && !claimed && (
                <div className="absolute top-2 right-2 bg-fl-gold/20 text-fl-gold text-[9px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider animate-pulse">
                  Ready!
                </div>
              )}

              <div className="flex items-start gap-3 mb-3">
                <div className={cn(
                  'text-4xl flex-shrink-0',
                  !completed && !claimed && 'opacity-50 grayscale'
                )}>
                  {a.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-black text-sm">{a.name}</div>
                  <div className="text-xs text-muted-foreground">{a.description}</div>
                </div>
              </div>

              {/* Progress bar */}
              {!claimed && (
                <div className="mb-3">
                  <div className="flex items-center justify-between text-[10px] mb-1">
                    <span className="text-muted-foreground uppercase tracking-wider">Progress</span>
                    <span className="font-bold tabular-nums">{progress.toLocaleString()} / {a.goal.toLocaleString()}</span>
                  </div>
                  <div className="h-2 bg-black/40 rounded-full overflow-hidden">
                    <motion.div
                      className={cn('h-full rounded-full', completed ? 'bg-fl-gold' : 'bg-gradient-to-r from-fl-neon-dim to-fl-neon')}
                      initial={{ width: 0 }}
                      animate={{ width: `${pct}%` }}
                      transition={{ duration: 0.6 }}
                    />
                  </div>
                </div>
              )}

              {/* Reward + claim button */}
              <div className="flex items-center justify-between">
                <div className="text-xs text-fl-gold font-bold flex items-center gap-1">
                  <Coins size={12} className="fill-fl-gold" />
                  {a.reward > 0 ? `+${a.reward.toLocaleString()}` : 'Glory only'}
                </div>
                {claimed ? (
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Check size={12} /> Done
                  </span>
                ) : readyToClaim ? (
                  <button
                    onClick={() => handleClaim(a.id, a.name, a.reward)}
                    className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-fl-gold-deep to-fl-gold text-fl-navy font-black text-xs hover:scale-105 transition-transform fl-glow-gold"
                  >
                    CLAIM
                  </button>
                ) : (
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Lock size={12} /> Locked
                  </span>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
