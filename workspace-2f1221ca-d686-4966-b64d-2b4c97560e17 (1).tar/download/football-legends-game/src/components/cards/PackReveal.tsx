'use client';

import { Player, PlayerVersion, CardTier } from '@/lib/types';
import { flagEmoji } from '@/lib/players';
import { PlayerCard } from './PlayerCard';
import { motion, AnimatePresence } from 'framer-motion';
import { useEffect, useMemo, useState } from 'react';
import { Sparkles, Star, Crown, X, ChevronRight, SkipForward, Flame } from 'lucide-react';

interface PackRevealProps {
  cards: { player: Player; version: PlayerVersion; tier: CardTier }[];
  onClose: () => void;
  onAddToSquad?: (cardId: string) => void;
}

// ============================================================
//  TIER METADATA — drives animation style, particles & banners
// ============================================================
const TIER_META = {
  standard: {
    label: 'STANDARD',
    color: '#94a3b8',
    icon: Sparkles,
    particles: 8,
    glow: 'rgba(148,163,184,0.4)',
  },
  highlight: {
    label: 'HIGHLIGHT',
    color: '#fcd34d',
    icon: Star,
    particles: 32,
    glow: 'rgba(252,211,77,0.8)',
  },
  epic: {
    label: 'EPIC',
    color: '#fbbf24',
    icon: Crown,
    particles: 80,
    glow: 'rgba(251,191,36,1)',
  },
} as const;

// Per-tier animation timing (ms)
const TIER_TIMING: Record<CardTier, { preDelay: number; flipDuration: number }> = {
  standard: { preDelay: 100, flipDuration: 600 },
  highlight: { preDelay: 200, flipDuration: 800 },
  epic: { preDelay: 800, flipDuration: 1000 }, // 300ms darken + 500ms shake, then flip
};

// ============================================================
//  PARTICLE BURST — different patterns per tier
// ============================================================
interface ParticleSpec {
  id: number;
  size: number;
  delay: number;
  duration: number;
  rotate: number;
  color: string;
  driftX: number;
  driftY: number;
}

function ParticleBurst({ tier }: { tier: CardTier }) {
  const meta = TIER_META[tier];
  const Icon = meta.icon;

  // Compute particle targets once per tier change (avoids re-randomizing on re-render)
  const particles = useMemo<ParticleSpec[]>(() => {
    return Array.from({ length: meta.particles }, (_, i) => {
      const angle = (i / meta.particles) * Math.PI * 2 + (Math.random() - 0.5) * 0.4;
      const isRed = tier === 'epic' && Math.random() > 0.5;
      const color =
        tier === 'epic'
          ? isRed
            ? '#dc2626'
            : '#fbbf24'
          : tier === 'highlight'
          ? Math.random() > 0.3
            ? '#fcd34d'
            : '#fde68a'
          : '#cbd5e1';

      // Standard = rising sparkles; highlight/epic = outward explosion
      const driftX =
        tier === 'standard'
          ? (Math.random() - 0.5) * 140
          : Math.cos(angle) * (90 + Math.random() * 240);
      const driftY =
        tier === 'standard'
          ? -180 - Math.random() * 140
          : Math.sin(angle) * (90 + Math.random() * 240);

      return {
        id: i,
        size: tier === 'standard' ? 6 + Math.random() * 8 : 6 + Math.random() * 16,
        delay: Math.random() * (tier === 'epic' ? 0.25 : 0.15),
        duration: 0.9 + Math.random() * 0.8,
        rotate: Math.random() * 540 - 270,
        color,
        driftX,
        driftY,
      };
    });
  }, [tier, meta]);

  return (
    <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-20">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute"
          initial={{ opacity: 0, scale: 0, x: 0, y: 0, rotate: 0 }}
          animate={{
            opacity: [0, 1, 1, 0],
            scale: [0, 1.3, 0.85, 0.2],
            x: p.driftX,
            y: p.driftY,
            rotate: p.rotate,
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            ease: 'easeOut',
            times: [0, 0.15, 0.7, 1],
          }}
          style={{ color: p.color, filter: `drop-shadow(0 0 6px ${p.color})` }}
        >
          <Icon size={p.size} fill="currentColor" />
        </motion.div>
      ))}
    </div>
  );
}

// ============================================================
//  GOLD LIGHT RAYS — for HIGHLIGHT tier
// ============================================================
function GoldLightRays() {
  const rays = useMemo(() => Array.from({ length: 14 }, (_, i) => i), []);
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-10">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
        {rays.map((i) => {
          const angle = (i / rays.length) * 360;
          return (
            <motion.div
              key={i}
              className="absolute top-0 left-0"
              style={{
                width: '5px',
                height: '340px',
                marginLeft: '-2.5px',
                background:
                  'linear-gradient(180deg, rgba(252,211,77,0.9) 0%, rgba(252,211,77,0.4) 30%, transparent 100%)',
                transformOrigin: '50% 0%',
                transform: `rotate(${angle}deg)`,
                filter: 'blur(3px)',
              }}
              initial={{ opacity: 0, scaleY: 0 }}
              animate={{
                opacity: [0, 0.9, 0.5, 0.85, 0.5],
                scaleY: [0, 1, 1, 1, 1],
              }}
              transition={{
                duration: 1.8,
                delay: i * 0.04,
                repeat: Infinity,
                repeatType: 'reverse',
                ease: 'easeInOut',
              }}
            />
          );
        })}
      </div>
    </div>
  );
}

// ============================================================
//  STADIUM LIGHTS — 8 sweeping beams for EPIC tier
// ============================================================
function StadiumLights() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-10">
      {Array.from({ length: 8 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute top-0 origin-top"
          style={{
            left: `${8 + i * 12}%`,
            width: '70px',
            height: '120%',
            marginLeft: '-35px',
            background:
              'linear-gradient(180deg, rgba(251,191,36,0.55) 0%, rgba(251,191,36,0.18) 35%, transparent 80%)',
            filter: 'blur(22px)',
            transformOrigin: 'top center',
          }}
          animate={{
            opacity: [0, 0.9, 0.35, 0.9, 0],
            rotate: [-9, 5, -5, 9, -9],
            scaleX: [0.6, 1, 0.85, 1.2, 0.6],
          }}
          transition={{
            duration: 3.6,
            delay: i * 0.4,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
      ))}
    </div>
  );
}

// ============================================================
//  ENERGY BORDER — pulsing red/gold flow around EPIC card
// ============================================================
function EnergyBorder() {
  return (
    <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-10">
      <motion.div
        className="rounded-2xl"
        style={{
          width: 300,
          height: 412,
          background:
            'linear-gradient(120deg, #dc2626 0%, #fbbf24 25%, #fde68a 50%, #fbbf24 75%, #dc2626 100%)',
          backgroundSize: '300% 300%',
          filter: 'blur(10px)',
        }}
        animate={{
          backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
          scale: [1, 1.04, 1],
          opacity: [0.55, 0.85, 0.55],
        }}
        transition={{
          duration: 2.5,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />
    </div>
  );
}

// ============================================================
//  TIER BACKGROUND — radial glow that intensifies on reveal
// ============================================================
function TierBackground({ tier, revealed }: { tier: CardTier; revealed: boolean }) {
  const isEpic = tier === 'epic';
  const isHighlight = tier === 'highlight';
  return (
    <>
      {/* Solid base */}
      <motion.div
        className="absolute inset-0"
        initial={{ backgroundColor: '#0a0e1f' }}
        animate={{
          backgroundColor: isEpic ? (revealed ? '#000000' : '#050507') : '#0a0e1f',
        }}
        transition={{ duration: isEpic ? 0.4 : 0.2 }}
      />
      {/* Radial glow */}
      <motion.div
        className="absolute inset-0"
        initial={{ opacity: 0.3 }}
        animate={{ opacity: revealed ? 1 : 0.35 }}
        transition={{ duration: 0.6 }}
        style={{
          background: isEpic
            ? 'radial-gradient(circle at center, rgba(220,38,38,0.28) 0%, rgba(251,191,36,0.18) 30%, rgba(0,0,0,0.6) 70%, #000 100%)'
            : isHighlight
            ? 'radial-gradient(circle at center, rgba(252,211,77,0.38) 0%, rgba(252,211,77,0.12) 40%, rgba(10,14,31,0.85) 75%)'
            : 'radial-gradient(circle at center, rgba(148,163,184,0.18) 0%, rgba(10,14,31,0.6) 60%, #0a0e1f 100%)',
        }}
      />
      {/* Subtle grid for epic */}
      {isEpic && (
        <div
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage:
              'linear-gradient(rgba(251,191,36,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(251,191,36,0.06) 1px, transparent 1px)',
            backgroundSize: '40px 40px',
            maskImage: 'radial-gradient(circle at center, black 30%, transparent 80%)',
            WebkitMaskImage: 'radial-gradient(circle at center, black 30%, transparent 80%)',
          }}
        />
      )}
    </>
  );
}

// ============================================================
//  TIER BANNER — pops at top when card is revealed
// ============================================================
function TierBanner({ tier, visible }: { tier: CardTier; visible: boolean }) {
  const meta = TIER_META[tier];
  const Icon = meta.icon;
  const isEpic = tier === 'epic';
  const isHighlight = tier === 'highlight';

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="absolute top-6 left-0 right-0 flex justify-center z-30 px-4"
          initial={{ y: -50, opacity: 0, scale: 0.7 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          exit={{ y: -50, opacity: 0, scale: 0.7 }}
          transition={{ type: 'spring', stiffness: 220, damping: 16, delay: 0.15 }}
        >
          <motion.div
            className="inline-flex items-center gap-2.5 px-6 py-2.5 rounded-full font-black text-sm sm:text-base tracking-[0.3em] uppercase"
            animate={
              isEpic
                ? { boxShadow: [
                    '0 0 24px rgba(220,38,38,0.7), 0 0 48px rgba(251,191,36,0.5)',
                    '0 0 40px rgba(251,191,36,0.9), 0 0 80px rgba(220,38,38,0.6)',
                    '0 0 24px rgba(220,38,38,0.7), 0 0 48px rgba(251,191,36,0.5)',
                  ] }
                : isHighlight
                ? { boxShadow: [
                    '0 0 20px rgba(252,211,77,0.6), 0 0 40px rgba(252,211,77,0.35)',
                    '0 0 32px rgba(252,211,77,0.9), 0 0 64px rgba(252,211,77,0.5)',
                    '0 0 20px rgba(252,211,77,0.6), 0 0 40px rgba(252,211,77,0.35)',
                  ] }
                : { boxShadow: '0 0 16px rgba(148,163,184,0.4)' }
            }
            transition={
              isEpic || isHighlight
                ? { duration: 1.6, repeat: Infinity, ease: 'easeInOut' }
                : { duration: 0.3 }
            }
            style={{
              background: isEpic
                ? 'linear-gradient(135deg, #dc2626 0%, #fbbf24 50%, #dc2626 100%)'
                : isHighlight
                ? 'linear-gradient(135deg, #b45309 0%, #fcd34d 50%, #b45309 100%)'
                : 'linear-gradient(135deg, #475569 0%, #94a3b8 50%, #475569 100%)',
              color: isEpic ? '#ffffff' : '#0a0e1f',
              border: `2px solid ${meta.color}`,
            }}
          >
            <Icon size={16} fill="currentColor" />
            <span className="fl-text-shadow-gold">{meta.label}</span>
            <Icon size={16} fill="currentColor" />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ============================================================
//  CARD COUNTER — top-left indicator
// ============================================================
function CardCounter({ index, total }: { index: number; total: number }) {
  return (
    <div className="absolute top-6 left-6 z-30 fl-glass rounded-lg px-3 py-2">
      <div className="text-[9px] uppercase tracking-[0.25em] text-muted-foreground">Card</div>
      <div className="font-black text-lg fl-text-neon leading-tight">
        {index + 1} <span className="text-muted-foreground text-sm font-bold">/</span> {total}
      </div>
    </div>
  );
}

// ============================================================
//  CARD BACK — what's shown before the flip
// ============================================================
function CardBack({ tier, shaking }: { tier: CardTier; shaking?: boolean }) {
  const meta = TIER_META[tier];
  const isEpic = tier === 'epic';
  const isHighlight = tier === 'highlight';
  const accentColor = isEpic ? '#fbbf24' : isHighlight ? '#fcd34d' : '#b3ff3a';

  return (
    <motion.div
      className="absolute inset-0 rounded-xl flex items-center justify-center overflow-hidden"
      animate={
        shaking
          ? { x: [0, -5, 5, -5, 5, -3, 3, 0], rotate: [0, -1.5, 1.5, -1.5, 1.5, -1, 1, 0] }
          : {}
      }
      transition={shaking ? { duration: 0.5, repeat: Infinity, ease: 'easeInOut' } : {}}
      style={{
        background: isEpic
          ? 'radial-gradient(circle at center, #1a0033 0%, #0a0a14 60%, #000 100%)'
          : 'linear-gradient(135deg, #1a1f35 0%, #0a0e1f 70%, #050810 100%)',
        border: `2px solid ${accentColor}`,
        boxShadow: `0 0 60px ${meta.glow}, inset 0 0 40px rgba(0,0,0,0.6)`,
      }}
    >
      {/* Decorative grid */}
      <div
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage: `linear-gradient(${accentColor}22 1px, transparent 1px), linear-gradient(90deg, ${accentColor}22 1px, transparent 1px)`,
          backgroundSize: '24px 24px',
        }}
      />
      {/* Shimmer for highlight/epic */}
      {(isHighlight || isEpic) && <div className="absolute inset-0 fl-shimmer opacity-40" />}

      <div className="relative text-center px-6">
        <div
          className="text-6xl mb-4 fl-spin-slow"
          style={{ filter: `drop-shadow(0 0 14px ${meta.glow})` }}
        >
          ⚽
        </div>
        <div
          className="font-black text-2xl tracking-[0.4em]"
          style={{ color: accentColor, textShadow: `0 0 12px ${meta.glow}` }}
        >
          FL
        </div>
        <div className="text-[10px] text-muted-foreground mt-1 tracking-[0.45em] uppercase">
          Dream XI
        </div>
        <div
          className="mt-6 inline-block px-3 py-1 rounded-full text-[10px] font-black tracking-[0.3em] uppercase"
          style={{
            background: 'rgba(0,0,0,0.6)',
            border: `1px solid ${accentColor}`,
            color: accentColor,
          }}
        >
          {meta.label}
        </div>
      </div>
    </motion.div>
  );
}

// ============================================================
//  SKIP BUTTON — visible during the flip animation
// ============================================================
function SkipButton({ onSkip }: { onSkip: () => void }) {
  return (
    <motion.button
      onClick={onSkip}
      aria-label="Skip animation"
      className="absolute bottom-8 right-8 z-40 flex items-center gap-2 px-5 py-3 rounded-lg font-bold text-sm fl-glass border border-white/20 hover:border-white/50 transition-all hover:scale-105"
      initial={{ y: 30, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 30, opacity: 0 }}
      transition={{ duration: 0.25 }}
    >
      <SkipForward size={16} className="fl-text-neon" />
      <span className="hidden sm:inline">Skip Animation</span>
      <span className="sm:hidden">Skip</span>
    </motion.button>
  );
}

// ============================================================
//  BOTTOM ACTION BAR — player info + Next/Done/Add buttons
// ============================================================
function BottomBar({
  card,
  isLast,
  onNext,
  onAddToSquad,
  tier,
}: {
  card: { player: Player; version: PlayerVersion; tier: CardTier };
  isLast: boolean;
  onNext: () => void;
  onAddToSquad?: () => void;
  tier: CardTier;
}) {
  const meta = TIER_META[tier];
  const handleAdd = () => {
    onAddToSquad?.();
    onNext();
  };

  return (
    <motion.div
      className="absolute bottom-6 left-0 right-0 flex flex-col items-center gap-3 z-30 px-4"
      initial={{ y: 50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.25, type: 'spring', stiffness: 200, damping: 18 }}
    >
      {/* Player info */}
      <div className="text-center max-w-full">
        <div
          className="text-2xl sm:text-3xl md:text-4xl font-black fl-text-shadow-gold mb-1 truncate"
          style={{ color: meta.color }}
        >
          {card.player.name}
        </div>
        <div className="flex items-center justify-center gap-2 text-xs sm:text-sm uppercase tracking-wide text-muted-foreground flex-wrap">
          <span className="text-base">{flagEmoji(card.player.countryCode)}</span>
          <span className="font-bold text-foreground/80">{card.player.position}</span>
          <span className="opacity-40">•</span>
          <span>
            OVR <span className="font-black" style={{ color: meta.color }}>{card.version.ovr}</span>
          </span>
          <span className="opacity-40">•</span>
          <span className="truncate max-w-[200px]">{card.version.versionName}</span>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex items-center gap-3 flex-wrap justify-center">
        {onAddToSquad && (
          <button
            onClick={handleAdd}
            className="px-4 sm:px-5 py-2.5 rounded-lg font-bold text-sm transition-all hover:scale-105 fl-glass border border-fl-neon text-fl-neon hover:bg-fl-neon/10 flex items-center gap-2"
          >
            <Flame size={16} />
            <span className="hidden sm:inline">Add to Squad</span>
            <span className="sm:hidden">Squad</span>
          </button>
        )}
        <button
          onClick={onNext}
          className="px-6 sm:px-7 py-2.5 rounded-lg font-black text-sm transition-all hover:scale-105 flex items-center gap-2"
          style={{
            background: 'linear-gradient(135deg, #b3ff3a 0%, #7fb800 100%)',
            color: '#0a0e1f',
            boxShadow: '0 0 24px rgba(179, 255, 58, 0.5)',
          }}
        >
          {isLast ? 'Done' : 'Next Card'}
          <ChevronRight size={16} />
        </button>
      </div>
    </motion.div>
  );
}

// ============================================================
//  CARD REVEAL STAGE — orchestrates a single card's reveal
// ============================================================
function CardRevealStage({
  card,
  index,
  total,
  onNext,
  onAddToSquad,
  isLast,
}: {
  card: { player: Player; version: PlayerVersion; tier: CardTier };
  index: number;
  total: number;
  onNext: () => void;
  onAddToSquad?: (cardId: string) => void;
  isLast: boolean;
}) {
  const tier = card.tier;
  const meta = TIER_META[tier];
  const isEpic = tier === 'epic';
  const isHighlight = tier === 'highlight';
  const timing = TIER_TIMING[tier];

  const [revealed, setRevealed] = useState(false); // Card has started flipping
  const [flipped, setFlipped] = useState(false); // Flip animation has completed
  const [skipped, setSkipped] = useState(false);

  useEffect(() => {
    // State resets are handled by the parent's `key={index}` remount.
    // This effect only schedules the timed flip transitions.
    const flipStart = setTimeout(() => setRevealed(true), timing.preDelay);
    const flipEnd = setTimeout(
      () => setFlipped(true),
      timing.preDelay + timing.flipDuration
    );

    return () => {
      clearTimeout(flipStart);
      clearTimeout(flipEnd);
    };
  }, [timing.preDelay, timing.flipDuration]);

  const handleSkip = () => {
    setSkipped(true);
    setRevealed(true);
    setFlipped(true);
  };

  const cardId = `${card.player.id}__${card.version.id}`;

  // Screen shake for epic — memoized so it only triggers once per reveal
  const shakeAnim = useMemo(
    () =>
      isEpic && revealed
        ? { x: [0, -14, 12, -9, 6, -3, 0], y: [0, 5, -7, 4, -3, 1, 0] }
        : { x: 0, y: 0 },
    [isEpic, revealed]
  );
  const shakeTransition = useMemo(
    () =>
      isEpic && revealed
        ? { duration: 0.6, times: [0, 0.15, 0.3, 0.45, 0.6, 0.8, 1], ease: 'easeOut' as const }
        : { duration: 0.2 },
    [isEpic, revealed]
  );

  // Flip animation transition
  const flipTransition = skipped
    ? { duration: 0 }
    : {
        duration: timing.flipDuration / 1000,
        type: 'spring' as const,
        stiffness: 60,
        damping: 14,
        delay: timing.preDelay / 1000,
      };

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-hidden"
      animate={shakeAnim}
      transition={shakeTransition}
    >
      <TierBackground tier={tier} revealed={revealed} />

      {/* Tier-specific effects that appear on reveal */}
      {isEpic && revealed && <StadiumLights />}
      {isHighlight && revealed && <GoldLightRays />}
      {isEpic && revealed && <EnergyBorder />}
      {revealed && <ParticleBurst tier={tier} />}

      {/* Epic screen flash on reveal */}
      <AnimatePresence>
        {isEpic && revealed && !skipped && (
          <motion.div
            key="flash"
            className="absolute inset-0 pointer-events-none z-20"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.85, 0] }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            style={{
              background:
                'radial-gradient(circle at center, rgba(251,191,36,0.7) 0%, rgba(220,38,38,0.3) 40%, transparent 75%)',
            }}
          />
        )}
      </AnimatePresence>

      {/* Header chrome */}
      <CardCounter index={index} total={total} />
      <TierBanner tier={tier} visible={revealed} />

      {/* Close (X) button — always available */}
      <button
        onClick={onNext}
        aria-label="Skip to next"
        className="absolute top-6 right-6 z-40 w-10 h-10 rounded-lg fl-glass border border-white/20 hover:border-white/50 flex items-center justify-center transition-all hover:scale-105 text-muted-foreground hover:text-foreground"
      >
        <X size={18} />
      </button>

      {/* The card with 3D flip */}
      <motion.div
        className="relative z-20"
        style={{ perspective: 1400, width: 280, height: 392 }}
        initial={{ scale: 0.85 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.4, ease: 'easeOut' }}
      >
        <motion.div
          className="absolute inset-0"
          style={{ transformStyle: 'preserve-3d' }}
          initial={{ rotateY: 180, scale: 0.5, opacity: 0 }}
          animate={
            revealed
              ? { rotateY: 0, scale: 1, opacity: 1 }
              : { rotateY: 180, scale: 0.5, opacity: 0 }
          }
          transition={flipTransition}
        >
          {/* Card back — visible while rotating, hidden after flip */}
          <div
            className="absolute inset-0"
            style={{
              backfaceVisibility: 'hidden',
              WebkitBackfaceVisibility: 'hidden',
              transform: 'rotateY(180deg)',
            }}
          >
            <CardBack tier={tier} shaking={isEpic && !revealed} />
          </div>
          {/* Card front — visible after flip */}
          <div
            className="absolute inset-0"
            style={{
              backfaceVisibility: 'hidden',
              WebkitBackfaceVisibility: 'hidden',
            }}
          >
            <PlayerCard player={card.player} version={card.version} size="xl" />
          </div>
        </motion.div>
      </motion.div>

      {/* Bottom chrome — Skip during animation, action bar after */}
      <AnimatePresence mode="wait">
        {!flipped ? (
          <SkipButton key="skip" onSkip={handleSkip} />
        ) : (
          <BottomBar
            key="actions"
            card={card}
            isLast={isLast}
            onNext={onNext}
            onAddToSquad={onAddToSquad ? () => onAddToSquad(cardId) : undefined}
            tier={tier}
          />
        )}
      </AnimatePresence>

      {/* Always-visible Skip button in top-right during reveal phase */}
      {!flipped && (
        <button
          onClick={handleSkip}
          className="absolute top-6 right-6 z-50 flex items-center gap-1.5 px-3 py-2 rounded-lg fl-glass border border-fl-neon/50 text-fl-neon text-xs font-bold hover:scale-105 transition-transform"
        >
          <SkipForward size={14} />
          Skip
        </button>
      )}
    </motion.div>
  );
}

// ============================================================
//  COMPLETION SCREEN — shown after all cards revealed
// ============================================================
function TierStat({
  icon: Icon,
  label,
  count,
  color,
}: {
  icon: typeof Sparkles;
  label: string;
  count: number;
  color: string;
}) {
  return (
    <div
      className="flex items-center gap-2 px-4 py-2 rounded-lg fl-glass"
      style={{ border: `1px solid ${color}40` }}
    >
      <Icon size={16} style={{ color }} fill="currentColor" />
      <span className="font-black text-lg" style={{ color }}>
        {count}
      </span>
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
    </div>
  );
}

function CompletionScreen({
  cards,
  onClose,
}: {
  cards: { player: Player; version: PlayerVersion; tier: CardTier }[];
  onClose: () => void;
}) {
  const tierCounts = useMemo(
    () => ({
      epic: cards.filter((c) => c.tier === 'epic').length,
      highlight: cards.filter((c) => c.tier === 'highlight').length,
      standard: cards.filter((c) => c.tier === 'standard').length,
    }),
    [cards]
  );

  // Confetti specs (computed once)
  const confetti = useMemo(
    () =>
      Array.from({ length: 40 }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        color: ['#b3ff3a', '#fbbf24', '#dc2626', '#60a5fa', '#fcd34d'][i % 5],
        delay: Math.random() * 2.5,
        duration: 3 + Math.random() * 2,
        size: 6 + Math.random() * 6,
        drift: (Math.random() - 0.5) * 120,
      })),
    []
  );

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md overflow-auto py-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      {/* Background glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(circle at center, rgba(179,255,58,0.18) 0%, rgba(251,191,36,0.08) 35%, transparent 70%)',
        }}
      />

      {/* Confetti */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {confetti.map((c) => (
          <motion.div
            key={c.id}
            className="absolute"
            style={{
              left: `${c.left}%`,
              top: '-20px',
              width: c.size,
              height: c.size * 1.5,
              background: c.color,
              borderRadius: '2px',
            }}
            initial={{ y: -20, opacity: 0, rotate: 0, x: 0 }}
            animate={{
              y: '110vh',
              opacity: [0, 1, 1, 0],
              rotate: 720,
              x: c.drift,
            }}
            transition={{
              duration: c.duration,
              delay: c.delay,
              repeat: Infinity,
              repeatDelay: Math.random() * 2,
              ease: 'linear',
            }}
          />
        ))}
      </div>

      <button
        onClick={onClose}
        aria-label="Close"
        className="absolute top-6 right-6 z-40 w-10 h-10 rounded-lg fl-glass border border-white/20 hover:border-white/50 flex items-center justify-center transition-all hover:scale-105 text-muted-foreground hover:text-foreground"
      >
        <X size={18} />
      </button>

      <div className="relative max-w-4xl w-full px-6">
        {/* Header */}
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 200, damping: 15 }}
          className="text-center mb-6"
        >
          <motion.div
            className="text-7xl mb-4"
            animate={{ rotate: [0, -10, 10, -10, 0], scale: [1, 1.1, 1] }}
            transition={{ duration: 1.2, repeat: Infinity, repeatDelay: 1.5 }}
          >
            🎉
          </motion.div>
          <h2 className="text-4xl md:text-5xl font-black fl-text-neon mb-2 fl-text-shadow-neon">
            Pack Complete!
          </h2>
          <p className="text-muted-foreground">
            You revealed{' '}
            <span className="fl-text-neon font-bold">{cards.length}</span> new{' '}
            {cards.length === 1 ? 'card' : 'cards'}
          </p>
        </motion.div>

        {/* Tier summary */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="flex justify-center gap-2 sm:gap-3 mb-6 flex-wrap"
        >
          {tierCounts.epic > 0 && (
            <TierStat icon={Crown} label="Epic" count={tierCounts.epic} color={TIER_META.epic.color} />
          )}
          {tierCounts.highlight > 0 && (
            <TierStat
              icon={Star}
              label="Highlight"
              count={tierCounts.highlight}
              color={TIER_META.highlight.color}
            />
          )}
          {tierCounts.standard > 0 && (
            <TierStat
              icon={Sparkles}
              label="Standard"
              count={tierCounts.standard}
              color={TIER_META.standard.color}
            />
          )}
        </motion.div>

        {/* Card grid */}
        {cards.length > 0 && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="flex flex-wrap justify-center gap-3 mb-8 max-h-[38vh] overflow-y-auto fl-scroll p-2"
          >
            {cards.map((c, i) => {
              const tm = TIER_META[c.tier];
              return (
                <motion.div
                  key={`${c.player.id}-${c.version.id}-${i}`}
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{
                    delay: 0.4 + i * 0.05,
                    type: 'spring',
                    stiffness: 200,
                    damping: 18,
                  }}
                  className="relative"
                >
                  <PlayerCard player={c.player} version={c.version} size="sm" />
                  <div
                    className="absolute -top-1.5 -right-1.5 px-1.5 py-0.5 rounded text-[8px] font-black tracking-wider uppercase z-10"
                    style={{
                      background: tm.color,
                      color: '#0a0e1f',
                      boxShadow: `0 0 8px ${tm.glow}`,
                    }}
                  >
                    {tm.label}
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        )}

        {/* Primary CTA */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="flex justify-center"
        >
          <button
            onClick={onClose}
            className="px-8 py-3.5 rounded-lg font-black text-base transition-all hover:scale-105 flex items-center gap-2"
            style={{
              background: 'linear-gradient(135deg, #b3ff3a 0%, #7fb800 100%)',
              color: '#0a0e1f',
              boxShadow: '0 0 28px rgba(179, 255, 58, 0.55)',
            }}
          >
            View in My Club
            <ChevronRight size={18} />
          </button>
        </motion.div>
      </div>
    </motion.div>
  );
}

// ============================================================
//  PACK REVEAL — top-level component
// ============================================================
export function PackReveal({ cards, onClose, onAddToSquad }: PackRevealProps) {
  const [index, setIndex] = useState(0);

  // After all cards revealed, show completion screen
  if (index >= cards.length) {
    return <CompletionScreen cards={cards} onClose={onClose} />;
  }

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={index}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.25 }}
      >
        <CardRevealStage
          card={cards[index]}
          index={index}
          total={cards.length}
          isLast={index === cards.length - 1}
          onNext={() => setIndex((i) => i + 1)}
          onAddToSquad={onAddToSquad}
        />
      </motion.div>
    </AnimatePresence>
  );
}
