'use client';

import { Player, PlayerVersion, Rarity } from '@/lib/types';
import { RARITY_META, flagEmoji, positionGroup } from '@/lib/players';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface PlayerCardProps {
  player: Player;
  version: PlayerVersion;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  onClick?: () => void;
  className?: string;
  count?: number;
  isNew?: boolean;
  selected?: boolean;
  compact?: boolean;
}

const SIZES = {
  xs: { w: 80, h: 112, ovr: 18, name: 8, stat: 8, title: 6 },
  sm: { w: 110, h: 154, ovr: 22, name: 10, stat: 9, title: 7 },
  md: { w: 150, h: 210, ovr: 28, name: 12, stat: 10, title: 8 },
  lg: { w: 200, h: 280, ovr: 36, name: 14, stat: 11, title: 10 },
  xl: { w: 280, h: 392, ovr: 48, name: 18, stat: 14, title: 13 },
};

/** Generate a player "portrait" SVG data URI with initials, gradient & flag */
function portraitSvg(player: Player, version: PlayerVersion, rarity: Rarity, w: number, h: number): string {
  const meta = RARITY_META[rarity];
  const initials = player.name
    .split(/\s+/)
    .map((s) => s[0])
    .filter((c) => c && /[A-Z]/.test(c))
    .slice(0, 2)
    .join('');
  const flag = flagEmoji(player.countryCode);
  const pos = player.position;
  const isGk = pos === 'GK';

  // Position-based accent color
  const posColor =
    isGk ? '#fbbf24' :
    ['CB', 'LB', 'RB', 'LWB', 'RWB'].includes(pos) ? '#60a5fa' :
    ['CDM', 'CM', 'CAM', 'LM', 'RM'].includes(pos) ? '#b3ff3a' :
    '#fb7185';

  // SVG template
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">
  <defs>
    <linearGradient id="bg${player.id}${version.id}" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${posColor}" stop-opacity="0.45"/>
      <stop offset="50%" stop-color="${posColor}" stop-opacity="0.15"/>
      <stop offset="100%" stop-color="#000000" stop-opacity="0.7"/>
    </linearGradient>
    <radialGradient id="glow${player.id}${version.id}" cx="50%" cy="40%" r="60%">
      <stop offset="0%" stop-color="${meta.border}" stop-opacity="0.4"/>
      <stop offset="100%" stop-color="${meta.border}" stop-opacity="0"/>
    </radialGradient>
    <pattern id="dots${player.id}${version.id}" x="0" y="0" width="14" height="14" patternUnits="userSpaceOnUse">
      <circle cx="2" cy="2" r="1" fill="white" opacity="0.05"/>
    </pattern>
  </defs>
  <rect width="${w}" height="${h}" fill="url(#bg${player.id}${version.id})"/>
  <rect width="${w}" height="${h}" fill="url(#dots${player.id}${version.id})"/>
  <rect width="${w}" height="${h}" fill="url(#glow${player.id}${version.id})"/>
  <g opacity="0.9">
    <ellipse cx="${w / 2}" cy="${h * 0.32}" rx="${w * 0.18}" ry="${h * 0.10}" fill="rgba(0,0,0,0.55)"/>
    <path d="M ${w * 0.30} ${h * 0.95} Q ${w * 0.5} ${h * 0.45} ${w * 0.70} ${h * 0.95} Z" fill="rgba(0,0,0,0.55)"/>
    <ellipse cx="${w / 2}" cy="${h * 0.28}" rx="${w * 0.13}" ry="${h * 0.08}" fill="rgba(0,0,0,0.6)"/>
  </g>
  <text x="${w / 2}" y="${h * 0.55}" font-family="Inter, Arial, sans-serif" font-size="${Math.floor(w * 0.32)}" font-weight="900"
    fill="white" fill-opacity="0.92" text-anchor="middle" stroke="rgba(0,0,0,0.4)" stroke-width="1">${initials}</text>
  <text x="${w - 14}" y="22" font-size="${Math.floor(w * 0.13)}" text-anchor="end">${flag}</text>
  <rect x="8" y="${h - 26}" width="32" height="20" rx="4" fill="rgba(0,0,0,0.7)" stroke="${posColor}" stroke-width="1"/>
  <text x="24" y="${h - 12}" font-family="Inter, Arial, sans-serif" font-size="11" font-weight="700" fill="white" text-anchor="middle">${pos}</text>
</svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export function PlayerCard({
  player,
  version,
  size = 'md',
  onClick,
  className,
  count,
  isNew,
  selected,
  compact,
}: PlayerCardProps) {
  const meta = RARITY_META[version.rarity];
  const dims = SIZES[size];
  const portrait = portraitSvg(player, version, version.rarity, dims.w, Math.floor(dims.h * 0.62));

  const rarityClass = {
    common: '',
    rare: '',
    epic: 'fl-glow-pulse',
    legendary: 'fl-gold-shine',
    icon: 'fl-icon-pulse',
    'ultimate-icon': 'fl-icon-pulse',
    highlight: 'fl-gold-shine',
    mythic: 'fl-icon-pulse',
  }[version.rarity];

  const stat = (label: string, value: number) => (
    <div className="flex items-center justify-between" style={{ fontSize: dims.stat }}>
      <span className="opacity-70 font-semibold">{label}</span>
      <span className="font-black tabular-nums" style={{ color: meta.border }}>{value}</span>
    </div>
  );

  return (
    <motion.div
      whileHover={onClick ? { scale: 1.03, y: -2 } : undefined}
      whileTap={onClick ? { scale: 0.98 } : undefined}
      onClick={onClick}
      className={cn(
        'relative rounded-xl overflow-hidden cursor-pointer select-none',
        rarityClass,
        selected && 'ring-2 ring-fl-neon ring-offset-2 ring-offset-fl-navy',
        className
      )}
      style={{
        width: dims.w,
        height: dims.h,
        background: meta.gradient,
        boxShadow: `0 4px 16px rgba(0,0,0,0.5), 0 0 0 1.5px ${meta.border}, 0 0 18px ${meta.glow}`,
      }}
    >
      {/* Shimmer overlay for higher rarities */}
      {(version.rarity === 'legendary' || version.rarity === 'icon' || version.rarity === 'ultimate-icon' || version.rarity === 'highlight' || version.rarity === 'mythic') && (
        <div className="absolute inset-0 fl-shimmer pointer-events-none" />
      )}

      {/* Top row: OVR + position */}
      <div className="absolute top-0 left-0 right-0 flex items-start justify-between px-2 py-1.5 z-10">
        <div className="flex flex-col items-center">
          <span
            className="font-black leading-none"
            style={{ fontSize: dims.ovr, color: meta.text, textShadow: '0 1px 3px rgba(0,0,0,0.8)' }}
          >
            {version.ovr}
          </span>
          <span
            className="font-bold mt-0.5 tracking-wide"
            style={{ fontSize: dims.title, color: meta.text }}
          >
            {player.position}
          </span>
          {size === 'xs' && (
            <span style={{ fontSize: 10 }}>{flagEmoji(player.countryCode)}</span>
          )}
        </div>
        <div className="flex flex-col items-end gap-0.5">
          <span
            className="px-1.5 py-0.5 rounded font-black tracking-wider uppercase"
            style={{
              fontSize: dims.title,
              backgroundColor: 'rgba(0,0,0,0.5)',
              color: meta.border,
              border: `1px solid ${meta.border}`,
            }}
          >
            {meta.shortLabel}
          </span>
        </div>
      </div>

      {/* Portrait */}
      <div
        className="absolute left-0 right-0"
        style={{ top: dims.ovr + dims.title + 18, height: Math.floor(dims.h * 0.55) }}
      >
        <img
          src={portrait}
          alt={player.name}
          className="w-full h-full object-cover"
          style={{ maskImage: 'linear-gradient(180deg, black 75%, transparent 100%)' }}
          draggable={false}
        />
      </div>

      {/* Bottom: name + stats */}
      <div className="absolute bottom-0 left-0 right-0 px-2 pb-2 pt-1.5"
        style={{
          background: 'linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.85) 35%, rgba(0,0,0,0.95) 100%)',
        }}
      >
        <div
          className="font-bold uppercase tracking-wide truncate text-center mb-0.5"
          style={{ fontSize: dims.title, color: meta.border }}
        >
          {version.versionName}
        </div>
        <div
          className="font-black text-center truncate"
          style={{ fontSize: dims.name, color: meta.text, textShadow: '0 1px 3px rgba(0,0,0,0.9)' }}
        >
          {player.name}
        </div>

        {!compact && size !== 'xs' && (
          <>
            <div className="grid grid-cols-2 gap-x-2 gap-y-0.5 mt-1.5 px-0.5">
              {stat('PAC', version.stats.pac)}
              {stat('DRI', version.stats.dri)}
              {stat('SHO', version.stats.sho)}
              {stat('DEF', version.stats.def)}
              {stat('PAS', version.stats.pas)}
              {stat('PHY', version.stats.phy)}
            </div>
            {size !== 'sm' && (
              <div className="flex items-center justify-center gap-1.5 mt-1 opacity-80" style={{ fontSize: dims.title }}>
                <span>{flagEmoji(player.countryCode)}</span>
                <span className="truncate max-w-[80%]">{player.club}</span>
              </div>
            )}
          </>
        )}
      </div>

      {count && count > 1 && (
        <div className="absolute top-1 right-1 bg-fl-neon text-fl-navy font-black rounded-full w-6 h-6 flex items-center justify-center text-xs z-20 fl-glow-neon">
          ×{count}
        </div>
      )}

      {isNew && (
        <div className="absolute top-1 right-1 bg-fl-gold text-fl-navy font-black rounded px-1.5 py-0.5 text-[9px] tracking-wider z-20 fl-glow-gold animate-pulse">
          NEW
        </div>
      )}

      {selected && (
        <div className="absolute inset-0 bg-fl-neon/10 pointer-events-none" />
      )}
    </motion.div>
  );
}

export function PlayerCardMini({ player, version, onClick, selected }: {
  player: Player;
  version: PlayerVersion;
  onClick?: () => void;
  selected?: boolean;
}) {
  const meta = RARITY_META[version.rarity];
  return (
    <div
      onClick={onClick}
      className={cn(
        'flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-colors',
        selected ? 'bg-fl-neon/20 ring-1 ring-fl-neon' : 'hover:bg-white/5'
      )}
    >
      <div
        className="w-12 h-12 rounded-md flex items-center justify-center font-black flex-shrink-0"
        style={{ background: meta.gradient, border: `1px solid ${meta.border}`, color: meta.text }}
      >
        {version.ovr}
      </div>
      <div className="min-w-0 flex-1">
        <div className="font-bold truncate">{player.name}</div>
        <div className="text-xs text-muted-foreground truncate">
          {version.versionName} • {player.position} • {player.club}
        </div>
      </div>
      <span className="text-xl">{flagEmoji(player.countryCode)}</span>
    </div>
  );
}
