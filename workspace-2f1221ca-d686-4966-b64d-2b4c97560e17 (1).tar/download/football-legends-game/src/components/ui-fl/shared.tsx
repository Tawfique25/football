'use client';

import { useGame } from '@/lib/store';
import { Coins, Trophy, Users, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

export function StatPill({ icon, value, label, accent }: {
  icon: React.ReactNode;
  value: string | number;
  label: string;
  accent?: 'neon' | 'gold' | 'blue';
}) {
  const colorMap = {
    neon: 'text-fl-neon',
    gold: 'text-fl-gold',
    blue: 'text-blue-400',
  };
  return (
    <div className="fl-glass rounded-xl px-3 py-1.5 flex items-center gap-2">
      <div className={colorMap[accent ?? 'neon']}>{icon}</div>
      <div className="flex flex-col leading-tight">
        <span className="font-black text-sm tabular-nums">{value}</span>
        <span className="text-[9px] uppercase tracking-wider text-muted-foreground">{label}</span>
      </div>
    </div>
  );
}

export function TopBar() {
  const coins = useGame((s) => s.coins);
  const level = useGame((s) => s.level);
  const collection = useGame((s) => s.collection);
  const matchesWon = useGame((s) => s.matchesWon);

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <StatPill icon={<Coins size={16} className="fill-fl-gold" />} value={coins.toLocaleString()} label="Coins" accent="gold" />
      <StatPill icon={<Zap size={16} />} value={`Lv ${level}`} label="Level" accent="neon" />
      <StatPill icon={<Trophy size={16} />} value={matchesWon} label="Wins" accent="gold" />
      <StatPill icon={<Users size={16} />} value={collection.length} label="Cards" accent="blue" />
    </div>
  );
}

/** Animated coin reward float */
export function CoinReward({ amount, trigger }: { amount: number; trigger: number }) {
  if (!trigger) return null;
  return (
    <motion.div
      key={trigger}
      initial={{ y: 0, opacity: 1, scale: 1 }}
      animate={{ y: -50, opacity: 0, scale: 1.2 }}
      transition={{ duration: 1.2 }}
      className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[100] pointer-events-none text-fl-gold font-black text-4xl fl-text-shadow-gold"
    >
      +{amount} 🪙
    </motion.div>
  );
}

/** Section header */
export function SectionHeader({ title, subtitle, icon }: {
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
}) {
  return (
    <div className="mb-6">
      <div className="flex items-center gap-3">
        {icon && <div className="text-fl-neon">{icon}</div>}
        <h1 className="text-3xl md:text-4xl font-black tracking-tight fl-text-shadow-neon">
          {title}
        </h1>
      </div>
      {subtitle && <p className="text-muted-foreground mt-1.5 text-sm md:text-base">{subtitle}</p>}
    </div>
  );
}
