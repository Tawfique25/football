'use client';

import { useGame } from '@/lib/store';
import { useFirestoreSync } from '@/lib/firestore-sync';
import { HomeSection } from '@/components/sections/Home';
import { PackOpeningSection } from '@/components/sections/PackOpening';
import { MyClubSection } from '@/components/sections/MyClub';
import { DreamTeamSection } from '@/components/sections/DreamTeam';
import { MatchesSection } from '@/components/sections/Matches';
import { AchievementsSection } from '@/components/sections/Achievements';
import { SettingsSection } from '@/components/sections/Settings';
import { MarketSection } from '@/components/sections/Market';
import { TradeSection } from '@/components/sections/Trade';
import { AuthButton } from '@/components/sections/Auth';
import { TopBar } from '@/components/ui-fl/shared';
import { motion, AnimatePresence } from 'framer-motion';
import { useEffect, useState } from 'react';
import { Home, Package, Users, Trophy, Award, Settings as SettingsIcon, Menu, X, ShoppingBag, ArrowLeftRight } from 'lucide-react';
import { cn } from '@/lib/utils';

type Section = 'home' | 'packs' | 'club' | 'team' | 'matches' | 'market' | 'trade' | 'achievements' | 'settings';

interface NavItem {
  id: Section;
  label: string;
  icon: React.ReactNode;
}

const NAV: NavItem[] = [
  { id: 'home', label: 'Home', icon: <Home size={20} /> },
  { id: 'packs', label: 'Packs', icon: <Package size={20} /> },
  { id: 'club', label: 'My Club', icon: <Users size={20} /> },
  { id: 'team', label: 'Dream Team', icon: <Trophy size={20} /> },
  { id: 'matches', label: 'Matches', icon: <Award size={20} /> },
  { id: 'market', label: 'Market', icon: <ShoppingBag size={20} /> },
  { id: 'trade', label: 'Trade', icon: <ArrowLeftRight size={20} /> },
  { id: 'achievements', label: 'Achievements', icon: <Award size={20} /> },
  { id: 'settings', label: 'Settings', icon: <SettingsIcon size={20} /> },
];

export default function HomeApp() {
  const [section, setSection] = useState<Section>('home');
  const [payload, setPayload] = useState<any>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const _hasHydrated = useGame((s) => s._hasHydrated);
  const claimDailyLogin = useGame((s) => s.claimDailyLogin);
  const lastLoginReward = useGame((s) => s.lastLoginReward);

  // Sync game state to Firestore when user is logged in
  useFirestoreSync();

  const starterSquadClaimed = useGame((s) => s.starterSquadClaimed);
  const claimStarterSquad = useGame((s) => s.claimStarterSquad);

  // Auto-claim daily login + starter squad on first load
  useEffect(() => {
    if (!_hasHydrated) return;
    const today = new Date().toISOString().slice(0, 10);
    if (lastLoginReward !== today) {
      claimDailyLogin();
    }
    // Auto-claim starter squad if not yet claimed
    if (!starterSquadClaimed) {
      claimStarterSquad();
    }
  }, [_hasHydrated]);

  const navigate = (s: string, p?: any) => {
    setSection(s as Section);
    setPayload(p ?? null);
    setMobileMenuOpen(false);
    // Scroll to top on navigation
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Loading state while store hydrates
  if (!_hasHydrated) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
          className="text-7xl mb-6"
        >
          ⚽
        </motion.div>
        <div className="text-2xl font-black fl-text-shadow-neon mb-1">
          FOOTBALL <span className="fl-text-gold">LEGENDS</span>
        </div>
        <div className="text-sm text-muted-foreground">Loading your Dream XI...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 fl-glass-strong border-b border-white/10">
        <div className="max-w-7xl mx-auto px-3 md:px-6 py-3">
          <div className="flex items-center justify-between gap-3">
            {/* Logo */}
            <button
              onClick={() => navigate('home')}
              className="flex items-center gap-2 hover:opacity-80 transition-opacity flex-shrink-0"
            >
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 12, repeat: Infinity, ease: 'linear' }}
                className="text-2xl md:text-3xl"
              >
                ⚽
              </motion.div>
              <div className="hidden sm:block">
                <div className="font-black text-base md:text-lg leading-none fl-text-shadow-neon">
                  FOOTBALL <span className="fl-text-gold">LEGENDS</span>
                </div>
                <div className="text-[9px] uppercase tracking-widest text-muted-foreground">Dream XI</div>
              </div>
            </button>

            {/* Desktop nav */}
            <nav className="hidden lg:flex items-center gap-1">
              {NAV.map((item) => (
                <button
                  key={item.id}
                  onClick={() => navigate(item.id)}
                  className={cn(
                    'px-3 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-1.5',
                    section === item.id
                      ? 'bg-fl-neon text-fl-navy fl-glow-neon'
                      : 'text-muted-foreground hover:text-foreground hover:bg-white/5'
                  )}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              ))}
            </nav>

            {/* TopBar (coins/level) - hidden on small screens */}
            <div className="hidden md:flex">
              <TopBar />
            </div>

            {/* Auth button */}
            <AuthButton />

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg bg-black/40 hover:bg-black/60 transition-colors"
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>

          {/* Mobile nav drawer */}
          <AnimatePresence>
            {mobileMenuOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="lg:hidden overflow-hidden mt-3"
              >
                <div className="grid grid-cols-2 gap-1.5 pb-2">
                  {NAV.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => navigate(item.id)}
                      className={cn(
                        'px-3 py-2.5 rounded-lg text-sm font-bold transition-all flex items-center gap-2',
                        section === item.id
                          ? 'bg-fl-neon text-fl-navy'
                          : 'bg-black/30 text-muted-foreground hover:bg-white/5'
                      )}
                    >
                      {item.icon}
                      <span>{item.label}</span>
                    </button>
                  ))}
                </div>
                <div className="md:hidden pb-2">
                  <TopBar />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </header>

      {/* Mobile top bar (always visible on small screens) */}
      <div className="md:hidden fl-glass border-b border-white/10 px-3 py-2">
        <TopBar />
      </div>

      {/* Main content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 md:px-6 py-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={section}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25 }}
          >
            {section === 'home' && <HomeSection onNavigate={navigate} />}
            {section === 'packs' && (
              <PackOpeningSection
                initialPackId={payload?.openPack}
                openDailyOnMount={payload?.openDaily}
                onConsumed={() => setPayload(null)}
              />
            )}
            {section === 'club' && <MyClubSection />}
            {section === 'team' && <DreamTeamSection />}
            {section === 'matches' && <MatchesSection />}
            {section === 'market' && <MarketSection />}
            {section === 'trade' && <TradeSection />}
            {section === 'achievements' && <AchievementsSection />}
            {section === 'settings' && <SettingsSection />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="mt-auto fl-glass border-t border-white/10 py-4">
        <div className="max-w-7xl mx-auto px-3 md:px-6 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
          <div className="flex items-center gap-2">
            <span className="font-black fl-text-neon">FOOTBALL LEGENDS</span>
            <span className="opacity-50">•</span>
            <span>Dream XI</span>
          </div>
          <div className="text-center sm:text-right">
            All ratings are game ratings for entertainment. No real-money gambling.
          </div>
        </div>
      </footer>

      {/* Mobile bottom nav (scrollable for more items) */}
      <nav className="lg:hidden sticky bottom-0 fl-glass-strong border-t border-white/10 px-1 py-1.5 z-30">
        <div className="flex gap-0.5 max-w-md mx-auto overflow-x-auto no-scrollbar">
          {NAV.map((item) => (
            <button
              key={item.id}
              onClick={() => navigate(item.id)}
              className={cn(
                'flex-shrink-0 py-1.5 px-2.5 rounded-lg text-[10px] font-bold transition-colors flex flex-col items-center gap-0.5',
                section === item.id
                  ? 'text-fl-neon bg-fl-neon/10'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              {item.icon}
              <span className="text-[8px] leading-none">{item.label.split(' ')[0]}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
