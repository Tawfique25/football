import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Use 'standalone' for Node.js deployment, 'export' for static hosting (Firebase/Netlify/Vercel static)
  // To deploy to Firebase Hosting, change to: output: 'export'
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Uncomment these when deploying to Firebase Hosting (static export):
  // images: { unoptimized: true },
};

export default nextConfig;
