# ⚽ FOOTBALL LEGENDS: DREAM XI

A complete, modern, interactive football player card collecting and team-building game inspired by eFootball Mobile and EA FC Ultimate Team.

## 🎮 Features

- **145+ real players** (current stars + legends) with multiple card versions
- **5 Box-Draw Packs** (150 players each): Ballon d'Or, World Champions, Goal Machine, Defensive Monsters, Ultimate Playmakers
- **3 Card Tiers**: Standard, Highlight (gold), Epic (cinematic reveal with 106-108 OVR)
- **Starter Squad**: Every new player gets 16 players + 10,000 coins
- **Dream Team Builder**: 6 preset formations + custom formation creator
- **9 AI Difficulty Tiers**: From Sunday League Amateurs to All-Time Legends XI
- **Transfer Market**: Buy/sell cards with coins
- **Trade Post**: Trade cards with NPC merchants
- **Match Simulation**: Full match engine with events, stats, rewards
- **Firebase Auth + Cloud Save**: Login system with cross-device sync
- **Premium UI**: Dark navy theme, neon green/gold accents, glassmorphism, animations

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```
*Or with bun: `bun install`*

### 2. Run Locally
```bash
npm run dev
```
Open http://localhost:3000

### 3. Build for Production
```bash
npm run build
```

## 🔥 Firebase Setup (for Login + Cloud Save)

Your Firebase config is already in `src/lib/firebase.ts`:
```
Project: football-legends-2551d
```

### Enable Login:
1. Go to [Firebase Console](https://console.firebase.google.com/) → your project
2. **Authentication** → **Sign-in method** → Enable **Email/Password**
3. **Firestore Database** → **Create database** (production mode)
4. **Authentication** → **Settings** → **Authorized domains** → Add your domain

### Set Database Rules:
Go to **Firestore Database** → **Rules** tab → paste:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read: if request.auth != null && request.auth.uid == userId;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    match /gameStates/{userId} {
      allow read: if request.auth != null && request.auth.uid == userId;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

See **FIREBASE_DEPLOYMENT_GUIDE.md** for full instructions.

## 📦 Deploy to Vercel (Easiest)

1. Go to [vercel.com](https://vercel.com) → Sign in
2. **Add New Project** → Import from GitHub or drag-and-drop
3. Click **Deploy**
4. Your game is live at `https://your-app.vercel.app`
5. Add this URL to Firebase → Authentication → Authorized domains

## 📦 Deploy to Firebase Hosting

```bash
npm install -g firebase-tools
firebase login
firebase init hosting
# Public directory: out
# Single-page app: Yes

# Update next.config.ts: change output to 'export'
npm run build
firebase deploy --only hosting
```

Your game is live at `https://football-legends-2551d.web.app`

## 📁 Project Structure

```
src/
├── app/
│   ├── layout.tsx          # Root layout (AuthProvider)
│   ├── page.tsx            # Main page with navigation
│   └── globals.css         # Premium theme + animations
├── lib/
│   ├── firebase.ts         # Your Firebase config ✅
│   ├── auth-context.tsx    # Login/signup system
│   ├── firestore-sync.ts   # Cloud save sync
│   ├── players.ts          # 145 players + 230 card versions
│   ├── box-packs.ts        # 5 box-draw packs (150 players each)
│   ├── store.ts            # Game state (Zustand + localStorage)
│   ├── formations.ts       # 6 formations + custom builder
│   ├── match-sim.ts        # 9 AI teams + match engine
│   ├── packs.ts            # Legacy pack system
│   ├── achievements.ts     # 17 achievements
│   └── types.ts            # TypeScript types
├── components/
│   ├── cards/
│   │   ├── PlayerCard.tsx      # Card component (8 rarities)
│   │   └── PackReveal.tsx      # Tier-based reveal animations
│   ├── sections/
│   │   ├── Home.tsx            # Dashboard
│   │   ├── PackOpening.tsx     # Box-draw pack system
│   │   ├── MyClub.tsx          # Card collection
│   │   ├── DreamTeam.tsx       # Squad builder + formations
│   │   ├── FormationBuilderModal.tsx  # Custom formation creator
│   │   ├── Matches.tsx         # 9 AI difficulties
│   │   ├── Market.tsx          # Buy/sell cards
│   │   ├── Trade.tsx           # Trade with merchants
│   │   ├── Achievements.tsx    # 17 achievements
│   │   ├── Settings.tsx        # Game settings
│   │   └── Auth.tsx            # Login/signup modal
│   └── ui-fl/
│       └── shared.tsx          # Shared UI components
└── components/ui/              # shadcn/ui components
```

## 🎯 Card Tiers

| Tier | OVR Range | Rarity | Reveal Animation |
|------|-----------|--------|------------------|
| Standard | 70-99 | Common → Ultimate Icon | Simple flip |
| Highlight | 90-105 | Highlight (gold) | Gold glow + particles |
| Epic | 106-108 | Mythic (red/gold) | Cinematic + stadium lights |

## 🏆 Box-Draw Packs

Each pack has **150 unique players** (no duplicates in same box):
- **3 Epic** (107/106/106 or 108/107/107)
- **7 Highlight** (90-99 OVR)
- **140 Standard** (70-92 OVR)

### Pack Details:
1. **Ballon d'Or Pack** — Kane 108, Yamal 107, Mbappé 107
2. **World Champions Pack** — Messi 107, Maradona 106, Zidane 106
3. **Goal Machine Pack** — Haaland 107, Mbappé 106, CR7 106
4. **Defensive Monsters Pack** — Maldini 107, Beckenbauer 106, Yashin 106
5. **Ultimate Playmakers Pack** — Iniesta 107, Xavi 106, Pirlo 106

## 💰 Coin System

- **Starting coins**: 10,000
- **1 spin**: 100 coins
- **10 spins**: 1,000 coins
- **Daily login rewards**: 200-2000 coins (7-day streak)
- **Match rewards**: 100-800 coins (varies by difficulty)
- **Sell cards**: 25% of market value
- **Trade cards**: Exchange with NPC merchants

## ⚽ AI Difficulties

| Team | OVR | Tier |
|------|-----|------|
| Sunday League Amateurs | 71 | 🌱 Amateur |
| Youth Academy | 78 | 🌱 Amateur |
| Local Rivals FC | 73 | ⚽ Pro |
| Rising Stars | 83 | ⚽ Pro |
| Continental Stars | 87 | ⭐ Elite |
| Champions League XI | 89 | ⭐ Elite |
| Galácticos United | 94 | 👑 Legend |
| World XI | 92 | 👑 Legend |
| All-Time Legends XI | 97 | 🏆 Ultimate |

## 🛠️ Tech Stack

- **Framework**: Next.js 16 (App Router)
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4 + shadcn/ui
- **State**: Zustand (localStorage persistence)
- **Database**: Firebase Firestore (cloud sync)
- **Auth**: Firebase Authentication
- **Animations**: Framer Motion
- **Icons**: Lucide React

## 📝 Notes

- All player ratings are **game ratings** for entertainment — not official FIFA/EA ratings
- Player names are used to celebrate football history
- No real-money gambling — all currency is in-game only
- Game works offline (localStorage) — Firebase is optional for cross-device sync

## 🆘 Need Help?

- Check **FIREBASE_DEPLOYMENT_GUIDE.md** for detailed deployment steps
- Check the in-game **Settings** page for stats and reset option
- All progress saves automatically

---

**Enjoy building your Dream XI!** ⚽🏆
