// Quick script to check AI team ratings without chemistry boost
import { AI_TEAMS_DEF, getAITeamRating, resolveAISquad } from '../src/lib/match-sim';
import { PLAYERS, getVersion } from '../src/lib/players';
import { calculateTeamRating, getFormation, effectiveRating } from '../src/lib/formations';

const lookup = (pid: string, vid: string) => {
  const player = PLAYERS.find((p) => p.id === pid);
  const version = getVersion(pid, vid);
  if (!player || !version) return undefined;
  return { player, version };
};

console.log('=== AI TEAM RATINGS ===');
for (const team of AI_TEAMS_DEF) {
  const squad = resolveAISquad(team, lookup);
  const formation = getFormation(team.formationId);
  let sum = 0;
  let n = 0;
  const ratings = [];
  for (let i = 0; i < squad.length; i++) {
    const entry = squad[i];
    if (!entry) continue;
    const slotPos = formation.slots[i].position;
    const eff = effectiveRating(entry.version, slotPos, entry.player);
    sum += eff;
    n++;
    ratings.push(`${entry.player.name}(${entry.version.ovr}→${eff})`);
  }
  const avg = Math.round(sum / n);
  const teamRating = calculateTeamRating(team.formationId, squad);
  console.log(`${team.name} (${team.tier}):`);
  console.log(`  Raw avg: ${avg}, Team rating (with chem): ${teamRating.overall}, Chem: ${teamRating.chemistry}%`);
  console.log(`  ATT:${teamRating.attack} MID:${teamRating.midfield} DEF:${teamRating.defense}`);
  console.log(`  Players: ${ratings.join(', ')}`);
  console.log();
}
