# 🔥 Firebase Deployment Guide — FOOTBALL LEGENDS: DREAM XI

This guide walks you through deploying your game to Firebase Hosting with Firebase Authentication and Firestore for cloud save sync.

---

## Table of Contents
1. [Prerequisites](#1-prerequisites)
2. [Create a Firebase Project](#2-create-a-firebase-project)
3. [Enable Authentication](#3-enable-authentication)
4. [Create Firestore Database](#4-create-firestore-database)
5. [Get Your Firebase Config](#5-get-your-firebase-config)
6. [Update the Game's Firebase Config](#6-update-the-games-firebase-config)
7. [Set Up Firestore Security Rules](#7-set-up-firestore-security-rules)
8. [Install Firebase CLI](#8-install-firebase-cli)
9. [Configure Firebase Hosting](#9-configure-firebase-hosting)
10. [Build and Deploy](#10-build-and-deploy)
11. [Verify Your Deployment](#11-verify-your-deployment)
12. [Troubleshooting](#12-troubleshooting)

---

## 1. Prerequisites

Before you start, make sure you have:

- ✅ A Google account
- ✅ Node.js 18+ installed (`node --version`)
- ✅ The game code on your machine
- ✅ A code editor (VS Code recommended)

---

## 2. Create a Firebase Project

1. Go to **[Firebase Console](https://console.firebase.google.com/)**
2. Click **"Add project"** (or "Create a project")
3. Enter a project name, e.g., `football-legends-dream-xi`
4. Choose whether to enable Google Analytics (optional — you can disable it)
5. Click **"Create project"**
6. Wait for Firebase to provision your project, then click **"Continue"**

---

## 3. Enable Authentication

1. In the Firebase Console, click **"Authentication"** in the left sidebar
2. Click **"Get Started"**
3. Go to the **"Sign-in method"** tab
4. Click on **"Email/Password"**
5. Toggle **"Enable"** for Email/Password
6. Click **"Save"**

> 💡 **Optional:** You can also enable Google sign-in for a one-click login experience.

---

## 4. Create Firestore Database

1. In the Firebase Console, click **"Firestore Database"** in the left sidebar
2. Click **"Create database"**
3. Choose **"Start in production mode"** (we'll add security rules below)
4. Select a location close to your users (e.g., `us-central1` for North America, `europe-west1` for Europe)
5. Click **"Create"**
6. Wait for Firestore to provision your database

---

## 5. Get Your Firebase Config

1. In the Firebase Console, click the **gear icon** ⚙️ next to "Project Overview" → **"Project settings"**
2. Scroll down to the **"Your apps"** section
3. Click the **Web icon** `</>` to add a web app
4. Enter an app nickname, e.g., `Football Legends Web`
5. Click **"Register app"**
6. Firebase will show you a config object like this:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
  authDomain: "football-legends-dream-xi.firebaseapp.com",
  projectId: "football-legends-dream-xi",
  storageBucket: "football-legends-dream-xi.appspot.com",
  messagingSenderId: "1234567890123",
  appId: "1:1234567890123:web:abcdef1234567890"
};
```

7. **Copy these values** — you'll need them in the next step

---

## 6. Update the Game's Firebase Config

1. Open the file `src/lib/firebase.ts` in your code editor
2. Find the `firebaseConfig` object (around line 25)
3. Replace the placeholder values with your real config:

```typescript
const firebaseConfig = {
  apiKey: "AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",       // ← Your apiKey
  authDomain: "football-legends-dream-xi.firebaseapp.com", // ← Your authDomain
  projectId: "football-legends-dream-xi",                  // ← Your projectId
  storageBucket: "football-legends-dream-xi.appspot.com",  // ← Your storageBucket
  messagingSenderId: "1234567890123",                      // ← Your messagingSenderId
  appId: "1:1234567890123:web:abcdef1234567890"            // ← Your appId
};
```

4. Save the file

> ⚠️ **Note:** The `isFirebaseConfigured` check will automatically detect when you've replaced the placeholder values and enable the login system.

---

## 7. Set Up Firestore Security Rules

1. In the Firebase Console, go to **Firestore Database** → **"Rules"** tab
2. Replace the existing rules with the following:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // User profiles — each user can only read/write their own profile
    match /users/{userId} {
      allow read: if request.auth != null && request.auth.uid == userId;
      allow write: if request.auth != null && request.auth.uid == userId;
    }

    // Game states — each user can only read/write their own game state
    match /gameStates/{userId} {
      allow read: if request.auth != null && request.auth.uid == userId;
      allow write: if request.auth != null && request.auth.uid == userId;
    }

    // Default: deny all
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

3. Click **"Publish"**

> 🔒 These rules ensure users can only access their own data. No user can read or write another user's game state.

---

## 8. Install Firebase CLI

Open a terminal and install the Firebase CLI globally:

```bash
npm install -g firebase-tools
```

Verify the installation:

```bash
firebase --version
```

---

## 9. Configure Firebase Hosting

1. In your terminal, navigate to your project folder:

```bash
cd /path/to/your/football-legends-game
```

2. Log in to Firebase:

```bash
firebase login
```

3. Initialize Firebase Hosting:

```bash
firebase init hosting
```

4. Answer the prompts:
   - **Use an existing project?** → Yes, select your `football-legends-dream-xi` project
   - **What do you want to use as your public directory?** → `out` (we'll configure this below)
   - **Configure as a single-page app?** → **Yes** (so all routes go to index.html)
   - **Set up automatic builds with GitHub?** → No (unless you want CI/CD)
   - **File `out/index.html` already exists. Overwrite?** → No

5. Firebase will create `firebase.json` and `.firebaserc` files in your project.

6. Open `firebase.json` and replace its contents with:

```json
{
  "hosting": {
    "public": "out",
    "ignore": ["firebase.json", "**/.*", "**/node_modules/**"],
    "rewrites": [
      {
        "source": "**",
        "destination": "/index.html"
      }
    ],
    "headers": [
      {
        "source": "**/*.@(js|css)",
        "headers": [
          { "key": "Cache-Control", "value": "max-age=604800" }
        ]
      }
    ]
  }
}
```

---

## 10. Build and Deploy

### Step 1: Configure Next.js for Static Export

1. Open `next.config.ts` in your project
2. Add the static export setting:

```typescript
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: 'export',
  images: { unoptimized: true },
};

export default nextConfig;
```

### Step 2: Build the Project

```bash
npm run build
```

This will generate a static export in the `out/` folder.

> ⚠️ **Note:** If you get errors about `next/image` or other server-side features, you may need to adjust some components. The game is designed to work client-side, so most features should work fine with static export.

### Step 3: Deploy to Firebase Hosting

```bash
firebase deploy --only hosting
```

Firebase will upload your files and give you a live URL like:
```
https://football-legends-dream-xi.web.app
```

---

## 11. Verify Your Deployment

1. **Visit your deployed URL** — the game should load
2. **Test the login system:**
   - Click the **"Sign In"** button in the top-right corner
   - Switch to **"Sign Up"** mode
   - Enter an email, password, and manager name
   - Click **"Create Account"**
   - You should be logged in and your profile shows in the header
3. **Test cloud sync:**
   - Open some packs, build a squad
   - Refresh the page — your progress should persist
   - Open the game in a different browser, sign in with the same account — your progress should load
4. **Test the market and trade features:**
   - Go to **Market** → buy a card with coins
   - Go to **Trade** → accept a trade offer

---

## 12. Troubleshooting

### "Firebase is not configured"
You see this message because `src/lib/firebase.ts` still has placeholder values. Go back to [Step 6](#6-update-the-games-firebase-config) and fill in your real config.

### Login button doesn't appear
The `AuthButton` component only renders when `isFirebaseConfigured` is `true`. Double-check your config values in `src/lib/firebase.ts`.

### "Missing or insufficient permissions"
Your Firestore security rules are blocking access. Go back to [Step 7](#7-set-up-firestore-security-rules) and make sure the rules are published correctly.

### Build errors with `output: 'export'`
Some Next.js features don't work with static export:
- `next/image` with external URLs → use `unoptimized: true` (already set)
- API routes → not available in static export (the game uses localStorage/Firestore, so this is fine)
- Server actions → not available (the game is client-side)

### CORS errors
If you see CORS errors in the browser console:
1. Go to Firebase Console → Authentication → Settings → Authorized domains
2. Add your deployed domain (e.g., `football-legends-dream-xi.web.app`)

### Deploy fails with "out directory not found"
Make sure you ran `npm run build` before `firebase deploy`. The build step creates the `out/` folder.

### Game state not syncing
Check that:
1. You're logged in (the header shows your profile)
2. Firestore rules allow read/write for the authenticated user
3. The browser console doesn't show permission errors

---

## 🎉 You're Live!

Your game is now deployed at `https://your-project.web.app` with:
- ✅ User authentication (email/password)
- ✅ Cloud save sync (Firestore)
- ✅ Card collection saved per user
- ✅ Market and trade features
- ✅ All game features from the original build

Share your URL and start collecting football legends!

---

## Optional: Custom Domain

To use a custom domain (e.g., `football-legends.com`):

1. Go to Firebase Console → Hosting → "Add custom domain"
2. Enter your domain
3. Firebase will give you a DNS A record to add to your domain registrar
4. Wait for DNS propagation (can take up to 24 hours)
5. Firebase will automatically provision an SSL certificate

## Optional: Analytics

To track user engagement:
1. Enable Google Analytics in Firebase Console
2. Add the Firebase Analytics SDK to your app
3. Track events like `pack_opened`, `match_played`, `card_bought`

---

## Quick Reference Commands

| Command | Description |
|---------|-------------|
| `npm run build` | Build the static export to `out/` |
| `firebase deploy --only hosting` | Deploy to Firebase Hosting |
| `firebase deploy --only firestore:rules` | Deploy Firestore rules |
| `firebase open hosting:site` | Open your live site in browser |
| `firebase logs --only hosting` | View hosting logs |

---

**Need help?** Check the [Firebase Documentation](https://firebase.google.com/docs) or the [Next.js Deployment Guide](https://nextjs.org/docs/app/building-your-application/deploying).
